-- ============================================================================
--  ZONECK - mise à jour de la base (version 1.3)
--  À coller UNE SEULE FOIS dans Supabase : menu « SQL Editor » > New query > Run.
--  Sans danger si on le relance : rien n'est effacé.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1) Groupe « Échanger entre membres » : date d'arrivée de chaque membre.
--    Une membre ne voit que les messages écrits APRÈS sa première ouverture du groupe.
-- ---------------------------------------------------------------------------
create table if not exists public.echange_members (
  user_id   uuid primary key references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now()
);

alter table public.echange_members enable row level security;

drop policy if exists "echange_members_select_own" on public.echange_members;
create policy "echange_members_select_own" on public.echange_members
  for select to authenticated using (user_id = auth.uid());

drop policy if exists "echange_members_insert_own" on public.echange_members;
create policy "echange_members_insert_own" on public.echange_members
  for insert to authenticated with check (user_id = auth.uid());

-- ---------------------------------------------------------------------------
-- 2) Comptes vendeur (1 000 FCFA d'inscription + 10 000 FCFA par mois, pubs gratuites)
-- ---------------------------------------------------------------------------
create table if not exists public.vendeurs (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null unique references auth.users(id) on delete cascade,
  nom         text not null,                 -- nom de l'entreprise
  responsable text,                          -- patron / patronne
  tel         text,
  description text,
  photo       text,                          -- photo 1 du patron (ajoutée par l'administrateur)
  photo2      text,                          -- photo 2 du patron
  status      text not null default 'pending', -- pending | paid | active | refused
  ref         text,                          -- référence Mobile Money (VEN-XXXXXX)
  montant     integer not null default 0,    -- somme à payer en ce moment
  expire_at   timestamptz,                   -- fin de l'abonnement en cours
  created_at  timestamptz not null default now()
);

alter table public.vendeurs enable row level security;

-- Tout le monde voit les comptes actifs ; chacun voit le sien ; l'administrateur voit tout.
drop policy if exists "vendeurs_select" on public.vendeurs;
create policy "vendeurs_select" on public.vendeurs
  for select using (status = 'active' or user_id = auth.uid() or public.salon_is_admin());

-- Une personne connectée peut créer SON compte vendeur (toujours « en attente de paiement »).
drop policy if exists "vendeurs_insert_own" on public.vendeurs;
create policy "vendeurs_insert_own" on public.vendeurs
  for insert to authenticated
  with check (user_id = auth.uid() and status = 'pending' and expire_at is null);

-- Seul l'administrateur modifie (activation, photos, prolongation) ou supprime.
drop policy if exists "vendeurs_admin_update" on public.vendeurs;
create policy "vendeurs_admin_update" on public.vendeurs
  for update to authenticated using (public.salon_is_admin()) with check (public.salon_is_admin());

drop policy if exists "vendeurs_admin_delete" on public.vendeurs;
create policy "vendeurs_admin_delete" on public.vendeurs
  for delete to authenticated using (public.salon_is_admin());

-- « J'ai payé » : le vendeur prévient l'administrateur.
create or replace function public.vendeur_declare_paid(p_ref text)
returns void language plpgsql security definer set search_path = public as $$
begin
  update public.vendeurs
     set status = 'paid'
   where user_id = auth.uid() and ref = p_ref and status = 'pending';
end $$;

-- Renouvellement mensuel : nouvelle référence ; le prix vient des « Réglages » du site (10 000 FCFA par défaut).
create or replace function public.vendeur_renew(p_ref text)
returns void language plpgsql security definer set search_path = public as $$
begin
  update public.vendeurs
     set status = 'pending', ref = p_ref,
         montant = coalesce((select (valeur->>'vendeur_mensuel')::int from public.contenu where cle = 'reglages'), 10000)
   where user_id = auth.uid();
end $$;

grant execute on function public.vendeur_declare_paid(text) to authenticated;
grant execute on function public.vendeur_renew(text) to authenticated;

-- ---------------------------------------------------------------------------
-- 3) Publicités GRATUITES pour les vendeurs actifs : mises en ligne automatiquement,
--    jusqu'à la fin de leur abonnement.
-- ---------------------------------------------------------------------------
create or replace function public.pubs_vendeur_gratuit()
returns trigger language plpgsql security definer set search_path = public as $$
declare v record;
begin
  select * into v from public.vendeurs
   where user_id = new.user_id and status = 'active'
     and (expire_at is null or expire_at > now())
   limit 1;
  if found then
    new.status    := 'active';
    new.montant   := 0;
    new.expire_at := v.expire_at;
  end if;
  return new;
end $$;

drop trigger if exists trg_pubs_vendeur_gratuit on public.pubs;
create trigger trg_pubs_vendeur_gratuit
  before insert on public.pubs
  for each row execute function public.pubs_vendeur_gratuit();

-- ---------------------------------------------------------------------------
-- 4) Messages vocaux et vidéos dans les discussions.
--    Si une règle de la base n'autorisait que « texte » et « image » dans la colonne
--    « type », on la retire (sinon les vocaux et vidéos seraient refusés).
-- ---------------------------------------------------------------------------
do $$
declare r record;
begin
  for r in
    select c.conrelid::regclass as tbl, c.conname
      from pg_constraint c
     where c.contype = 'c'
       and c.conrelid in ('public.messages'::regclass, 'public.echange_messages'::regclass)
       and pg_get_constraintdef(c.oid) ilike '%type%'
  loop
    execute format('alter table %s drop constraint %I', r.tbl, r.conname);
  end loop;
exception when undefined_table then null;
end $$;
