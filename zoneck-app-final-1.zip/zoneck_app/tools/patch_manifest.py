"""Ajoute internet, le nom « Zoneck » et les liens (téléphone, WhatsApp, e-mail) au manifeste Android."""
import re

path = "android/app/src/main/AndroidManifest.xml"
s = open(path, encoding="utf-8").read()

if "android.permission.INTERNET" not in s:
    s = s.replace("<application", '<uses-permission android:name="android.permission.INTERNET"/>\n    <application', 1)
for perm in ("POST_NOTIFICATIONS", "VIBRATE"):
    if "android.permission." + perm not in s:
        s = s.replace("<application", '<uses-permission android:name="android.permission.%s"/>\n    <application' % perm, 1)
if "android.permission.RECORD_AUDIO" not in s:
    s = s.replace("<application", '<uses-permission android:name="android.permission.RECORD_AUDIO"/>\n    <application', 1)

s = re.sub(r'android:label="[^"]*"', 'android:label="Zoneck"', s, count=1)

if "<queries>" not in s:
    queries = """
    <queries>
        <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>
        <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="tel"/></intent>
        <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="mailto"/></intent>
        <intent><action android:name="android.intent.action.PROCESS_TEXT"/><data android:mimeType="text/plain"/></intent>
    </queries>
"""
    # remplace le bloc <queries> par défaut s'il existe, sinon l'ajoute avant </manifest>
    s = s.replace("</manifest>", queries + "</manifest>", 1)

open(path, "w", encoding="utf-8").write(s)
print("Manifeste prêt.")
