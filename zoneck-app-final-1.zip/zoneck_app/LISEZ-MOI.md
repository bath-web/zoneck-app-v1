# Zoneck – application mobile (Flutter)

Application Android native du salon **Zoneck**, reliée à la même base Supabase que votre site :
mêmes comptes, mêmes réservations, mêmes messages, mêmes publicités, mêmes avis.

## Obtenir l'APK (fichier à installer sur le téléphone)

L'APK se fabrique automatiquement sur GitHub (gratuit). Voir le guide donné dans la conversation :

1. Créer un compte sur github.com, puis un dépôt **privé** nommé `zoneck-app`.
2. Y envoyer tout le contenu de ce dossier (y compris le dossier `.github`).
3. Onglet **Actions** → « Construire l'application Zoneck (APK) » → attendre ~8 minutes.
4. Onglet **Releases** (à droite sur la page du dépôt) → télécharger `app-release.apk`.
5. L'ouvrir sur le téléphone et autoriser l'installation.

## Mise à jour 1.3 : à faire UNE fois dans Supabase

Pour que le groupe « Échanger entre membres » (historique par membre) et les **comptes vendeur** fonctionnent :

1. Ouvrir Supabase > **SQL Editor** > New query.
2. Coller tout le contenu du fichier `supabase_mise_a_jour.sql`, puis **Run**.

Sans cette étape, l'application marche quand même, mais les comptes vendeur affichent « bientôt disponibles ».

## Ce que fait l'application

- Accueil, Nos réalisations (photos + vidéos), Catalogue et prix
- Réservation de rendez-vous (avec la photo du modèle choisi)
- Messagerie avec les salons et avec les vendeurs d'annonces : photos, vidéos, messages vocaux, réponse à un message précis, appui long pour supprimer (pour soi seulement)
- « Échanger entre membres » (menu) : groupe façon WhatsApp ; chaque membre ne voit que les messages écrits depuis son arrivée
- Compte vendeur (menu) : 1 000 FCFA d'inscription + 10 000 FCFA/mois, publicités gratuites ; l'administrateur ajoute 1 ou 2 photos des patrons (onglet « Vendeurs »)
- Publicités (création, paiement Mobile Money, mise en ligne)
- Avis, notifications, profil, 5 thèmes de couleur
- Espace administrateur (rendez-vous, validation des pubs, annonces à toutes les clientes)
- Le contenu modifié depuis le site (table `contenu`) s'affiche aussi dans l'application

## Personnaliser

- `lib/core/config.dart` : téléphone, e-mail, WhatsApp, adresse, prix des pubs.
- `assets/icon/icon.png` : icône de l'application (1024×1024).

## Compatibilité téléphones

- **Android 6.0 et plus** (environ 99 % des téléphones Android) : build « Construire l'application Zoneck (APK) ». Les notifications fonctionnent aussi sur Android 13, 14 et 15 (autorisation demandée).
- **iPhone, iOS 13 et plus** (iPhone 6s et suivants) : onglet Actions, « Construire l'application Zoneck (iPhone) », Run workflow. On récupère `Zoneck-iPhone.ipa` (non signé).
  Pour l'installer, Apple impose une signature : soit un compte Apple Developer (TestFlight / App Store), soit une installation de test avec AltStore ou Sideloadly et un identifiant Apple gratuit (valable 7 jours).
- Sur iPhone, les sons de notification personnalisés ne sont pas disponibles : le son standard de l'iPhone est utilisé.

## Réglages modifiables depuis le site

Dans l'administration du site : onglet **⚙️ Réglages** (prix d'inscription et mensuel des vendeuses, durée de l'abonnement, prix et durée des publicités, numéro Mobile Money, contacts) et onglet **🏪 Vendeuses** (photos des patronnes, activation / prolongation, refus, suppression).
L'application lit ces réglages au démarrage : plus besoin de refaire l'APK pour changer un prix. Pour que le renouvellement mensuel utilise le bon prix, relancez une fois `supabase_mise_a_jour.sql` dans Supabase.
