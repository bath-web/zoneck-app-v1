// Réglages de l'application Zoneck (repris du site).
const String supabaseUrl = 'https://oldjawwgrxxwcupbcxdg.supabase.co';
const String supabaseKey = 'sb_publishable_JYXX3SqMIpZKkvTGzy4cmg_8pG85ndt';

const String devise = 'FCFA';
String paiementTel = '06 480 78 53'; // Mobile Money qui reçoit les paiements des pubs
int prixPeriode = 1000;
int semainesPeriode = 2;

// Coordonnées affichées dans « Contact » (laisser vide = « À venir »)
String contactEmail = '';
String contactWhatsapp = ''; // ex : 242060000000
String contactTel = '';
String contactAdresse = '';

// Valeurs attendues par la base pour la réservation
const List<String> bookingSalons = ['Kinshundi barrage', 'Barrage', 'Plateau de 15'];

// Compte vendeur : inscription une fois, puis abonnement mensuel. Les publicités sont offertes.
int vendeurInscription = 1000;
int vendeurMensuel = 10000;
int vendeurJours = 30;

const String zkTag = '⁢'; // séparateur invisible des citations (comme sur le site)
