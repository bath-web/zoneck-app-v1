import 'dart:ui' show Color;
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// Un son de notification proposé dans les paramètres.
class ZkSound {
  final String id; // sert aussi à nommer le canal Android
  final String label;
  final String raw; // nom du fichier son (dossier res/raw), vide = son du téléphone
  const ZkSound(this.id, this.label, this.raw);
}

const List<ZkSound> zkSounds = [
  ZkSound('defaut', 'Son du téléphone', ''),
  ZkSound('cristal', 'Cristal', 'zk_cristal'),
  ZkSound('goutte', 'Goutte', 'zk_goutte'),
  ZkSound('carillon', 'Carillon', 'zk_carillon'),
  ZkSound('pop', 'Pop', 'zk_pop'),
  ZkSound('douce', 'Douce', 'zk_douce'),
  ZkSound('silence', 'Silencieux', ''),
];

ZkSound soundById(String id) {
  for (final s in zkSounds) {
    if (s.id == id) return s;
  }
  return zkSounds[1];
}

/// Notifications dans la barre du téléphone (avec son).
class Notifier {
  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static Future<void> init() async {
    try {
      const settings = InitializationSettings(
        android: AndroidInitializationSettings('ic_stat_zk'),
        iOS: DarwinInitializationSettings(requestAlertPermission: false, requestBadgePermission: false, requestSoundPermission: false),
      );
      await _plugin.initialize(settings);
      final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      for (final s in zkSounds) {
        await android?.createNotificationChannel(AndroidNotificationChannel(
          'zk_msg_${s.id}',
          'Zoneck - ${s.label}',
          description: 'Messages et annonces Zoneck',
          importance: Importance.high,
          playSound: s.id != 'silence',
          sound: s.raw.isEmpty ? null : RawResourceAndroidNotificationSound(s.raw),
          enableVibration: s.id != 'silence',
        ));
      }
      _ready = true;
    } catch (e) {
      debugPrint('Notifier.init: $e');
    }
  }

  /// Demande l'autorisation d'afficher des notifications (Android 13 et +, iPhone).
  static Future<void> askPermission() async {
    try {
      final android = _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      await android?.requestNotificationsPermission();
      final ios = _plugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>();
      await ios?.requestPermissions(alert: true, badge: true, sound: true);
    } catch (_) {}
  }

  static Future<void> show({required String key, required String title, required String body, required String soundId}) async {
    if (!_ready) return;
    try {
      final s = soundById(soundId);
      final id = key.hashCode & 0x7fffffff;
      final details = AndroidNotificationDetails(
        'zk_msg_${s.id}',
        'Zoneck - ${s.label}',
        channelDescription: 'Messages et annonces Zoneck',
        importance: Importance.high,
        priority: Priority.high,
        playSound: s.id != 'silence',
        enableVibration: s.id != 'silence',
        icon: 'ic_stat_zk',
        color: const Color(0xFFD4E04A),
        styleInformation: BigTextStyleInformation(body),
      );
      await _plugin.show(id, title, body, NotificationDetails(
        android: details,
        iOS: DarwinNotificationDetails(presentAlert: true, presentBanner: true, presentList: true, presentSound: s.id != 'silence'),
      ));
    } catch (e) {
      debugPrint('Notifier.show: $e');
    }
  }
}
