import 'package:shared_preferences/shared_preferences.dart';

/// Messages « supprimés pour moi » : ils sont seulement cachés sur ce téléphone,
/// les autres personnes les voient toujours.
class Hidden {
  static final Map<String, Set<String>> _cache = {};

  static Future<Set<String>> load(String scope) async {
    final c = _cache[scope];
    if (c != null) return c;
    Set<String> s = <String>{};
    try {
      final p = await SharedPreferences.getInstance();
      s = (p.getStringList('zk_hidden_$scope') ?? <String>[]).toSet();
    } catch (_) {}
    _cache[scope] = s;
    return s;
  }

  static Future<void> add(String scope, String id) async {
    final s = await load(scope);
    s.add(id);
    try {
      final p = await SharedPreferences.getInstance();
      await p.setStringList('zk_hidden_$scope', s.toList());
    } catch (_) {}
  }
}
