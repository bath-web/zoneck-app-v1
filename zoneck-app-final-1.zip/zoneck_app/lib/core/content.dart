import 'package:flutter/foundation.dart';
import 'api.dart';
import 'config.dart';

/// Une coiffure du catalogue.
class Coiffure {
  final String nom, desc;
  final int min, max;
  final String? img;
  const Coiffure(this.nom, this.desc, this.min, this.max, [this.img]);

  String get prix => min == max ? '${money(min)} FCFA' : '${money(min)} – ${money(max)} FCFA';
}

/// Une photo (ou vidéo) de « Nos réalisations ».
class Realisation {
  final String img, type;
  final bool video;
  const Realisation(this.img, this.type, {this.video = false});
}

class Salon {
  final String nom, heures, patronne, tel, adresse;
  final List<String> photos;
  const Salon(this.nom, this.heures, this.patronne, this.photos, {this.tel = '', this.adresse = ''});

  /// Valeur attendue par la base pour les réservations / messages.
  String get cle {
    final n = nom.toLowerCase();
    if (n.contains('plateau')) return bookingSalonsKey[2];
    if (n.contains('kin')) return bookingSalonsKey[0];
    return bookingSalonsKey[1];
  }
}

const bookingSalonsKey = ['Kinshundi barrage', 'Barrage', 'Plateau de 15'];

/// Nom à afficher d'un salon. La valeur gardée dans la base (« Kinshundi barrage ») ne change pas,
/// mais à l'écran on écrit toujours le nom correctement : Kinsoundi Barrage.
String salonLabel(String key) {
  final n = key.toLowerCase().trim();
  if (n.startsWith('kins') || n.startsWith('kin ')) return 'Kinsoundi Barrage';
  return key;
}

const _defCoiffures = <Coiffure>[
  Coiffure('Closure', 'Pose soignée et naturelle.', 5000, 10000, 'asset:lace2'),
  Coiffure('Lace', 'Lace frontale ou closure, rendu invisible.', 5000, 10000, 'asset:lace1'),
  Coiffure('Pose perruque', 'Pose, ajustement et finition.', 5000, 10000, 'asset:n2'),
  Coiffure('Make-up', 'Maquillage sublime pour toutes occasions.', 5000, 10000, 'asset:mk1'),
  Coiffure('Mariée', 'Coiffure et maquillage pour le grand jour.', 5000, 10000, 'asset:mar1'),
  Coiffure('Chignon', 'Chignons lisses ou bouclés, élégants.', 5000, 10000, 'asset:chignon'),
  Coiffure('Tresses arabes', 'Tresses élégantes et durables.', 5000, 10000),
  Coiffure('Tresses américaines', 'Un style moderne et net.', 5000, 10000),
  Coiffure('Twists', 'Nattes collées et twists, légers et stylés.', 5000, 10000, 'asset:twists'),
  Coiffure('Tissage', 'Volume et longueur sur mesure.', 5000, 10000),
  Coiffure('Coupe courte', 'Coupe courte nette et moderne.', 5000, 10000, 'asset:court'),
  Coiffure('Coloration', 'Couleurs vibrantes, produits bio.', 5000, 10000, 'asset:n5'),
  Coiffure('Brushing', 'Un fini souple et brillant.', 5000, 10000, 'asset:brush'),
  Coiffure('Soin capillaire', 'Nourrit et répare en profondeur.', 5000, 10000),
];

List<Realisation> _defPortfolio() {
  const base = <String, String>{
    'mar1': 'Mariée', 'mar2': 'Mariée', 'chignon': 'Chignon', 'lace1': 'Lace', 'lace2': 'Lace',
    'twists': 'Twists', 'mk1': 'Make-up', 'mk2': 'Make-up', 'mk3': 'Make-up', 'mk4': 'Make-up',
    'court': 'Coupe courte', 'brush': 'Brushing',
    'n1': 'Coupe courte', 'n2': 'Pose perruque', 'n3': 'Coupe courte', 'n4': 'Gélé', 'n5': 'Coloration',
    'n6': 'Mariée', 'n7': 'Lace', 'n8': 'Chignon', 'n9': 'Mariée', 'n10': 'Chignon', 'n11': 'Make-up',
    'p1': 'Coupe courte', 'p2': 'Coupe courte', 'p3': 'Coupe courte', 'p4': 'Coupe courte',
    'p5': 'Coupe courte', 'p6': 'Make-up', 'p7': 'Coupe courte', 'p8': 'Coupe courte',
    'p9': 'Coupe courte', 'p10': 'Make-up', 'p11': 'Make-up', 'p12': 'Brushing', 'p13': 'Mariée',
    'p14': 'Coupe courte', 'p15': 'Mariée', 'p16': 'Chignon', 'p17': 'Mariée', 'p18': 'Brushing',
    'p19': 'Chignon', 'p20': 'Chignon', 'p21': 'Mariée', 'p22': 'Make-up', 'p23': 'Make-up',
    'p24': 'Make-up', 'p25': 'Chignon', 'p26': 'Make-up', 'p27': 'Make-up',
  };
  return base.entries.map((e) => Realisation('asset:${e.key}', e.value)).toList();
}

const _defSalons = <Salon>[
  Salon('Plateau des 15 ans', '8h – 22h', 'Thergela', ['asset:salon1', 'asset:salon2']),
  Salon('Kinsoundi Barrage', '8h – 23h', 'Lauretta', ['asset:salon3']),
  Salon('Barrage', '8h – 21h', 'Chardelle', []),
];

const videoAssets = ['assets/videos/v1.mp4', 'assets/videos/v2.mp4', 'assets/videos/v3.mp4'];

/// Contenu du salon : valeurs d'origine, puis mises à jour faites depuis le site (table « contenu »).
class ContentStore extends ChangeNotifier {
  List<Coiffure> coiffures = List.of(_defCoiffures);
  List<Realisation> portfolio = _defPortfolio();
  List<Salon> salons = List.of(_defSalons);
  bool loaded = false;

  /// Photos + vidéos mélangées comme sur le site (une vidéo toutes les 3 photos).
  List<Realisation> get mix {
    final vids = [for (final v in videoAssets) Realisation(v, 'Vidéo', video: true)];
    final out = <Realisation>[];
    var vk = 0;
    for (var k = 0; k < portfolio.length; k++) {
      out.add(portfolio[k]);
      if ((k + 1) % 3 == 0 && vk < vids.length) out.add(vids[vk++]);
    }
    while (vk < vids.length) {
      out.add(vids[vk++]);
    }
    return out;
  }

  List<String> get types {
    final t = <String>{};
    for (final r in mix) {
      t.add(r.type);
    }
    return ['Tout', ...t];
  }

  String? imageFor(Coiffure c) {
    if (c.img != null) return c.img;
    for (final r in portfolio) {
      if (r.type == c.nom) return r.img;
    }
    return null;
  }

  Coiffure? coiffureNamed(String nom) {
    for (final c in coiffures) {
      if (c.nom == nom) return c;
    }
    return null;
  }

  /// Réglages modifiables depuis l'administration du site (prix, contacts) : ils remplacent les valeurs par défaut.
  void _applyReglages(Map v) {
    int n(dynamic x, int d, {bool zero = false}) {
      final i = x is num ? x.toInt() : int.tryParse('${x ?? ''}'.trim());
      return i != null && (zero ? i >= 0 : i > 0) ? i : d;
    }
    String s(dynamic x, String d) {
      final t = '${x ?? ''}'.trim();
      return t.isEmpty ? d : t;
    }
    vendeurInscription = n(v['vendeur_inscription'], vendeurInscription, zero: true);
    vendeurMensuel = n(v['vendeur_mensuel'], vendeurMensuel, zero: true);
    vendeurJours = n(v['vendeur_jours'], vendeurJours);
    prixPeriode = n(v['pub_periode'], prixPeriode, zero: true);
    semainesPeriode = n(v['pub_semaines'], semainesPeriode);
    paiementTel = s(v['paiement_tel'], paiementTel);
    contactTel = s(v['contact_tel'], contactTel);
    contactWhatsapp = s(v['contact_whatsapp'], contactWhatsapp);
    contactEmail = s(v['contact_email'], contactEmail);
    contactAdresse = s(v['contact_adresse'], contactAdresse);
  }

  Future<void> load() async {
    try {
      final rows = await sb.from('contenu').select('cle,valeur');
      List<Realisation> base = _defPortfolio();
      List hidden = [];
      List extra = [];
      Map ovr = {};
      for (final row in (rows as List)) {
        final key = row['cle'];
        final v = row['valeur'];
        if (key == 'prix_override' && v is Map) ovr = v;
        if (key == 'reglages' && v is Map) _applyReglages(v);
        if (v is! List) continue;
        if (key == 'portfolio_hidden') hidden = v;
        if (key == 'portfolio_extra') extra = v;
        if (v.isEmpty) continue;
        if (key == 'coiffures') coiffures = v.map<Coiffure>(_coiffureFrom).toList();
        if (key == 'portfolio') base = v.map<Realisation>(_realFrom).toList();
        if (key == 'salons') salons = v.map<Salon>(_salonFrom).toList();
      }
      if (ovr.isNotEmpty) {
        coiffures = [
          for (final c in coiffures)
            if (ovr[c.nom] is List && (ovr[c.nom] as List).length >= 2)
              Coiffure(c.nom, c.desc, _int((ovr[c.nom] as List)[0]), _int((ovr[c.nom] as List)[1]), c.img)
            else
              c
        ];
      }
      final shown = <Realisation>[
        for (var i = 0; i < base.length; i++)
          if (!hidden.contains(i)) base[i]
      ];
      shown.addAll(extra.map<Realisation>(_realFrom));
      portfolio = shown;
      loaded = true;
      notifyListeners();
    } catch (_) {
      // Pas de connexion : on garde le contenu d'origine intégré à l'application.
    }
  }

  static int _int(dynamic v) => v is num ? v.round() : int.tryParse('$v') ?? 0;

  static Coiffure _coiffureFrom(dynamic m) {
    final prix = m['prix'];
    final a = prix is List && prix.isNotEmpty ? _int(prix[0]) : 0;
    final b = prix is List && prix.length > 1 ? _int(prix[1]) : a;
    return Coiffure('${m['nom'] ?? ''}', '${m['desc'] ?? ''}', a, b, _img(m['img']));
  }

  static Realisation _realFrom(dynamic m) => Realisation(_img(m['img']) ?? '', '${m['type'] ?? ''}');

  static Salon _salonFrom(dynamic m) => Salon(
        '${m['nom'] ?? ''}',
        '${m['heures'] ?? ''}',
        '${m['patronne'] ?? ''}',
        [
          for (final k in ['photo', 'photo2'])
            if (m[k] != null && '${m[k]}'.isNotEmpty) _img(m[k])!
        ],
        tel: '${m['tel'] ?? ''}',
        adresse: '${m['adresse'] ?? ''}',
      );

  static String? _img(dynamic v) {
    if (v == null) return null;
    final s = '$v';
    return s.isEmpty ? null : s;
  }
}
