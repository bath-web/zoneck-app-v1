import 'package:flutter/material.dart';

class Pal extends ThemeExtension<Pal> {
  final Color bg, bg2, card, line, text, muted, accent, ink;
  const Pal({
    required this.bg,
    required this.bg2,
    required this.card,
    required this.line,
    required this.text,
    required this.muted,
    required this.accent,
    required this.ink,
  });

  @override
  Pal copyWith({Color? bg, Color? bg2, Color? card, Color? line, Color? text, Color? muted, Color? accent, Color? ink}) =>
      Pal(
        bg: bg ?? this.bg,
        bg2: bg2 ?? this.bg2,
        card: card ?? this.card,
        line: line ?? this.line,
        text: text ?? this.text,
        muted: muted ?? this.muted,
        accent: accent ?? this.accent,
        ink: ink ?? this.ink,
      );

  @override
  Pal lerp(ThemeExtension<Pal>? other, double t) => this;
}

const Map<String, Pal> palettes = {
  'violet': Pal(
      bg: Color(0xFF4A2A58), bg2: Color(0xFF3B2047), card: Color(0x12FFFFFF), line: Color(0x29FFFFFF),
      text: Colors.white, muted: Color(0xFFD6C6DE), accent: Color(0xFFD4E04A), ink: Color(0xFF2A1633)),
  'rose': Pal(
      bg: Color(0xFF7A2352), bg2: Color(0xFF5F1A40), card: Color(0x14FFFFFF), line: Color(0x2EFFFFFF),
      text: Colors.white, muted: Color(0xFFF2CFE0), accent: Color(0xFFFFC2DC), ink: Color(0xFF4A0F2D)),
  'bleu': Pal(
      bg: Color(0xFF12386B), bg2: Color(0xFF0C2A52), card: Color(0x12FFFFFF), line: Color(0x29FFFFFF),
      text: Colors.white, muted: Color(0xFFC3D6EE), accent: Color(0xFF7FD6FF), ink: Color(0xFF06223F)),
  'noir': Pal(
      bg: Color(0xFF121212), bg2: Color(0xFF000000), card: Color(0x12FFFFFF), line: Color(0x29FFFFFF),
      text: Colors.white, muted: Color(0xFFB8B8B8), accent: Color(0xFFF2C14E), ink: Color(0xFF1A1200)),
  'blanc': Pal(
      bg: Color(0xFFFFFFFF), bg2: Color(0xFFF4EFF8), card: Color(0x0A000000), line: Color(0x21000000),
      text: Color(0xFF2A1633), muted: Color(0xFF6B5A75), accent: Color(0xFFB0398A), ink: Colors.white),
};

const Map<String, String> themeLabels = {
  'violet': 'Violet',
  'rose': 'Rose',
  'bleu': 'Bleu',
  'noir': 'Noir',
  'blanc': 'Blanc',
};

ThemeData buildTheme(String name) {
  final p = palettes[name] ?? palettes['violet']!;
  final light = name == 'blanc';
  final scheme = (light ? const ColorScheme.light() : const ColorScheme.dark()).copyWith(
    primary: p.accent,
    onPrimary: p.ink,
    surface: p.bg,
    onSurface: p.text,
    secondary: p.accent,
    onSecondary: p.ink,
    error: const Color(0xFFFF8A8A),
  );
  final border = OutlineInputBorder(
    borderRadius: BorderRadius.circular(14),
    borderSide: BorderSide(color: p.line),
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: p.bg,
    canvasColor: p.bg2,
    dividerColor: p.line,
    extensions: <ThemeExtension<dynamic>>[p],
    appBarTheme: AppBarTheme(
      backgroundColor: p.bg2,
      foregroundColor: p.text,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: p.bg2,
      selectedItemColor: p.accent,
      unselectedItemColor: p.muted,
      type: BottomNavigationBarType.fixed,
      showUnselectedLabels: true,
      selectedLabelStyle: const TextStyle(fontSize: 11),
      unselectedLabelStyle: const TextStyle(fontSize: 11),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: p.card,
      labelStyle: TextStyle(color: p.muted),
      hintStyle: TextStyle(color: p.muted),
      border: border,
      enabledBorder: border,
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: p.accent, width: 1.6),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: p.accent,
        foregroundColor: p.ink,
        minimumSize: const Size(0, 50),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
        textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: p.text,
        minimumSize: const Size(0, 50),
        side: BorderSide(color: p.line),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(26)),
        textStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
      ),
    ),
    textButtonTheme: TextButtonThemeData(style: TextButton.styleFrom(foregroundColor: p.accent)),
    chipTheme: ChipThemeData(
      backgroundColor: p.card,
      selectedColor: p.accent,
      labelStyle: TextStyle(color: p.text, fontWeight: FontWeight.w600),
      secondaryLabelStyle: TextStyle(color: p.ink, fontWeight: FontWeight.w700),
      side: BorderSide(color: p.line),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      checkmarkColor: p.ink,
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: p.bg2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: p.accent,
      contentTextStyle: TextStyle(color: p.ink, fontWeight: FontWeight.w600),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
  );
}

extension PalX on BuildContext {
  Pal get pal => Theme.of(this).extension<Pal>()!;
}
