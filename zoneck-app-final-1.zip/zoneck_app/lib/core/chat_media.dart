import 'dart:io' show File;
import 'dart:math';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart' show FileOptions;
import 'api.dart';
import 'app_state.dart';

/// Un média déjà envoyé sur internet, prêt à être mis dans un message.
class SentMedia {
  final String url, type; // type : image | video | audio
  const SentMedia(this.url, this.type);
}

String _rnd() => '${DateTime.now().millisecondsSinceEpoch}-${Random().nextInt(99999).toRadixString(36)}';

const int maxVideoMo = 45;

/// Choisit une photo (galerie ou appareil photo) et l'envoie. Renvoie null si la personne annule.
Future<SentMedia?> pickPhoto(ImageSource source, {String prefix = 'chat'}) async {
  final f = await ImagePicker().pickImage(source: source, maxWidth: 1280, imageQuality: 75);
  if (f == null) return null;
  final bytes = await f.readAsBytes();
  final path = '${app.user!.id}/$prefix-${_rnd()}.jpg';
  await sb.storage.from('chat').uploadBinary(path, bytes, fileOptions: const FileOptions(contentType: 'image/jpeg', cacheControl: '31536000'));
  return SentMedia(sb.storage.from('chat').getPublicUrl(path), 'image');
}

/// Choisit une vidéo dans la galerie (ou la filme) et l'envoie.
Future<SentMedia?> pickVideo(ImageSource source, {String prefix = 'chat'}) async {
  final f = await ImagePicker().pickVideo(source: source, maxDuration: const Duration(seconds: 90));
  if (f == null) return null;
  final file = File(f.path);
  final size = await file.length();
  if (size > maxVideoMo * 1024 * 1024) {
    throw Exception('Cette vidéo est trop lourde ($maxVideoMo Mo maximum). Choisissez une vidéo plus courte.');
  }
  final path = '${app.user!.id}/$prefix-${_rnd()}.mp4';
  await sb.storage.from('chat').upload(path, file, fileOptions: const FileOptions(contentType: 'video/mp4', cacheControl: '31536000'));
  return SentMedia(sb.storage.from('chat').getPublicUrl(path), 'video');
}

/// Envoie un message vocal enregistré. La durée est gardée à la fin de l'adresse (#d=12).
Future<SentMedia> uploadAudio(String filePath, int seconds, {String prefix = 'chat'}) async {
  final file = File(filePath);
  final path = '${app.user!.id}/$prefix-${_rnd()}.m4a';
  await sb.storage.from('chat').upload(path, file, fileOptions: const FileOptions(contentType: 'audio/mp4', cacheControl: '31536000'));
  final url = sb.storage.from('chat').getPublicUrl(path);
  return SentMedia('$url#d=$seconds', 'audio');
}

/// Durée (en secondes) gardée dans l'adresse d'un message vocal, 0 si inconnue.
int audioSeconds(String url) {
  final i = url.indexOf('#d=');
  if (i < 0) return 0;
  return int.tryParse(url.substring(i + 3)) ?? 0;
}

String cleanUrl(String url) {
  final i = url.indexOf('#');
  return i < 0 ? url : url.substring(0, i);
}
