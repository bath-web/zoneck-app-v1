/// Catalogue d'emojis de Zoneck : beauté, coiffure, femmes (avec toutes les teintes de peau).
class EmojiCat {
  final String icon;
  final String name;
  final List<String> items;
  final bool quick; // true = phrases rapides (envoyées d'un seul toucher)
  const EmojiCat(this.icon, this.name, this.items, {this.quick = false});
}

const String _fem = '\u200D\u2640\uFE0F';
const List<String> _tones = ['', '\u{1F3FB}', '\u{1F3FC}', '\u{1F3FD}', '\u{1F3FE}', '\u{1F3FF}'];

List<String> _toned(String base) => [for (final t in _tones) '$base$t'];
List<String> _tonedFemale(String base) => [for (final t in _tones) '$base$t$_fem'];
List<String> _curly() => [for (final t in _tones.sublist(3)) '\u{1F469}$t\u200D\u{1F9B1}'];

final List<EmojiCat> emojiCats = [
  EmojiCat('\u{1F487}\u200D\u2640\uFE0F', 'Coiffure et beauté', [
    ..._tonedFemale('\u{1F487}'),
    ..._tonedFemale('\u{1F486}'),
    ..._toned('\u{1F485}'),
    '\u{1F484}', '\u{1F48B}', '\u{1F451}', '\u2728', '\u{1F4AB}', '\u{1F31F}', '\u{1F48E}', '\u{1F48D}',
    '\u{1F380}', '\u{1F9F4}', '\u{1F9FC}', '\u{1F460}', '\u{1F457}', '\u{1F45C}', '\u{1F452}', '\u{1F490}',
    '\u{1F338}', '\u{1F33A}', '\u{1F339}', '\u{1F337}', '\u{1F33C}', '\u{1F98B}', '\u{1F9D6}\u200D\u2640\uFE0F',
  ]),
  EmojiCat('\u{1F469}\u{1F3FE}', 'Femmes', [
    ..._toned('\u{1F469}'),
    ..._curly(),
    ..._toned('\u{1F478}'),
    ..._toned('\u{1F483}'),
    ..._tonedFemale('\u{1F64B}'),
    ..._tonedFemale('\u{1F481}'),
    ..._tonedFemale('\u{1F937}'),
    ..._tonedFemale('\u{1F9D6}'),
    ..._toned('\u{1F470}'),
    ..._toned('\u{1F930}'),
    ..._toned('\u{1F9D5}'),
    '\u{1F46D}', '\u{1F46F}\u200D\u2640\uFE0F', '\u{1F469}\u200D\u2764\uFE0F\u200D\u{1F469}',
  ]),
  EmojiCat('\u{1F60D}', 'Visages', [
    '\u{1F600}', '\u{1F603}', '\u{1F604}', '\u{1F601}', '\u{1F606}', '\u{1F605}', '\u{1F602}', '\u{1F923}',
    '\u{1F60A}', '\u{1F607}', '\u{1F642}', '\u{1F609}', '\u{1F60D}', '\u{1F970}', '\u{1F618}', '\u{1F617}',
    '\u{1F619}', '\u{1F61A}', '\u{1F60B}', '\u{1F61B}', '\u{1F61C}', '\u{1F92A}', '\u{1F60E}', '\u{1F929}',
    '\u{1F973}', '\u{1F60F}', '\u{1F612}', '\u{1F61E}', '\u{1F614}', '\u{1F61F}', '\u{1F615}', '\u{1F641}',
    '\u{1F623}', '\u{1F616}', '\u{1F62B}', '\u{1F629}', '\u{1F97A}', '\u{1F622}', '\u{1F62D}', '\u{1F624}',
    '\u{1F620}', '\u{1F621}', '\u{1F92C}', '\u{1F92F}', '\u{1F633}', '\u{1F975}', '\u{1F976}', '\u{1F631}',
    '\u{1F628}', '\u{1F630}', '\u{1F625}', '\u{1F613}', '\u{1F917}', '\u{1F914}', '\u{1F92D}', '\u{1F92B}',
    '\u{1F636}', '\u{1F610}', '\u{1F611}', '\u{1F62C}', '\u{1F644}', '\u{1F62F}', '\u{1F626}', '\u{1F627}',
    '\u{1F62E}', '\u{1F632}', '\u{1F971}', '\u{1F634}', '\u{1F924}', '\u{1F62A}', '\u{1F635}', '\u{1F910}',
    '\u{1F974}', '\u{1F922}', '\u{1F92E}', '\u{1F927}', '\u{1F637}', '\u{1F912}', '\u{1F915}',
  ]),
  EmojiCat('\u{1F49C}', 'Cœurs et mains', [
    '\u2764\uFE0F', '\u{1F9E1}', '\u{1F49B}', '\u{1F49A}', '\u{1F499}', '\u{1F49C}', '\u{1F5A4}', '\u{1F90D}',
    '\u{1F90E}', '\u{1F494}', '\u{1F495}', '\u{1F49E}', '\u{1F493}', '\u{1F497}', '\u{1F496}', '\u{1F498}',
    '\u{1F49D}', '\u{1F49F}', '\u{1F48C}',
    ..._toned('\u{1F44D}'),
    ..._toned('\u{1F44F}'),
    ..._toned('\u{1F64F}'),
    ..._toned('\u{1F64C}'),
    ..._toned('\u{1F4AA}'),
    ..._toned('\u{1F44C}'),
    ..._toned('\u{1F44B}'),
    ..._toned('\u{1F91E}'),
    ..._toned('\u{1F919}'),
    '\u{1F91D}', '\u{1F44E}',
  ]),
  EmojiCat('\u{1F389}', 'Fête et objets', [
    '\u{1F389}', '\u{1F38A}', '\u{1F381}', '\u{1F382}', '\u{1F37E}', '\u{1F942}', '\u{1F370}', '\u{1F525}',
    '\u{1F4AF}', '\u2705', '\u274C', '\u2B50', '\u{1F308}', '\u{1F319}', '\u{1F3B5}', '\u{1F3B6}',
    '\u{1F4F8}', '\u{1F4DE}', '\u{1F4B0}', '\u{1F4B5}', '\u{1F697}', '\u{1F3E0}', '\u23F0', '\u{1F4C5}',
    '\u{1F4A1}', '\u{1F4AC}', '\u{1F4E2}', '\u{1F6CD}\uFE0F', '\u{1F37D}\uFE0F', '\u{1F34E}', '\u{1F349}',
    '\u{1F34D}', '\u{1F95B}', '\u2615', '\u{1F377}',
  ]),
  EmojiCat('\u{1F4AC}', 'Phrases rapides', [
    'Bonjour tout le monde \u{1F44B}\u2728',
    'Merci beaucoup \u{1F49C}',
    'Trop belle coiffure \u{1F60D}\u{1F487}\u200D\u2640\uFE0F',
    'Très belle réalisation \u{1F44F}',
    'Je réserve ! \u{1F4C5}\u2728',
    'Quel est le prix ? \u{1F4B0}',
    'Où êtes-vous situées ? \u{1F4CD}',
    'À très vite \u{1F496}',
    'Bonne journée à toutes \u{1F338}',
    'Félicitations ma chérie \u{1F389}',
    'Je suis intéressée \u{1F64B}\u200D\u2640\uFE0F',
    'Belle journée \u2600\uFE0F',
  ], quick: true),
];
