import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart' show AppLifecycleState, WidgetsBinding, WidgetsBindingObserver;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'api.dart';
import 'config.dart' show zkTag;
import 'content.dart';
import 'i18n.dart';
import 'notifier.dart';

const avatarEmojis = ['🌸', '💜', '✨', '🌺', '👑', '🦋', '🌟', '💃', '🔥', '🌈', '🍀', '💎'];

class _Alert {
  final String key, kind, title, body;
  const _Alert(this.key, this.kind, this.title, this.body);
}

class AppState extends ChangeNotifier with WidgetsBindingObserver {
  String theme = 'violet';
  String lang = 'fr';
  String soundId = 'cristal';
  bool notifMessages = true;
  bool notifEchange = true;
  bool foreground = true;
  int chatOpen = 0; // nombre de discussions ouvertes à l'écran
  final Set<String> _pushed = <String>{};
  bool _baseline = false;
  bool _askedPerm = false;
  Map<String, dynamic>? profile;
  User? user;
  bool isAdmin = false;
  int unreadMessages = 0;
  int unreadNotifs = 0;
  int unreadEchange = 0;
  DateTime? echangeJoinedAt; // à partir de quand la personne voit le groupe Échange
  Map<String, dynamic>? vendeur; // compte vendeur de la personne (s'il existe)
  final ContentStore content = ContentStore();
  SharedPreferences? _prefs;
  Timer? _poll;
  bool _authBusy = false;

  bool get loggedIn => user != null;

  /// Compte vendeur payé et encore valable : les publicités sont alors gratuites.
  bool get vendeurActive {
    final v = vendeur;
    if (v == null || '${v['status']}' != 'active') return false;
    final e = parseDate(v['expire_at']);
    return e == null || e.isAfter(DateTime.now());
  }
  String get prenom => (profile?['prenom'] ?? user?.email?.split('@').first ?? '').toString();
  String get avatar => (profile?['avatar'] ?? 'e:🌸').toString();

  Future<void> init() async {
    try {
      _prefs = await SharedPreferences.getInstance();
      theme = _prefs?.getString('zk_theme') ?? 'violet';
      lang = _prefs?.getString('zk_lang') ?? 'fr';
      soundId = _prefs?.getString('zk_sound') ?? 'cristal';
      notifMessages = _prefs?.getBool('zk_notif_msg') ?? true;
      notifEchange = _prefs?.getBool('zk_notif_echange') ?? true;
    } catch (_) {}
    setCurrentLang(lang);
    WidgetsBinding.instance.addObserver(this);
    user = sb.auth.currentSession?.user;
    sb.auth.onAuthStateChange.listen((data) {
      user = data.session?.user;
      if (_authBusy) return;
      loadMe();
    });
    content.load();
    await loadMe();
    _poll = Timer.periodic(const Duration(seconds: 15), (_) => refreshCounters());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    foreground = state == AppLifecycleState.resumed;
    if (foreground) refreshCounters();
  }

  Future<void> setLang(String l) async {
    lang = l;
    setCurrentLang(l);
    notifyListeners();
    try {
      await _prefs?.setString('zk_lang', l);
    } catch (_) {}
  }

  Future<void> setSound(String id) async {
    soundId = id;
    notifyListeners();
    try {
      await _prefs?.setString('zk_sound', id);
    } catch (_) {}
  }

  Future<void> setNotifMessages(bool v) async {
    notifMessages = v;
    notifyListeners();
    try {
      await _prefs?.setBool('zk_notif_msg', v);
    } catch (_) {}
  }

  Future<void> setNotifEchange(bool v) async {
    notifEchange = v;
    notifyListeners();
    try {
      await _prefs?.setBool('zk_notif_echange', v);
    } catch (_) {}
  }

  Future<void> setTheme(String t) async {
    theme = t;
    notifyListeners();
    try {
      await _prefs?.setString('zk_theme', t);
    } catch (_) {}
  }

  Future<void> loadMe() async {
    user = sb.auth.currentSession?.user;
    if (user == null) {
      profile = null;
      isAdmin = false;
      unreadMessages = 0;
      unreadNotifs = 0;
      unreadEchange = 0;
      echangeJoinedAt = null;
      vendeur = null;
      _pushed.clear();
      _baseline = false;
      notifyListeners();
      return;
    }
    if (!_askedPerm) {
      _askedPerm = true;
      Notifier.askPermission();
    }
    try {
      final p = await sb.from('profiles').select().eq('id', user!.id).maybeSingle();
      if (p != null) {
        profile = Map<String, dynamic>.from(p);
      } else {
        final fb = {
          'id': user!.id,
          'prenom': (user!.email ?? 'Moi').split('@').first,
          'nom': 'Membre',
          'avatar': 'e:🌸',
        };
        try {
          await sb.from('profiles').upsert(fb);
        } catch (_) {}
        profile = fb;
      }
    } catch (_) {
      profile ??= {'id': user!.id, 'prenom': (user!.email ?? 'Moi').split('@').first, 'avatar': 'e:🌸'};
    }
    try {
      final r = await sb.rpc('salon_is_admin');
      isAdmin = r == true;
    } catch (_) {
      isAdmin = false;
    }
    await _loadEchangeJoin();
    await loadVendeur();
    notifyListeners();
    refreshCounters();
  }

  // ---------- Groupe Échange : on ne voit que les messages écrits après son arrivée ----------
  Future<void> _loadEchangeJoin() async {
    final u = user;
    if (u == null) {
      echangeJoinedAt = null;
      return;
    }
    DateTime? d;
    try {
      final r = await sb.from('echange_members').select('joined_at').eq('user_id', u.id).maybeSingle();
      if (r != null) d = DateTime.tryParse('${r['joined_at']}');
    } catch (_) {}
    if (d == null) {
      final saved = _prefs?.getString('zk_echange_join_${u.id}');
      if (saved != null) d = DateTime.tryParse(saved);
    }
    echangeJoinedAt = d;
  }

  /// Appelé à l'ouverture du groupe : la première fois, on note l'heure d'arrivée de la personne.
  Future<DateTime> joinEchange() async {
    final known = echangeJoinedAt;
    if (known != null) return known;
    final u = user!;
    await _loadEchangeJoin();
    final again = echangeJoinedAt;
    if (again != null) return again;
    DateTime? d;
    try {
      await sb.from('echange_members').insert({'user_id': u.id});
    } catch (_) {}
    try {
      final r = await sb.from('echange_members').select('joined_at').eq('user_id', u.id).maybeSingle();
      if (r != null) d = DateTime.tryParse('${r['joined_at']}');
    } catch (_) {}
    d ??= DateTime.now().toUtc();
    try {
      await _prefs?.setString('zk_echange_join_${u.id}', d.toUtc().toIso8601String());
    } catch (_) {}
    echangeJoinedAt = d;
    return d;
  }

  DateTime? _echangeSince() {
    final j = echangeJoinedAt;
    final u = user;
    if (j == null || u == null) return null;
    final seenS = _prefs?.getString('zk_echange_seen_${u.id}');
    final seen = seenS == null ? null : DateTime.tryParse(seenS);
    if (seen != null && seen.isAfter(j)) return seen;
    return j;
  }

  Future<void> markEchangeSeen() async {
    final u = user;
    if (u == null) return;
    try {
      await _prefs?.setString('zk_echange_seen_${u.id}', DateTime.now().toUtc().toIso8601String());
    } catch (_) {}
    if (unreadEchange != 0) {
      unreadEchange = 0;
      notifyListeners();
    }
  }

  // ---------- Compte vendeur ----------
  Future<void> loadVendeur() async {
    final u = user;
    if (u == null) {
      vendeur = null;
      return;
    }
    try {
      final r = await sb.from('vendeurs').select().eq('user_id', u.id).maybeSingle();
      vendeur = r == null ? null : Map<String, dynamic>.from(r);
    } catch (_) {
      vendeur = null;
    }
    notifyListeners();
  }

  Future<void> refreshCounters() async {
    if (user == null) return;
    try {
      final admin = isAdmin;
      final salonUnread = await sb.from('salon_messages').select('id').filter('read_at', 'is', 'null').eq('from_admin', !admin);
      var n = (salonUnread as List).length;
      final adUnread = await sb.from('messages').select('id').filter('read_at', 'is', 'null').neq('sender_id', user!.id);
      n += (adUnread as List).length;
      unreadMessages = n;
      final seen = _prefs?.getString('zk_notif_seen') ?? '';
      final notifs = await sb.from('salon_notifications').select('created_at').order('created_at', ascending: false).limit(50);
      unreadNotifs = (notifs as List).where((e) => '${e['created_at']}'.compareTo(seen) > 0).length;
      final since = _echangeSince();
      if (since != null && chatOpen == 0) {
        try {
          final er = await sb.from('echange_messages').select('id').neq('sender_id', user!.id).gt('created_at', since.toUtc().toIso8601String()).limit(99);
          unreadEchange = (er as List).length;
        } catch (_) {}
      }
      notifyListeners();
    } catch (_) {}
    try {
      await _checkAlerts();
    } catch (_) {}
  }

  String _mediaLabel(String type) {
    if (type == 'audio') return '🎤 ${tr('Message vocal')}';
    if (type == 'video') return '🎬 ${tr('Vidéo')}';
    return '📷 Photo';
  }

  String _plain(String raw) {
    if (raw.isEmpty || raw[0] != zkTag) return raw;
    final parts = raw.substring(1).split(zkTag);
    if (parts.length < 4) return parts.join();
    return parts.sublist(3).join();
  }

  /// Cherche les nouveaux messages / annonces et les affiche dans la barre du téléphone, avec le son choisi.
  Future<void> _checkAlerts() async {
    final u = user;
    if (u == null) return;
    final found = <_Alert>[];
    try {
      final r = await sb.from('salon_messages').select('id,texte,created_at').filter('read_at', 'is', 'null').eq('from_admin', !isAdmin).order('created_at', ascending: false).limit(15);
      for (final m in (r as List)) {
        final t = _plain('${m['texte'] ?? ''}');
        found.add(_Alert('s${m['id']}', 'msg', isAdmin ? tr('Message d’une cliente') : tr('Message du salon'), t.isEmpty ? '📷' : t));
      }
    } catch (_) {}
    try {
      final r = await sb.from('messages').select('id,texte,type,pub_titre,created_at').filter('read_at', 'is', 'null').neq('sender_id', u.id).order('created_at', ascending: false).limit(15);
      for (final m in (r as List)) {
        final t = _plain('${m['texte'] ?? ''}');
        found.add(_Alert('p${m['id']}', 'msg', '${tr('Annonce')} · ${m['pub_titre'] ?? ''}', t.isEmpty ? _mediaLabel('${m['type']}') : t));
      }
    } catch (_) {}
    try {
      final r = await sb.from('salon_notifications').select('id,titre,texte,created_at').order('created_at', ascending: false).limit(10);
      for (final m in (r as List)) {
        found.add(_Alert('n${m['id']}', 'notif', '${m['titre'] ?? 'Zoneck'}', '${m['texte'] ?? ''}'));
      }
    } catch (_) {}
    try {
      final since = _echangeSince();
      final r = since == null
          ? <dynamic>[]
          : await sb.from('echange_messages').select('id,sender_id,sender_name,texte,type,created_at').gt('created_at', since.toUtc().toIso8601String()).order('created_at', ascending: false).limit(10);
      for (final m in r) {
        if ('${m['sender_id']}' == u.id) {
          _pushed.add('e${m['id']}');
          continue;
        }
        final t = _plain('${m['texte'] ?? ''}');
        found.add(_Alert('e${m['id']}', 'echange', '${tr('Échange Zoneck')} · ${m['sender_name'] ?? ''}', t.isEmpty ? _mediaLabel('${m['type']}') : t));
      }
    } catch (_) {}
    if (!_baseline) {
      // première lecture : on mémorise l'existant sans faire de bruit
      for (final a in found) {
        _pushed.add(a.key);
      }
      _baseline = true;
      return;
    }
    final fresh = <_Alert>[];
    for (final a in found) {
      if (_pushed.add(a.key)) fresh.add(a);
    }
    final show = <_Alert>[];
    for (final a in fresh) {
      if (a.kind == 'msg' && !notifMessages) continue;
      if (a.kind == 'echange' && !notifEchange) continue;
      if (a.kind != 'notif' && foreground && chatOpen > 0) continue;
      show.add(a);
    }
    if (show.isEmpty) return;
    if (show.length > 3) {
      await Notifier.show(key: 'resume-${DateTime.now().millisecondsSinceEpoch}', title: 'Zoneck', body: '${show.length} ${tr('nouveaux messages')}', soundId: soundId);
    } else {
      for (final a in show) {
        await Notifier.show(key: a.key, title: a.title, body: a.body, soundId: soundId);
      }
    }
  }

  Future<void> markNotifsSeen() async {
    try {
      await _prefs?.setString('zk_notif_seen', DateTime.now().toUtc().toIso8601String());
    } catch (_) {}
    unreadNotifs = 0;
    notifyListeners();
  }

  // ---------- Compte ----------
  Future<void> signIn(String pseudo, String pw) async {
    final mail = toMail(pseudo);
    if (mail.isEmpty) throw Exception('Pseudo invalide.');
    await sb.auth.signInWithPassword(email: mail, password: pw);
    await loadMe();
  }

  Future<void> signUp({required String pseudo, required String nom, required String tel, required String pw, required String avatar}) async {
    final mail = toMail(pseudo);
    if (mail.isEmpty) throw Exception('Pseudo invalide.');
    _authBusy = true;
    try {
      final res = await sb.auth.signUp(email: mail, password: pw);
      var u = res.user;
      if (res.session == null) {
        final r2 = await sb.auth.signInWithPassword(email: mail, password: pw);
        u = r2.user;
      }
      if (u != null) {
        try {
          await sb.from('profiles').upsert({
            'id': u.id,
            'prenom': pseudo.trim(),
            'nom': nom.trim(),
            'avatar': avatar,
            'telephone': tel.trim(),
          });
        } catch (_) {}
      }
    } finally {
      _authBusy = false;
    }
    await loadMe();
  }

  Future<void> saveProfile({required String nom, required String tel, required String avatar}) async {
    final row = {
      'id': user!.id,
      'prenom': prenom,
      'nom': nom.trim(),
      'avatar': avatar,
      'telephone': tel.trim(),
    };
    await sb.from('profiles').upsert(row);
    await loadMe();
  }

  Future<void> signOut() async {
    try {
      await sb.auth.signOut();
    } catch (_) {}
    user = null;
    profile = null;
    isAdmin = false;
    unreadMessages = 0;
    unreadNotifs = 0;
    unreadEchange = 0;
    echangeJoinedAt = null;
    vendeur = null;
    _pushed.clear();
    _baseline = false;
    notifyListeners();
  }

  @override
  void dispose() {
    _poll?.cancel();
    super.dispose();
  }
}

final AppState app = AppState();
