import 'package:supabase_flutter/supabase_flutter.dart';
import 'i18n.dart';

SupabaseClient get sb => Supabase.instance.client;

const _accents = {
  'à': 'a', 'â': 'a', 'ä': 'a', 'á': 'a', 'ã': 'a', 'ç': 'c', 'é': 'e', 'è': 'e', 'ê': 'e', 'ë': 'e',
  'î': 'i', 'ï': 'i', 'í': 'i', 'ô': 'o', 'ö': 'o', 'ó': 'o', 'õ': 'o', 'ù': 'u', 'û': 'u', 'ü': 'u',
  'ú': 'u', 'ÿ': 'y', 'ñ': 'n',
};

/// Même règle que le site : un pseudo devient une adresse « pseudo@zoneck.app ».
String toMail(String input) {
  var u = input.trim().toLowerCase();
  if (u.contains('@')) return u;
  final b = StringBuffer();
  for (final ch in u.split('')) {
    b.write(_accents[ch] ?? ch);
  }
  u = b.toString().replaceAll(RegExp(r'[^a-z0-9._-]+'), '');
  return u.isEmpty ? '' : '$u@zoneck.app';
}

String errText(Object e) {
  if (e is AuthException) {
    final m = e.message.toLowerCase();
    if (m.contains('invalid login')) return 'Pseudo ou mot de passe incorrect.';
    if (m.contains('already')) return 'Ce pseudo est déjà utilisé.';
    if (m.contains('password')) return 'Mot de passe trop court (6 caractères minimum).';
    return e.message;
  }
  if (e is PostgrestException) return e.message;
  if (e is StorageException) return e.message;
  final s = e.toString();
  if (s.startsWith('Exception: ')) return s.substring(11);
  if (s.contains('SocketException') || s.contains('ClientException')) {
    return 'Connexion interrompue. Vérifiez votre internet et réessayez.';
  }
  return s;
}

const _mois = [
  'janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'
];
const _jours = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche'];
const _monthsEn = [
  'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'
];
const _daysEn = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

bool get _en => currentLang == 'en';

String two(int n) => n.toString().padLeft(2, '0');

DateTime? parseDate(dynamic v) {
  if (v == null) return null;
  return DateTime.tryParse(v.toString())?.toLocal();
}

String hhmm(dynamic v) {
  final d = parseDate(v);
  return d == null ? '' : '${two(d.hour)}:${two(d.minute)}';
}

String dateLong(dynamic v) {
  final d = parseDate(v);
  if (d == null) return '';
  if (_en) return '${_daysEn[d.weekday - 1]} ${d.day} ${_monthsEn[d.month - 1]} at ${two(d.hour)}:${two(d.minute)}';
  return '${_jours[d.weekday - 1]} ${d.day} ${_mois[d.month - 1]} à ${two(d.hour)}h${two(d.minute)}';
}

String dateDay(dynamic v) {
  final d = parseDate(v);
  if (d == null) return '';
  return '${d.day} ${_en ? _monthsEn[d.month - 1] : _mois[d.month - 1]} ${d.year}';
}

String dateShort(dynamic v) {
  final d = parseDate(v);
  if (d == null) return '';
  final now = DateTime.now();
  if (d.year == now.year && d.month == now.month && d.day == now.day) return hhmm(v);
  return '${two(d.day)}/${two(d.month)}';
}

String dayLabel(dynamic v) {
  final d = parseDate(v);
  if (d == null) return '';
  final now = DateTime.now();
  final t = DateTime(now.year, now.month, now.day);
  final x = DateTime(d.year, d.month, d.day);
  final diff = t.difference(x).inDays;
  if (diff == 0) return tr("Aujourd'hui");
  if (diff == 1) return tr('Hier');
  return '${d.day} ${_en ? _monthsEn[d.month - 1] : _mois[d.month - 1]} ${d.year}';
}

String money(num n) {
  final s = n.round().toString();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write(' ');
    b.write(s[i]);
  }
  return b.toString();
}
