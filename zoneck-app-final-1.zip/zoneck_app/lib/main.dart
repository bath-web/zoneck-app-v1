import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'core/app_state.dart';
import 'core/config.dart';
import 'core/notifier.dart';
import 'core/theme.dart';
import 'screens/auth.dart';
import 'screens/shell.dart';
import 'screens/splash.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseKey);
  await Notifier.init();
  await app.init();
  runApp(const ZoneckApp());
}

class ZoneckApp extends StatelessWidget {
  const ZoneckApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final light = app.theme == 'blanc';
        SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: light ? Brightness.dark : Brightness.light,
          systemNavigationBarColor: (palettes[app.theme] ?? palettes['violet']!).bg2,
          systemNavigationBarIconBrightness: light ? Brightness.dark : Brightness.light,
        ));
        return MaterialApp(
          // changer la langue relance l'écran d'accueil avec les nouveaux textes
          key: ValueKey(app.lang),
          title: 'Zoneck',
          builder: (context, child) {
            final mq = MediaQuery.of(context);
            return MediaQuery(
              data: mq.copyWith(textScaler: mq.textScaler.clamp(minScaleFactor: 0.85, maxScaleFactor: 1.25)),
              child: child ?? const SizedBox.shrink(),
            );
          },
          debugShowCheckedModeBanner: false,
          theme: buildTheme(app.theme),
          locale: Locale(app.lang),
          supportedLocales: const [Locale('fr'), Locale('en')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          // Animation d'entrée, puis : pas connecté = page « Se connecter », sinon on entre directement.
          // Déjà connecté (session gardée sur le téléphone) : on entre directement.
          home: SplashGate(child: app.loggedIn ? const Shell() : const AuthPage(root: true)),
        );
      },
    );
  }
}
