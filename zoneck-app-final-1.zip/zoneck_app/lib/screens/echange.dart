import 'dart:async';
import 'package:flutter/material.dart' hide Text;
import 'package:supabase_flutter/supabase_flutter.dart' show PostgrestException;
import '../core/api.dart';
import '../core/app_state.dart';
import '../core/theme.dart';
import '../widgets/chat_panel.dart';
import '../widgets/common.dart';
import '../widgets/zk_text.dart';

/// « Échanger entre membres » : le groupe de discussion de toutes les membres Zoneck,
/// qui fonctionne comme un groupe WhatsApp. Chaque membre ne voit que les messages
/// écrits depuis son arrivée dans le groupe.
class EchangePage extends StatefulWidget {
  const EchangePage({super.key});
  @override
  State<EchangePage> createState() => _EchangePageState();
}

class _EchangePageState extends State<EchangePage> {
  List<Map<String, dynamic>> _msgs = [];
  Timer? _t;
  DateTime? _since;
  bool _missing = false, _loaded = false;

  @override
  void initState() {
    super.initState();
    _start();
    _t = Timer.periodic(const Duration(seconds: 4), (_) => _load());
  }

  @override
  void dispose() {
    _t?.cancel();
    Future.microtask(app.markEchangeSeen);
    super.dispose();
  }

  Future<void> _start() async {
    try {
      _since = await app.joinEchange();
    } catch (_) {
      _since = DateTime.now().toUtc();
    }
    await _load();
  }

  Future<void> _load() async {
    final since = _since;
    if (since == null) return;
    try {
      final r = await sb
          .from('echange_messages')
          .select()
          .gte('created_at', since.toUtc().toIso8601String())
          .order('created_at', ascending: false)
          .limit(300);
      final list = List<Map<String, dynamic>>.from(r as List).reversed.toList();
      if (!mounted) return;
      setState(() {
        _msgs = list;
        _missing = false;
        _loaded = true;
      });
      app.markEchangeSeen();
    } on PostgrestException catch (e) {
      final m = e.message.toLowerCase();
      if (mounted && (m.contains('echange_messages') || m.contains('schema cache') || e.code == '42P01' || e.code == 'PGRST205')) {
        setState(() {
          _missing = true;
          _loaded = true;
        });
      }
    } catch (_) {}
  }

  Future<void> _insert({String? texte, String? media, String? type, ChatItem? reply}) async {
    await sb.from('echange_messages').insert({
      'sender_id': app.user!.id,
      'sender_name': app.prenom,
      'sender_avatar': app.avatar,
      'texte': texte ?? '',
      if (media != null) 'media': media,
      if (type != null) 'type': type,
      if (reply != null) 'reply_to': reply.id,
      if (reply != null) 'reply_name': replyAuthor(reply, 'Membre'),
      if (reply != null) 'reply_text': reply.preview,
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final me = app.user?.id;
    final items = [
      for (final m in _msgs)
        ChatItem(
          id: '${m['id']}',
          mine: '${m['sender_id']}' == me,
          text: '${m['texte'] ?? ''}',
          createdAt: m['created_at']?.toString(),
          media: m['media'] as String?,
          type: m['type'] as String?,
          senderName: m['sender_name'] as String?,
          senderAvatar: m['sender_avatar'] as String?,
          replyName: m['reply_name'] as String?,
          replyText: m['reply_text'] as String?,
          canDeleteAll: '${m['sender_id']}' == me || app.isAdmin,
        ),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          Container(
            width: 36,
            height: 36,
            alignment: Alignment.center,
            decoration: BoxDecoration(shape: BoxShape.circle, color: p.accent),
            child: const Text('👑', style: TextStyle(fontSize: 18)),
          ),
          const SizedBox(width: 10),
          const Expanded(
            child: Text('Échanger entre membres', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          ),
        ]),
      ),
      body: _missing
          ? const Center(child: Empty('Le groupe Échange sera bientôt disponible.\nRevenez un peu plus tard 💜', icon: Icons.groups_rounded))
          : !_loaded
              ? const Center(child: CircularProgressIndicator())
              : ChatPanel(
                  items: items,
                  group: true,
                  hiddenScope: '${me}_echange',
                  peerLabel: 'Membre',
                  mediaPrefix: 'echange',
                  emptyText: 'Soyez la première à écrire dans le groupe 👋',
                  onMedia: (m, reply) async {
                    await _insert(media: m.url, type: m.type, reply: reply);
                    await _load();
                  },
                  onSend: (text, reply) async {
                    await _insert(texte: text, reply: reply);
                    await _load();
                  },
                  onDeleteAll: (item) async {
                    await sb.from('echange_messages').delete().eq('id', item.id);
                    await _load();
                  },
                ),
    );
  }
}
