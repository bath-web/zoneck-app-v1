import 'package:flutter/material.dart' hide Text;
import 'package:url_launcher/url_launcher.dart';
import '../core/app_state.dart';
import '../core/config.dart';
import '../core/content.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'booking.dart';
import 'messages.dart';
import 'vendeur.dart';
import '../widgets/zk_text.dart';
import '../core/i18n.dart';

class ContactPage extends StatelessWidget {
  const ContactPage({super.key});

  Future<void> _open(BuildContext context, String url) async {
    try {
      final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      if (!ok && context.mounted) toast(context, 'Impossible d’ouvrir.', error: true);
    } catch (_) {
      if (context.mounted) toast(context, 'Impossible d’ouvrir.', error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    Widget info(IconData icon, String label, String value, String? url) => ZkCard(
          onTap: value.isEmpty || url == null ? null : () => _open(context, url),
          child: Row(children: [
            Icon(icon, color: p.accent),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(label, style: TextStyle(color: p.muted, fontSize: 12.5)),
                Text(value.isEmpty ? 'À venir' : value, style: TextStyle(color: p.text, fontWeight: FontWeight.w700, fontSize: 15)),
              ]),
            ),
          ]),
        );
    return Scaffold(
      appBar: AppBar(title: const Text('Contact & salons')),
      body: ListenableBuilder(
        listenable: app.content,
        builder: (context, _) => ListView(padding: const EdgeInsets.only(bottom: 30), children: [
          const SectionTitle('Parlons-en', sub: 'Une question ? Notre équipe vous répond.'),
          info(Icons.phone_rounded, 'Téléphone', contactTel, 'tel:$contactTel'),
          info(Icons.mail_rounded, 'E-mail', contactEmail, 'mailto:$contactEmail'),
          info(Icons.chat_rounded, 'WhatsApp', contactWhatsapp, 'https://wa.me/$contactWhatsapp'),
          info(Icons.place_rounded, 'Adresse', contactAdresse, null),
          const SectionTitle('Nos salons'),
          for (final s in app.content.salons) _SalonCard(s),
          const VendeursSection(),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: FilledButton.icon(onPressed: () => openBooking(context), icon: const Icon(Icons.event_available_rounded), label: const Text('Prendre rendez-vous')),
          ),
        ]),
      ),
    );
  }
}

class _SalonCard extends StatelessWidget {
  final Salon s;
  const _SalonCard(this.s);

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return ZkCard(
      padding: EdgeInsets.zero,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (s.photos.isNotEmpty)
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
            child: SizedBox(
              height: 210,
              width: double.infinity,
              child: s.photos.length == 1
                  ? ZkImage(s.photos.first, alignment: Alignment.topCenter, cacheWidth: 900)
                  : Row(children: [for (final ph in s.photos) Expanded(child: ZkImage(ph, alignment: Alignment.topCenter, cacheWidth: 600))]),
            ),
          ),
        Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('📍 ${tr('Salon')} ${salonLabel(s.nom)}', style: TextStyle(color: p.text, fontWeight: FontWeight.w800, fontSize: 17)),
            if (s.heures.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 3), child: Text('${tr('Ouvert')} · ${s.heures}', style: TextStyle(color: p.muted))),
            if (s.patronne.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 3), child: Text('${tr('Responsable')} : ${s.patronne}', style: TextStyle(color: p.muted))),
            if (s.adresse.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 3), child: Text(s.adresse, style: TextStyle(color: p.muted))),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: FilledButton(onPressed: () => openBooking(context, salon: s.cle), child: const Text('Réserver ici'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton(onPressed: () => openSalonChat(context, s.cle), child: const Text('Écrire'))),
            ]),
          ]),
        ),
      ]),
    );
  }
}
