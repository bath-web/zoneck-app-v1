import 'package:flutter/material.dart' hide Text;
import '../core/api.dart';
import '../core/app_state.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'auth.dart';
import 'avis.dart';
import 'booking.dart';
import 'contact.dart';
import 'pubs.dart';
import '../widgets/zk_text.dart';
import '../core/i18n.dart';

class HomePage extends StatefulWidget {
  final void Function(int) onGo;
  const HomePage({super.key, required this.onGo});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Map<String, dynamic>> _avis = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await sb.from('avis').select('*,profiles(prenom,nom,avatar)').order('created_at', ascending: false).limit(6);
      if (mounted) setState(() => _avis = List<Map<String, dynamic>>.from(r as List));
    } catch (_) {}
  }

  void _push(Widget w) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => w));

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final shortcuts = <(IconData, String, VoidCallback)>[
      (Icons.photo_library_rounded, 'Réalisations', () => widget.onGo(1)),
      (Icons.content_cut_rounded, 'Catalogue', () => widget.onGo(2)),
      (Icons.campaign_rounded, 'Publicités', () => _push(const PubsPage())),
      (Icons.star_rounded, 'Avis', () => _push(const AvisPage())),
      (Icons.place_rounded, 'Nos salons', () => _push(const ContactPage())),
      (Icons.chat_bubble_rounded, 'Messages', () => widget.onGo(3)),
    ];
    return RefreshIndicator(
      color: p.accent,
      onRefresh: () async {
        await app.content.load();
        await _load();
      },
      child: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          // Bandeau principal
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: Stack(
                children: [
                  AspectRatio(
                    aspectRatio: 0.92,
                    child: Image.asset('assets/images/hero.jpg', fit: BoxFit.cover, alignment: Alignment.topCenter, cacheWidth: 1000,
                        errorBuilder: (_, __, ___) => Container(color: p.bg2)),
                  ),
                  Positioned.fill(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.transparent, p.bg2.withAlpha(120), p.bg2.withAlpha(245)],
                          stops: const [.30, .62, 1],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 18,
                    right: 18,
                    bottom: 18,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text.rich(
                          TextSpan(children: [
                            TextSpan(text: tr('Fais de tes cheveux ')),
                            TextSpan(text: tr('ta signature'), style: TextStyle(color: p.accent)),
                            const TextSpan(text: '.'),
                          ]),
                          style: TextStyle(fontSize: 27, height: 1.15, fontWeight: FontWeight.w900, color: p.text),
                        ),
                        const SizedBox(height: 6),
                        Text('Sois belle. Sois inoubliable. Plus qu’une coiffure, une attitude.',
                            style: TextStyle(color: p.muted, fontSize: 14, height: 1.35)),
                        const SizedBox(height: 14),
                        Row(children: [
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: () => openBooking(context),
                              icon: const Icon(Icons.event_available_rounded, size: 20),
                              label: const Text('Prendre rendez-vous'),
                            ),
                          ),
                        ]),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            child: Wrap(spacing: 8, runSpacing: 8, children: [
              for (final b in ['✂️ Style des experts', '🌿 Produits bio', '📅 Sur rendez-vous'])
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                  decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(20), border: Border.all(color: p.line)),
                  child: Text(b, style: TextStyle(color: p.text, fontSize: 12.5, fontWeight: FontWeight.w600)),
                ),
            ]),
          ),
          // Raccourcis
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
            child: GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 1.15,
              children: [
                for (final s in shortcuts)
                  Material(
                    color: p.card,
                    borderRadius: BorderRadius.circular(18),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(18),
                      onTap: s.$3,
                      child: Container(
                        decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: p.line)),
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(s.$1, color: p.accent, size: 28),
                          const SizedBox(height: 6),
                          Text(s.$2, style: TextStyle(color: p.text, fontWeight: FontWeight.w700, fontSize: 12.5)),
                        ]),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          SectionTitle(
            'Avis de nos clientes',
            sub: 'Elles nous font confiance.',
            trailing: TextButton(onPressed: () => _push(const AvisPage()), child: const Text('Tout voir')),
          ),
          if (_avis.isEmpty) ...[
            for (final a in const [
              ('Sophie M.', 'Cliente fidèle', 'Une équipe formidable, mes cheveux n’ont jamais été aussi beaux !'),
              ('Camille D.', 'Cliente', 'Produits bio, résultat éclatant. Je recommande à 100 %.'),
              ('Laura B.', 'Cliente', 'Un accueil chaleureux et un vrai travail d’artiste.'),
            ])
              AvisCard.fixed(name: a.$1, role: a.$2, text: a.$3),
          ] else
            for (final a in _avis) AvisCard(a),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
            child: OutlinedButton.icon(
              onPressed: () async {
                if (!await requireLogin(context)) return;
                if (!context.mounted) return;
                await addAvis(context);
                _load();
              },
              icon: const Icon(Icons.rate_review_rounded),
              label: const Text('Donner mon avis'),
            ),
          ),
        ],
      ),
    );
  }
}
