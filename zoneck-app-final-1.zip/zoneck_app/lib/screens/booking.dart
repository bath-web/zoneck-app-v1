import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart' show FileOptions;
import '../core/api.dart';
import '../core/app_state.dart';
import '../core/config.dart';
import '../core/content.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'auth.dart';
import '../widgets/zk_text.dart';
import '../core/i18n.dart';

String _uuid() {
  final r = Random.secure();
  final b = List<int>.generate(16, (_) => r.nextInt(256));
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  String h(int i) => b[i].toRadixString(16).padLeft(2, '0');
  return '${h(0)}${h(1)}${h(2)}${h(3)}-${h(4)}${h(5)}-${h(6)}${h(7)}-${h(8)}${h(9)}-${h(10)}${h(11)}${h(12)}${h(13)}${h(14)}${h(15)}';
}

/// Ouvre le formulaire de rendez-vous (avec, si on le souhaite, la coiffure et la photo du modèle choisi).
Future<void> openBooking(BuildContext context, {String? motif, String? photo, String? salon}) async {
  if (!await requireLogin(context)) return;
  if (!context.mounted) return;
  await sheet(context, BookingSheet(motif: motif, photo: photo, salon: salon));
}

class BookingSheet extends StatefulWidget {
  final String? motif, photo, salon;
  const BookingSheet({super.key, this.motif, this.photo, this.salon});
  @override
  State<BookingSheet> createState() => _BookingSheetState();
}

class _BookingSheetState extends State<BookingSheet> {
  final _nom = TextEditingController(text: app.prenom == '' ? '' : '${app.prenom} ${app.profile?['nom'] == 'Membre' ? '' : (app.profile?['nom'] ?? '')}'.trim());
  final _tel = TextEditingController(text: '${app.profile?['telephone'] ?? ''}');
  String? _salon, _motif;
  DateTime? _date;
  String? _photo;
  bool _busy = false;
  String? _err;
  final String _id = _uuid();

  @override
  void initState() {
    super.initState();
    _salon = widget.salon;
    _motif = widget.motif;
    _photo = widget.photo;
  }

  @override
  void dispose() {
    _nom.dispose();
    _tel.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: _date ?? now,
      firstDate: now,
      lastDate: now.add(const Duration(days: 180)),
      locale: const Locale('fr'),
    );
    if (d == null || !mounted) return;
    final t = await showTimePicker(
      context: context,
      initialTime: _date != null ? TimeOfDay.fromDateTime(_date!) : const TimeOfDay(hour: 10, minute: 0),
    );
    if (t == null) return;
    setState(() => _date = DateTime(d.year, d.month, d.day, t.hour, t.minute));
  }

  Future<String> _photoUrl() async {
    final ph = _photo;
    if (ph == null || ph.isEmpty) return '';
    Uint8List? bytes;
    if (ph.startsWith('asset:')) {
      final data = await rootBundle.load('assets/images/${ph.substring(6)}.jpg');
      bytes = data.buffer.asUint8List();
    } else if (ph.startsWith('data:')) {
      bytes = ZkImage.bytesOf(ph);
    } else {
      return ph.startsWith('http') ? ph : '';
    }
    if (bytes == null) return '';
    final uid = app.user!.id;
    final path = 'photos/$uid/$_id.jpg';
    try {
      await sb.storage.from('salon-media').uploadBinary(path, bytes,
          fileOptions: const FileOptions(contentType: 'image/jpeg', cacheControl: '3600', upsert: true));
    } catch (e) {
      if (!RegExp(r'exists|duplicate', caseSensitive: false).hasMatch(e.toString())) {
        throw Exception('${tr('La photo n’a pas pu être envoyée')} : ${errText(e)}');
      }
    }
    return sb.storage.from('salon-media').getPublicUrl(path);
  }

  Future<void> _send() async {
    setState(() => _err = null);
    if (_nom.text.trim().isEmpty) return setState(() => _err = 'Indiquez votre nom.');
    if (_tel.text.trim().length < 8) return setState(() => _err = 'Indiquez un numéro de téléphone valide.');
    if (_salon == null) return setState(() => _err = 'Choisissez le salon le plus proche.');
    if (_motif == null) return setState(() => _err = 'Choisissez la coiffure souhaitée.');
    if (_date == null) return setState(() => _err = 'Choisissez le jour et l’heure.');
    setState(() => _busy = true);
    try {
      final url = await _photoUrl();
      await sb.rpc('salon_book', params: {
        'p_id': _id,
        'p_salon': _salon,
        'p_nom': _nom.text.trim(),
        'p_tel': _tel.text.trim(),
        'p_motif': _motif,
        'p_date': _date!.toUtc().toIso8601String(),
        'p_photo': url,
      });
      app.refreshCounters();
      if (!mounted) return;
      final nav = Navigator.of(context);
      final msg = ScaffoldMessenger.of(context);
      nav.pop();
      msg.showSnackBar(SnackBar(
        content: Text('${tr('Rendez-vous enregistré pour le salon')} ${salonLabel(_salon ?? '')}. ${tr('Réponse dans vos messages.')}'),
        backgroundColor: context.pal.accent,
        duration: const Duration(seconds: 5),
      ));
    } catch (e) {
      if (mounted) setState(() => _err = errText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final motifs = [for (final c in app.content.coiffures) c.nom, 'Autre'];
    if (_motif != null && !motifs.contains(_motif)) motifs.insert(0, _motif!);
    final df = _date == null ? 'Choisir le jour et l’heure' : dateLong(_date!.toIso8601String());
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Center(child: Container(width: 42, height: 4, decoration: BoxDecoration(color: p.line, borderRadius: BorderRadius.circular(4)))),
          const SizedBox(height: 14),
          Text('Prendre rendez-vous', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: p.text)),
          const SizedBox(height: 14),
          if (_photo != null)
            Container(
              margin: const EdgeInsets.only(bottom: 14),
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: p.line)),
              child: Row(children: [
                ClipRRect(borderRadius: BorderRadius.circular(10), child: ZkImage(_photo, width: 60, height: 60, cacheWidth: 200)),
                const SizedBox(width: 12),
                Expanded(child: Text('Modèle choisi : la photo sera envoyée avec votre réservation.', style: TextStyle(color: p.muted, fontSize: 13))),
                IconButton(onPressed: () => setState(() => _photo = null), icon: const Icon(Icons.close_rounded)),
              ]),
            ),
          TextField(controller: _nom, textCapitalization: TextCapitalization.words, decoration: InputDecoration(labelText: tr('Votre nom'))),
          const SizedBox(height: 12),
          TextField(controller: _tel, keyboardType: TextInputType.phone, decoration: InputDecoration(labelText: tr('Numéro de téléphone'))),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _salon,
            isExpanded: true,
            dropdownColor: p.bg2,
            decoration: InputDecoration(labelText: tr('Lieu du rendez-vous')),
            hint: const Text('Choisissez le salon le plus proche'),
            items: [for (final s in bookingSalons) DropdownMenuItem(value: s, child: Text(salonLabel(s)))],
            onChanged: (v) => setState(() => _salon = v),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _motif,
            isExpanded: true,
            dropdownColor: p.bg2,
            decoration: InputDecoration(labelText: tr('Coiffure souhaitée')),
            items: [for (final m in motifs) DropdownMenuItem(value: m, child: Text(m))],
            onChanged: (v) => setState(() => _motif = v),
          ),
          const SizedBox(height: 12),
          InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: _pickDate,
            child: InputDecorator(
              decoration: InputDecoration(labelText: tr('Jour et heure'), suffixIcon: Icon(Icons.calendar_month_rounded)),
              child: Text(df, style: TextStyle(color: _date == null ? p.muted : p.text)),
            ),
          ),
          if (_err != null)
            Padding(
              padding: const EdgeInsets.only(top: 14),
              child: Text(_err!, style: const TextStyle(color: Color(0xFFFF9C9C), fontWeight: FontWeight.w600)),
            ),
          const SizedBox(height: 18),
          BusyButton(label: 'Réserver', busy: _busy, onPressed: _send, icon: Icons.check_circle_rounded),
        ],
      ),
    );
  }
}

/// Sélection d'une photo dans la galerie : renvoie une image réduite en « data:image/jpeg;base64 ».
Future<String?> pickImageData({int maxWidth = 900, int quality = 72}) async {
  final f = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: maxWidth.toDouble(), imageQuality: quality);
  if (f == null) return null;
  final bytes = await f.readAsBytes();
  return 'data:image/jpeg;base64,${base64Encode(bytes)}';
}
