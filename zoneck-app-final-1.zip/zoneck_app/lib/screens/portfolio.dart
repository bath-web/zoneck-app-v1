import 'package:flutter/material.dart' hide Text;
import 'package:video_player/video_player.dart';
import '../core/app_state.dart';
import '../core/content.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'booking.dart';
import '../widgets/zk_text.dart';

class PortfolioPage extends StatefulWidget {
  const PortfolioPage({super.key});
  @override
  State<PortfolioPage> createState() => _PortfolioPageState();
}

class _PortfolioPageState extends State<PortfolioPage> {
  String _f = 'Tout';

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return ListenableBuilder(
      listenable: app.content,
      builder: (context, _) {
        final all = app.content.mix;
        final types = app.content.types;
        if (!types.contains(_f)) _f = 'Tout';
        final items = _f == 'Tout' ? all : all.where((r) => r.type == _f).toList();
        return Column(children: [
          SizedBox(
            height: 58,
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
              scrollDirection: Axis.horizontal,
              itemCount: types.length,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) => ChoiceChip(
                label: Text(types[i]),
                selected: _f == types[i],
                onSelected: (_) => setState(() => _f = types[i]),
                showCheckmark: false,
                labelStyle: TextStyle(color: _f == types[i] ? p.ink : p.text, fontWeight: FontWeight.w700),
              ),
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 20),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: .78),
              itemCount: items.length,
              itemBuilder: (_, i) {
                final r = items[i];
                return GestureDetector(
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => Viewer(items: items, index: i))),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Stack(fit: StackFit.expand, children: [
                      r.video
                          ? Container(color: p.bg2, child: Icon(Icons.play_circle_fill_rounded, color: p.accent, size: 54))
                          : ZkImage(r.img, alignment: Alignment.topCenter, cacheWidth: 500),
                      Positioned(
                        left: 0,
                        right: 0,
                        bottom: 0,
                        child: Container(
                          padding: const EdgeInsets.fromLTRB(10, 22, 10, 9),
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Color(0xCC000000)]),
                          ),
                          child: Row(children: [
                            if (r.video) const Padding(padding: EdgeInsets.only(right: 4), child: Icon(Icons.videocam_rounded, color: Colors.white, size: 15)),
                            Expanded(child: Text(r.type, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12.5))),
                          ]),
                        ),
                      ),
                    ]),
                  ),
                );
              },
            ),
          ),
        ]);
      },
    );
  }
}

/// Visionneuse plein écran (glisser pour passer d'une photo à l'autre).
class Viewer extends StatefulWidget {
  final List<Realisation> items;
  final int index;
  const Viewer({super.key, required this.items, required this.index});
  @override
  State<Viewer> createState() => _ViewerState();
}

class _ViewerState extends State<Viewer> {
  late final PageController _c = PageController(initialPage: widget.index);
  late int _cur = widget.index;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.items[_cur];
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        title: Text(r.type, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
        actions: [Padding(padding: const EdgeInsets.only(right: 16), child: Center(child: Text('${_cur + 1}/${widget.items.length}', style: const TextStyle(color: Colors.white70))))],
      ),
      body: PageView.builder(
        controller: _c,
        itemCount: widget.items.length,
        onPageChanged: (i) => setState(() => _cur = i),
        itemBuilder: (_, i) {
          final it = widget.items[i];
          if (it.video) return _VideoPlayerView(asset: it.img, active: i == _cur);
          return InteractiveViewer(minScale: 1, maxScale: 4, child: Center(child: ZkImage(it.img, fit: BoxFit.contain, cacheWidth: 1400)));
        },
      ),
      bottomNavigationBar: r.video
          ? null
          : SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                child: FilledButton.icon(
                  onPressed: () => openBooking(context, motif: r.type, photo: r.img),
                  icon: const Icon(Icons.content_cut_rounded, size: 19),
                  label: const Text('Je veux cette coiffure'),
                ),
              ),
            ),
    );
  }
}

class _VideoPlayerView extends StatefulWidget {
  final String asset;
  final bool active;
  const _VideoPlayerView({required this.asset, required this.active});
  @override
  State<_VideoPlayerView> createState() => _VideoPlayerViewState();
}

class _VideoPlayerViewState extends State<_VideoPlayerView> {
  VideoPlayerController? _vc;

  @override
  void initState() {
    super.initState();
    final c = VideoPlayerController.asset(widget.asset);
    _vc = c;
    c.initialize().then((_) {
      if (!mounted) return;
      c.setLooping(true);
      if (widget.active) c.play();
      setState(() {});
    }).catchError((_) {});
  }

  @override
  void didUpdateWidget(covariant _VideoPlayerView old) {
    super.didUpdateWidget(old);
    final c = _vc;
    if (c == null || !c.value.isInitialized) return;
    widget.active ? c.play() : c.pause();
  }

  @override
  void dispose() {
    _vc?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = _vc;
    if (c == null || !c.value.isInitialized) return const Center(child: CircularProgressIndicator());
    return GestureDetector(
      onTap: () => setState(() {
        if (c.value.isPlaying) {
          c.pause();
        } else {
          c.play();
        }
      }),
      child: Center(
        child: Stack(alignment: Alignment.center, children: [
          AspectRatio(aspectRatio: c.value.aspectRatio, child: VideoPlayer(c)),
          if (!c.value.isPlaying) const Icon(Icons.play_circle_fill_rounded, color: Colors.white70, size: 72),
        ]),
      ),
    );
  }
}
