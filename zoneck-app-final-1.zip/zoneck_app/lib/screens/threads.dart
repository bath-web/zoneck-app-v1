import 'dart:async';
import 'package:flutter/material.dart' hide Text;
import '../core/api.dart';
import '../core/app_state.dart';
import '../widgets/chat_panel.dart';
import '../widgets/zk_text.dart';

// ------------------------------------------------------------------ Salon

class SalonThreadPage extends StatefulWidget {
  final String conversationId, title;
  const SalonThreadPage({super.key, required this.conversationId, required this.title});
  @override
  State<SalonThreadPage> createState() => _SalonThreadPageState();
}

class _SalonThreadPageState extends State<SalonThreadPage> {
  List<Map<String, dynamic>> _msgs = [];
  Timer? _t;
  bool _first = true;

  @override
  void initState() {
    super.initState();
    _load();
    _t = Timer.periodic(const Duration(seconds: 4), (_) => _load());
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final r = await sb.from('salon_messages').select().eq('conversation_id', widget.conversationId).order('created_at', ascending: true).limit(1000);
      final list = List<Map<String, dynamic>>.from(r as List);
      final changed = list.length != _msgs.length;
      if (!mounted) return;
      setState(() => _msgs = list);
      if (_first || changed) {
        _first = false;
        if (list.any((m) => m['read_at'] == null && m['from_admin'] != app.isAdmin)) {
          try {
            await sb.rpc('salon_read', params: {'p_conversation': widget.conversationId});
          } catch (_) {}
        }
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final items = [
      for (final m in _msgs)
        ChatItem(
          id: '${m['id']}',
          mine: (m['from_admin'] == true) == app.isAdmin,
          text: '${m['texte'] ?? ''}',
          createdAt: m['created_at']?.toString(),
        ),
    ];
    return Scaffold(
      appBar: AppBar(title: Text(widget.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
      body: ChatPanel(
        items: items,
        hiddenScope: '${app.user?.id}_salon',
        peerLabel: widget.title,
        onSend: (text, reply) async {
          final t = reply == null ? text : encodeReply(replyAuthor(reply, widget.title), reply.preview, text);
          await sb.rpc('salon_send', params: {'p_conversation': widget.conversationId, 'p_texte': t});
          await _load();
        },
      ),
    );
  }
}

// ------------------------------------------------------------------ Annonces

class PubThreadPage extends StatefulWidget {
  final String pubId, titre, sellerId, buyerId;
  const PubThreadPage({super.key, required this.pubId, required this.titre, required this.sellerId, required this.buyerId});
  @override
  State<PubThreadPage> createState() => _PubThreadPageState();
}

class _PubThreadPageState extends State<PubThreadPage> {
  List<Map<String, dynamic>> _msgs = [];
  Timer? _t;
  bool _first = true;

  @override
  void initState() {
    super.initState();
    _load();
    _t = Timer.periodic(const Duration(seconds: 4), (_) => _load());
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final r = await sb
          .from('messages')
          .select()
          .eq('pub_id', widget.pubId)
          .eq('seller_id', widget.sellerId)
          .eq('buyer_id', widget.buyerId)
          .order('created_at', ascending: true);
      final list = List<Map<String, dynamic>>.from(r as List);
      final changed = list.length != _msgs.length;
      if (!mounted) return;
      setState(() => _msgs = list);
      if (_first || changed) {
        _first = false;
        final ids = [for (final m in list) if (m['sender_id'] != app.user!.id && m['read_at'] == null) m['id']];
        if (ids.isNotEmpty) {
          try {
            await sb.from('messages').update({'read_at': DateTime.now().toUtc().toIso8601String()}).inFilter('id', ids);
          } catch (_) {}
        }
      }
    } catch (_) {}
  }

  Future<void> _insert({String? texte, String? media, String? type}) async {
    await sb.from('messages').insert({
      'pub_id': widget.pubId,
      'pub_titre': widget.titre,
      'seller_id': widget.sellerId,
      'buyer_id': widget.buyerId,
      'sender_id': app.user!.id,
      if (type != null) 'type': type,
      if (media != null) 'media': media,
      'texte': texte ?? '',
    });
  }

  @override
  Widget build(BuildContext context) {
    final peer = widget.sellerId == app.user?.id ? 'Acheteur' : 'Vendeur';
    final items = [
      for (final m in _msgs)
        ChatItem(
          id: '${m['id']}',
          mine: m['sender_id'] == app.user?.id,
          text: '${m['texte'] ?? ''}',
          createdAt: m['created_at']?.toString(),
          media: m['media'] as String?,
          type: m['type'] as String?,
        ),
    ];
    return Scaffold(
      appBar: AppBar(title: Text(widget.titre, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
      body: ChatPanel(
        items: items,
        hiddenScope: '${app.user?.id}_pub',
        peerLabel: peer,
        onMedia: (m, reply) async {
          final t = reply == null ? '' : encodeReply(replyAuthor(reply, peer), reply.preview, '');
          await _insert(texte: t, media: m.url, type: m.type);
          await _load();
        },
        onSend: (text, reply) async {
          final t = reply == null ? text : encodeReply(replyAuthor(reply, peer), reply.preview, text);
          await _insert(texte: t);
          await _load();
        },
      ),
    );
  }
}
