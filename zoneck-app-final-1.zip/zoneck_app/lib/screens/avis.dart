import 'package:flutter/material.dart' hide Text;
import '../core/api.dart';
import '../core/app_state.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'auth.dart';
import '../widgets/zk_text.dart';
import '../core/i18n.dart';

class AvisCard extends StatelessWidget {
  final Map<String, dynamic>? a;
  final String? sName, sRole, sText;
  const AvisCard(this.a, {super.key})
      : sName = null,
        sRole = null,
        sText = null;
  const AvisCard.fixed({super.key, required String name, required String role, required String text})
      : a = null,
        sName = name,
        sRole = role,
        sText = text;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final prof = (a?['profiles'] is Map) ? Map<String, dynamic>.from(a!['profiles']) : <String, dynamic>{};
    final name = sName ?? [prof['prenom'], prof['nom'] == 'Membre' ? null : prof['nom']].where((e) => e != null && '$e'.isNotEmpty).join(' ');
    final text = sText ?? '${a?['texte'] ?? ''}';
    final note = sName != null ? 5 : (a?['note'] is num ? (a!['note'] as num).round() : 5);
    return ZkCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        stars(note, size: 18),
        const SizedBox(height: 8),
        Text('« $text »', style: TextStyle(color: p.text, height: 1.4, fontSize: 14.5)),
        const SizedBox(height: 12),
        Row(children: [
          Avatar(avatar: sName != null ? null : '${prof['avatar'] ?? ''}', name: name.isEmpty ? 'C' : name, size: 34),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(name.isEmpty ? 'Cliente' : name, style: TextStyle(color: p.text, fontWeight: FontWeight.w700)),
              Text(sRole ?? dateLong(a?['created_at']).split(' à ').first, style: TextStyle(color: p.muted, fontSize: 12)),
            ]),
          ),
        ]),
      ]),
    );
  }
}

Future<void> addAvis(BuildContext context) async {
  await sheet(context, const _AvisForm());
}

class _AvisForm extends StatefulWidget {
  const _AvisForm();
  @override
  State<_AvisForm> createState() => _AvisFormState();
}

class _AvisFormState extends State<_AvisForm> {
  int _note = 5;
  bool _busy = false;
  final _txt = TextEditingController();

  Future<void> _send() async {
    if (_txt.text.trim().length < 3) return toast(context, 'Écrivez quelques mots.', error: true);
    setState(() => _busy = true);
    try {
      await sb.from('avis').insert({'user_id': app.user!.id, 'note': _note, 'texte': _txt.text.trim()});
      if (!mounted) return;
      Navigator.of(context).pop();
      toast(context, 'Merci pour votre avis ! ⭐');
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Donner mon avis', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: p.text)),
        const SizedBox(height: 14),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          for (var i = 1; i <= 5; i++)
            IconButton(
              iconSize: 40,
              onPressed: () => setState(() => _note = i),
              icon: Icon(i <= _note ? Icons.star_rounded : Icons.star_outline_rounded, color: const Color(0xFFFFC94D)),
            ),
        ]),
        TextField(controller: _txt, maxLines: 4, maxLength: 400, decoration: InputDecoration(labelText: tr('Votre avis'))),
        const SizedBox(height: 10),
        BusyButton(label: 'Publier', busy: _busy, onPressed: _send),
      ]),
    );
  }
}

class AvisPage extends StatefulWidget {
  const AvisPage({super.key});
  @override
  State<AvisPage> createState() => _AvisPageState();
}

class _AvisPageState extends State<AvisPage> {
  List<Map<String, dynamic>>? _rows;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await sb.from('avis').select('*,profiles(prenom,nom,avatar)').order('created_at', ascending: false).limit(60);
      if (mounted) setState(() => _rows = List<Map<String, dynamic>>.from(r as List));
    } catch (_) {
      if (mounted) setState(() => _rows = []);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Avis de nos clientes')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          if (!await requireLogin(context)) return;
          if (!context.mounted) return;
          await addAvis(context);
          _load();
        },
        icon: const Icon(Icons.edit_rounded),
        label: const Text('Mon avis'),
      ),
      body: _rows == null
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: _rows!.isEmpty
                  ? ListView(children: const [SizedBox(height: 80), Empty('Aucun avis pour le moment. Soyez la première !', icon: Icons.star_outline_rounded)])
                  : ListView(padding: const EdgeInsets.only(top: 12, bottom: 90), children: [for (final a in _rows!) AvisCard(a)]),
            ),
    );
  }
}
