import 'package:flutter/material.dart' hide Text;
import '../core/api.dart';
import '../core/app_state.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import '../widgets/zk_text.dart';
import '../core/i18n.dart';

/// Ouvre l'écran de connexion si besoin. Renvoie true si la personne est connectée.
Future<bool> requireLogin(BuildContext context) async {
  if (app.loggedIn) return true;
  final ok = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const AuthPage()));
  return ok == true && app.loggedIn;
}

class AuthPage extends StatefulWidget {
  /// true = écran d'accueil de l'application (pas de bouton retour).
  final bool root;
  const AuthPage({super.key, this.root = false});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  bool _open = false; // le menu déroulant (pseudo, mot de passe) est ouvert
  bool _signup = false, _busy = false, _hide = true;
  final _user = TextEditingController();
  final _tel = TextEditingController();
  final _pw = TextEditingController();
  String? _err;

  @override
  void dispose() {
    for (final c in [_user, _tel, _pw]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _go() async {
    setState(() => _err = null);
    final u = _user.text.trim();
    if (u.isEmpty || _pw.text.isEmpty) {
      setState(() => _err = 'Renseignez votre pseudo et votre mot de passe.');
      return;
    }
    if (_signup && _pw.text.length < 6) {
      setState(() => _err = 'Mot de passe : 6 caractères minimum.');
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() => _busy = true);
    try {
      if (_signup) {
        await app.signUp(pseudo: u, nom: u, tel: _tel.text, pw: _pw.text, avatar: 'e:🌸');
      } else {
        await app.signIn(u, _pw.text);
      }
      if (mounted && !widget.root) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) setState(() => _err = errText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _panel(Pal p) {
    return Container(
      key: ValueKey(_signup),
      margin: const EdgeInsets.only(top: 14),
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
      decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(22), border: Border.all(color: p.line)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        TextField(
          controller: _user,
          autofocus: true,
          autocorrect: false,
          textInputAction: TextInputAction.next,
          decoration: InputDecoration(labelText: tr('Pseudo'), prefixIcon: const Icon(Icons.person_outline_rounded)),
        ),
        if (_signup) ...[
          const SizedBox(height: 12),
          TextField(
            controller: _tel,
            keyboardType: TextInputType.phone,
            textInputAction: TextInputAction.next,
            decoration: InputDecoration(labelText: tr('Téléphone (facultatif)'), prefixIcon: const Icon(Icons.phone_outlined)),
          ),
        ],
        const SizedBox(height: 12),
        TextField(
          controller: _pw,
          obscureText: _hide,
          textInputAction: TextInputAction.done,
          onSubmitted: (_) => _go(),
          decoration: InputDecoration(
            labelText: tr('Mot de passe'),
            prefixIcon: const Icon(Icons.lock_outline_rounded),
            suffixIcon: IconButton(
              icon: Icon(_hide ? Icons.visibility_rounded : Icons.visibility_off_rounded),
              onPressed: () => setState(() => _hide = !_hide),
            ),
          ),
        ),
        if (_err != null)
          Padding(
            padding: const EdgeInsets.only(top: 14),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: const Color(0x33FF8A8A), borderRadius: BorderRadius.circular(12)),
              child: Text(_err!, style: const TextStyle(color: Color(0xFFFF9C9C), fontWeight: FontWeight.w600)),
            ),
          ),
        const SizedBox(height: 16),
        BusyButton(label: _signup ? 'Créer mon compte' : 'OK', busy: _busy, onPressed: _go),
        TextButton(
          onPressed: () => setState(() {
            _signup = !_signup;
            _err = null;
          }),
          child: Text(_signup ? 'J’ai déjà un compte : me connecter' : 'Pas de compte ? Créer un compte'),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      appBar: widget.root ? null : AppBar(title: const Text('Connexion')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 30),
          children: [
            SizedBox(height: widget.root ? 36 : 12),
            TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: 1),
              duration: const Duration(milliseconds: 700),
              curve: Curves.easeOutCubic,
              builder: (context, v, child) => Opacity(opacity: v, child: Transform.translate(offset: Offset(0, 18 * (1 - v)), child: child)),
              child: Column(children: [
                Center(child: ClipRRect(borderRadius: BorderRadius.circular(28), child: Image.asset('assets/images/logo.png', width: 110, height: 110))),
                const SizedBox(height: 12),
                Text('Zoneck', style: TextStyle(color: p.accent, fontSize: 32, fontWeight: FontWeight.w900, letterSpacing: -.5)),
                const SizedBox(height: 4),
                Text('Content de vous revoir', style: TextStyle(color: p.muted)),
              ]),
            ),
            const SizedBox(height: 40),
            FilledButton(
              onPressed: () => setState(() {
                _open = !_open;
                _err = null;
              }),
              style: FilledButton.styleFrom(minimumSize: const Size(0, 56)),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text('Se connecter', style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w800)),
                const SizedBox(width: 8),
                AnimatedRotation(turns: _open ? .5 : 0, duration: const Duration(milliseconds: 250), child: const Icon(Icons.keyboard_arrow_down_rounded, size: 26)),
              ]),
            ),
            AnimatedSize(
              duration: const Duration(milliseconds: 320),
              curve: Curves.easeOutCubic,
              alignment: Alignment.topCenter,
              child: _open ? _panel(p) : const SizedBox(width: double.infinity),
            ),
          ],
        ),
      ),
    );
  }
}
