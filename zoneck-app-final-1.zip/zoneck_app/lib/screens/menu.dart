import 'package:flutter/material.dart' hide Text;
import '../core/app_state.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'account.dart';
import 'admin.dart';
import 'auth.dart';
import 'avis.dart';
import 'booking.dart';
import 'contact.dart';
import 'echange.dart';
import 'notifications.dart';
import 'pubs.dart';
import 'settings.dart';
import 'vendeur.dart';
import '../widgets/zk_text.dart';

class MenuPage extends StatelessWidget {
  const MenuPage({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    void push(Widget w) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => w));
    Widget tile(IconData i, String t, String sub, VoidCallback f, {int badge = 0}) => ZkCard(
          onTap: f,
          margin: const EdgeInsets.fromLTRB(16, 0, 16, 10),
          child: Row(children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(color: p.accent.withAlpha(35), borderRadius: BorderRadius.circular(14)),
              child: RedBadge(count: badge, child: Icon(i, color: p.accent)),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(t, style: TextStyle(color: p.text, fontWeight: FontWeight.w800, fontSize: 15.5)),
                Text(sub, style: TextStyle(color: p.muted, fontSize: 12.5)),
              ]),
            ),
            Icon(Icons.chevron_right_rounded, color: p.muted),
          ]),
        );
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) => ListView(padding: const EdgeInsets.only(top: 10, bottom: 30), children: [
        ZkCard(
          onTap: () => push(const AccountPage()),
          child: Row(children: [
            app.loggedIn ? Avatar(avatar: app.avatar, name: app.prenom, size: 54) : Icon(Icons.account_circle_rounded, size: 54, color: p.muted),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(app.loggedIn ? app.prenom : 'Se connecter', style: TextStyle(color: p.text, fontWeight: FontWeight.w800, fontSize: 18)),
                Text(app.loggedIn ? 'Voir mon compte et mes rendez-vous' : 'Créez un compte ou connectez-vous', style: TextStyle(color: p.muted, fontSize: 12.5)),
              ]),
            ),
            Icon(Icons.chevron_right_rounded, color: p.muted),
          ]),
        ),
        tile(Icons.event_available_rounded, 'Prendre rendez-vous', 'Réservez dans le salon le plus proche', () => openBooking(context)),
        if (app.loggedIn) tile(Icons.notifications_rounded, 'Notifications', 'Réponses du salon, pubs, annonces', () => push(const NotificationsPage()), badge: app.unreadNotifs),
        tile(Icons.campaign_rounded, 'Publicité', 'Faites connaître vos produits', () => push(const PubsPage())),
        tile(Icons.star_rounded, 'Avis de nos clientes', 'Lisez et donnez votre avis', () => push(const AvisPage())),
        tile(Icons.place_rounded, 'Contact & salons', 'Nos adresses, horaires et contacts', () => push(const ContactPage())),
        tile(Icons.groups_rounded, 'Échanger entre membres', 'Le groupe où toutes les membres discutent', () async {
          if (await requireLogin(context) && context.mounted) push(const EchangePage());
        }, badge: app.unreadEchange),
        tile(Icons.storefront_rounded, app.vendeur == null ? 'Créer un compte vendeur' : 'Mon compte vendeur', app.vendeurActive ? 'Compte actif · publicités gratuites' : 'Vendez vos produits, publicités offertes', () async {
          if (await requireLogin(context) && context.mounted) push(const VendeurPage());
        }),
        tile(Icons.settings_rounded, 'Paramètres', 'Notifications, sons, langue, apparence', () => push(const SettingsPage())),
        if (app.isAdmin) tile(Icons.admin_panel_settings_rounded, 'Espace administrateur', 'Rendez-vous, publicités, annonces', () => push(const AdminPage())),
        const SizedBox(height: 24),
        Center(child: Text('@2026zoneck · version 1.2', style: TextStyle(color: p.muted, fontSize: 12))),
      ]),
    );
  }
}
