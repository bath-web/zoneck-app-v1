import 'package:flutter/material.dart' hide Text;
import '../core/app_state.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'account.dart';
import 'booking.dart';
import 'catalogue.dart';
import 'home.dart';
import 'menu.dart';
import 'messages.dart';
import 'notifications.dart';
import 'portfolio.dart';
import '../widgets/zk_text.dart';
import '../core/i18n.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => ShellState();
}

class ShellState extends State<Shell> {
  int _i = 0;

  void goTo(int i) => setState(() => _i = i);

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final pages = <Widget>[
      HomePage(onGo: goTo),
      const PortfolioPage(),
      const CataloguePage(),
      const MessagesPage(),
      const MenuPage(),
    ];
    const titles = ['Zoneck', 'Nos réalisations', 'Catalogue', 'Messages', 'Menu'];
    return PopScope(
      canPop: _i == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) goTo(0);
      },
      child: ListenableBuilder(
        listenable: app,
        builder: (context, _) => Scaffold(
          appBar: AppBar(
            titleSpacing: 16,
            title: _i == 0
                ? Text('Zoneck', style: TextStyle(color: p.accent, fontWeight: FontWeight.w900, fontSize: 26, letterSpacing: -.5))
                : Text(titles[_i], style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 20)),
            actions: [
              IconButton(
                tooltip: tr('Prendre rendez-vous'),
                icon: const Icon(Icons.event_available_rounded),
                onPressed: () => openBooking(context),
              ),
              if (app.loggedIn)
                IconButton(
                  tooltip: tr('Notifications'),
                  icon: RedBadge(count: app.unreadNotifs, child: const Icon(Icons.notifications_rounded)),
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NotificationsPage())),
                ),
              Padding(
                padding: const EdgeInsets.only(right: 12, left: 4),
                child: GestureDetector(
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AccountPage())),
                  child: app.loggedIn
                      ? Avatar(avatar: app.avatar, name: app.prenom, size: 34)
                      : Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                          decoration: BoxDecoration(color: p.accent, borderRadius: BorderRadius.circular(18)),
                          child: Text('Connexion', style: TextStyle(color: p.ink, fontWeight: FontWeight.w800, fontSize: 12.5)),
                        ),
                ),
              ),
            ],
          ),
          body: IndexedStack(index: _i, children: pages),
          bottomNavigationBar: BottomNavigationBar(
            currentIndex: _i,
            onTap: goTo,
            items: [
              BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: tr('Accueil')),
              BottomNavigationBarItem(icon: Icon(Icons.photo_library_rounded), label: tr('Réalisations')),
              BottomNavigationBarItem(icon: Icon(Icons.content_cut_rounded), label: tr('Catalogue')),
              BottomNavigationBarItem(
                icon: RedBadge(count: app.unreadMessages, child: const Icon(Icons.chat_bubble_rounded)),
                label: tr('Messages'),
              ),
              BottomNavigationBarItem(icon: RedBadge(count: app.unreadEchange, child: const Icon(Icons.menu_rounded)), label: tr('Menu')),
            ],
          ),
        ),
      ),
    );
  }
}
