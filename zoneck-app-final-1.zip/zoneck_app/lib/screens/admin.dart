import 'package:flutter/material.dart' hide Text;
import '../core/api.dart';
import '../core/app_state.dart';
import '../core/content.dart';
import '../core/chat_media.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import '../widgets/zk_text.dart';
import 'package:image_picker/image_picker.dart' show ImageSource;
import 'vendeur.dart';
import '../core/i18n.dart';

class AdminPage extends StatelessWidget {
  const AdminPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Administrateur'),
          bottom: const TabBar(isScrollable: true, tabAlignment: TabAlignment.start, tabs: [Tab(text: 'Rendez-vous'), Tab(text: 'Publicités'), Tab(text: 'Vendeurs'), Tab(text: 'Annonce')]),
        ),
        body: const TabBarView(children: [_Rdv(), _Pubs(), _Vendeurs(), _Broadcast()]),
      ),
    );
  }
}

class _Rdv extends StatefulWidget {
  const _Rdv();
  @override
  State<_Rdv> createState() => _RdvState();
}

class _RdvState extends State<_Rdv> {
  List<Map<String, dynamic>>? _rows;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await sb.from('salon_appointments').select().order('created_at', ascending: false).limit(200);
      if (mounted) setState(() => _rows = List<Map<String, dynamic>>.from(r as List));
    } catch (_) {
      if (mounted) setState(() => _rows = []);
    }
  }

  Future<void> _reply(Map<String, dynamic> r, bool confirm) async {
    final c = TextEditingController(text: confirm ? 'Votre rendez-vous est confirmé. À bientôt chez Zoneck !' : '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(confirm ? 'Confirmer le rendez-vous' : 'Répondre'),
        content: TextField(controller: c, maxLines: 4, decoration: InputDecoration(labelText: tr('Message à la cliente'))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Annuler')),
          TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Envoyer')),
        ],
      ),
    );
    if (ok != true || c.text.trim().isEmpty) return;
    try {
      await sb.rpc('salon_admin_reply', params: {'p_id': r['id'], 'p_texte': c.text.trim(), 'p_confirm': confirm});
      if (mounted) toast(context, 'Envoyé ✓');
      _load();
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    }
  }

  Future<void> _delete(Map<String, dynamic> r) async {
    try {
      await sb.from('salon_appointments').delete().eq('id', r['id']);
      setState(() => _rows!.remove(r));
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (_rows == null) return const Center(child: CircularProgressIndicator());
    return RefreshIndicator(
      onRefresh: _load,
      child: _rows!.isEmpty
          ? ListView(children: const [SizedBox(height: 80), Empty('Aucune demande.', icon: Icons.event_busy_rounded)])
          : ListView(padding: const EdgeInsets.only(top: 12, bottom: 24), children: [
              for (final r in _rows!)
                ZkCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      if ('${r['photo'] ?? ''}'.isNotEmpty)
                        Padding(padding: const EdgeInsets.only(right: 12), child: ClipRRect(borderRadius: BorderRadius.circular(10), child: ZkImage('${r['photo']}', width: 64, height: 64, cacheWidth: 200))),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('${r['nom']} · ${r['motif']}', style: TextStyle(color: p.text, fontWeight: FontWeight.w800)),
                          Text('${tr('Lieu')} : ${salonLabel('${r['salon']}')}', style: TextStyle(color: p.muted)),
                          Text(dateLong(r['appointment_date']), style: TextStyle(color: p.muted)),
                          Text('${tr('Tél.')} ${r['tel']}', style: TextStyle(color: p.muted)),
                          Text('${r['statut'] ?? ''}', style: TextStyle(color: p.accent, fontWeight: FontWeight.w700, fontSize: 12.5)),
                        ]),
                      ),
                    ]),
                    const SizedBox(height: 10),
                    Row(children: [
                      Expanded(child: FilledButton(onPressed: () => _reply(r, true), style: FilledButton.styleFrom(minimumSize: const Size(0, 42)), child: const Text('Confirmer'))),
                      const SizedBox(width: 8),
                      Expanded(child: OutlinedButton(onPressed: () => _reply(r, false), style: OutlinedButton.styleFrom(minimumSize: const Size(0, 42)), child: const Text('Répondre'))),
                      IconButton(onPressed: () => _delete(r), icon: const Icon(Icons.delete_outline_rounded)),
                    ]),
                  ]),
                ),
            ]),
    );
  }
}

class _Pubs extends StatefulWidget {
  const _Pubs();
  @override
  State<_Pubs> createState() => _PubsState();
}

class _PubsState extends State<_Pubs> {
  List<Map<String, dynamic>>? _rows;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await sb.from('pubs').select().order('created_at', ascending: false).limit(200);
      if (mounted) setState(() => _rows = List<Map<String, dynamic>>.from(r as List));
    } catch (_) {
      if (mounted) setState(() => _rows = []);
    }
  }

  Future<void> _decide(Map<String, dynamic> pub, String status) async {
    try {
      final weeks = (pub['semaines'] is num) ? (pub['semaines'] as num).toInt() : 1;
      final expire = status == 'active' && ((pub['montant'] ?? 0) as num) > 0 ? DateTime.now().add(Duration(days: 7 * (weeks < 1 ? 1 : weeks))).toUtc().toIso8601String() : null;
      List res;
      try {
        res = await sb.from('pubs').update({'status': status, 'expire_at': expire}).eq('id', pub['id']).select();
      } catch (_) {
        res = await sb.from('pubs').update({'status': status}).eq('id', pub['id']).select();
      }
      if (res.isEmpty) throw Exception('Modification refusée.');
      if (status != 'pending' && pub['user_id'] != null) {
        await sb.from('salon_notifications').insert({
          'user_id': pub['user_id'],
          'broadcast': false,
          'titre': status == 'active' ? 'Publicité en ligne' : 'Paiement non retrouvé',
          'texte': status == 'active' ? 'Votre publicité « ${pub['titre']} » est en ligne.' : 'Nous n’avons pas retrouvé le paiement de « ${pub['titre']} ». Contactez Zoneck.',
        });
      }
      if (mounted) toast(context, 'Décision enregistrée ✓');
      _load();
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    }
  }

  Future<void> _delete(Map<String, dynamic> pub) async {
    try {
      await sb.from('pubs').delete().eq('id', pub['id']);
      setState(() => _rows!.remove(pub));
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (_rows == null) return const Center(child: CircularProgressIndicator());
    return RefreshIndicator(
      onRefresh: _load,
      child: _rows!.isEmpty
          ? ListView(children: const [SizedBox(height: 80), Empty('Aucune publicité.', icon: Icons.campaign_outlined)])
          : ListView(padding: const EdgeInsets.only(top: 12, bottom: 24), children: [
              for (final pub in _rows!)
                ZkCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${pub['titre']}', style: TextStyle(color: p.text, fontWeight: FontWeight.w800, fontSize: 15.5)),
                    Text('${tr('Réf.')} ${pub['ref'] ?? ''} · ${money((pub['montant'] ?? 0) as num)} $devise · ${pub['status']}', style: TextStyle(color: p.muted, fontSize: 12.5)),
                    const SizedBox(height: 10),
                    Row(children: [
                      Expanded(child: FilledButton(onPressed: () => _decide(pub, 'active'), style: FilledButton.styleFrom(minimumSize: const Size(0, 40)), child: const Text('Mettre en ligne'))),
                      const SizedBox(width: 8),
                      Expanded(child: OutlinedButton(onPressed: () => _decide(pub, 'refused'), style: OutlinedButton.styleFrom(minimumSize: const Size(0, 40)), child: const Text('Refuser'))),
                      IconButton(onPressed: () => _delete(pub), icon: const Icon(Icons.delete_outline_rounded)),
                    ]),
                  ]),
                ),
            ]),
    );
  }
}

class _Vendeurs extends StatefulWidget {
  const _Vendeurs();
  @override
  State<_Vendeurs> createState() => _VendeursState();
}

class _VendeursState extends State<_Vendeurs> {
  List<Map<String, dynamic>>? _rows;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await sb.from('vendeurs').select().order('created_at', ascending: false).limit(200);
      if (mounted) setState(() => _rows = List<Map<String, dynamic>>.from(r as List));
    } catch (_) {
      if (mounted) setState(() => _rows = []);
    }
  }

  Future<void> _notify(Map<String, dynamic> v, String titre, String texte) async {
    if (v['user_id'] == null) return;
    try {
      await sb.from('salon_notifications').insert({'user_id': v['user_id'], 'broadcast': false, 'titre': titre, 'texte': texte});
    } catch (_) {}
  }

  /// Active (ou prolonge) le compte de $vendeurJours jours à partir d'aujourd'hui, ou de la fin en cours.
  Future<void> _activate(Map<String, dynamic> v) async {
    try {
      final now = DateTime.now();
      final cur = parseDate(v['expire_at']);
      final start = (cur != null && cur.isAfter(now)) ? cur : now;
      final expire = start.add(Duration(days: vendeurJours)).toUtc().toIso8601String();
      final res = await sb.from('vendeurs').update({'status': 'active', 'expire_at': expire}).eq('id', v['id']).select();
      if (res.isEmpty) throw Exception('Modification refusée.');
      await _notify(v, 'Compte vendeur activé', 'Votre compte vendeur « ${v['nom']} » est actif. Vos publicités sont gratuites !');
      if (mounted) toast(context, 'Compte activé ✓');
      _load();
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    }
  }

  Future<void> _refuse(Map<String, dynamic> v) async {
    try {
      await sb.from('vendeurs').update({'status': 'refused'}).eq('id', v['id']);
      await _notify(v, 'Compte vendeur', 'Nous n’avons pas retrouvé le paiement de « ${v['nom']} ». Contactez Zoneck.');
      if (mounted) toast(context, 'Décision enregistrée ✓');
      _load();
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    }
  }

  Future<void> _delete(Map<String, dynamic> v) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Supprimer ce compte vendeur ?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Annuler')),
          TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Supprimer')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await sb.from('vendeurs').delete().eq('id', v['id']);
      if (mounted) setState(() => _rows!.remove(v));
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    }
  }

  Future<void> _edit(Map<String, dynamic> v) async {
    final nom = TextEditingController(text: '${v['nom'] ?? ''}');
    final resp = TextEditingController(text: '${v['responsable'] ?? ''}');
    final tel = TextEditingController(text: '${v['tel'] ?? ''}');
    final desc = TextEditingController(text: '${v['description'] ?? ''}');
    String photo = '${v['photo'] ?? ''}';
    String photo2 = '${v['photo2'] ?? ''}';
    bool up = false;
    final save = await showDialog<bool>(
      context: context,
      builder: (d) => StatefulBuilder(builder: (d, setD) {
        Future<void> pick(int n) async {
          setD(() => up = true);
          try {
            final m = await pickPhoto(ImageSource.gallery, prefix: 'vendeur');
            if (m != null) {
              if (n == 1) {
                photo = m.url;
              } else {
                photo2 = m.url;
              }
            }
          } catch (e) {
            if (mounted) toast(context, errText(e), error: true);
          }
          setD(() => up = false);
        }

        Widget slot(int n, String url) => Expanded(
              child: Column(children: [
                AspectRatio(
                  aspectRatio: 1,
                  child: GestureDetector(
                    onTap: up ? null : () => pick(n),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: url.isEmpty
                          ? Container(color: Colors.black26, child: const Icon(Icons.add_a_photo_rounded))
                          : ZkImage(url, alignment: Alignment.topCenter, cacheWidth: 400),
                    ),
                  ),
                ),
                TextButton(
                  onPressed: up
                      ? null
                      : () => setD(() {
                            if (n == 1) {
                              photo = '';
                            } else {
                              photo2 = '';
                            }
                          }),
                  child: Text(url.isEmpty ? 'Photo $n' : 'Retirer'),
                ),
              ]),
            );
        return AlertDialog(
          title: const Text('Modifier le compte vendeur'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: nom, decoration: InputDecoration(labelText: tr('Nom de l’entreprise'))),
              const SizedBox(height: 10),
              TextField(controller: resp, decoration: InputDecoration(labelText: tr('Responsable (patron / patronne)'))),
              const SizedBox(height: 10),
              TextField(controller: tel, keyboardType: TextInputType.phone, decoration: InputDecoration(labelText: tr('Téléphone'))),
              const SizedBox(height: 10),
              TextField(controller: desc, maxLines: 3, decoration: InputDecoration(labelText: tr('Description'))),
              const SizedBox(height: 12),
              const Align(alignment: Alignment.centerLeft, child: Text('Photos des patrons (1 ou 2)', style: TextStyle(fontWeight: FontWeight.w700))),
              const SizedBox(height: 8),
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [slot(1, photo), const SizedBox(width: 10), slot(2, photo2)]),
              if (up) const Padding(padding: EdgeInsets.only(top: 8), child: LinearProgressIndicator()),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Annuler')),
            TextButton(onPressed: up ? null : () => Navigator.pop(d, true), child: const Text('Enregistrer')),
          ],
        );
      }),
    );
    final row = {
      'nom': nom.text.trim(),
      'responsable': resp.text.trim(),
      'tel': tel.text.trim(),
      'description': desc.text.trim(),
      'photo': photo.isEmpty ? null : photo,
      'photo2': photo2.isEmpty ? null : photo2,
    };
    nom.dispose();
    resp.dispose();
    tel.dispose();
    desc.dispose();
    if (save != true) return;
    try {
      final res = await sb.from('vendeurs').update(row).eq('id', v['id']).select();
      if (res.isEmpty) throw Exception('Modification refusée.');
      if (mounted) toast(context, 'Enregistré ✓');
      _load();
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (_rows == null) return const Center(child: CircularProgressIndicator());
    return RefreshIndicator(
      onRefresh: _load,
      child: _rows!.isEmpty
          ? ListView(children: const [SizedBox(height: 80), Empty('Aucun compte vendeur.', icon: Icons.storefront_outlined)])
          : ListView(padding: const EdgeInsets.only(top: 12, bottom: 24), children: [
              for (final v in _rows!) _card(p, v),
            ]),
    );
  }

  Widget _card(Pal p, Map<String, dynamic> v) {
    final etat = vendeurEtat(v);
    final color = etatColor(etat, p);
    final photos = [for (final k in ['photo', 'photo2']) if ('${v[k] ?? ''}'.isNotEmpty) '${v[k]}'];
    return ZkCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          for (final ph in photos) Padding(padding: const EdgeInsets.only(right: 8), child: ClipRRect(borderRadius: BorderRadius.circular(10), child: ZkImage(ph, width: 56, height: 56, alignment: Alignment.topCenter, cacheWidth: 200))),
          Expanded(
            child: Text('${v['nom']}', style: TextStyle(color: p.text, fontWeight: FontWeight.w800, fontSize: 15.5)),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(color: color.withAlpha(40), borderRadius: BorderRadius.circular(12)),
            child: Text(etatText(etat), style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 11.5)),
          ),
        ]),
        const SizedBox(height: 4),
        Text('${tr('Responsable')} : ${v['responsable'] ?? ''} · ${tr('Tél.')} ${v['tel'] ?? ''}', style: TextStyle(color: p.muted, fontSize: 12.5)),
        Text('${tr('Réf.')} ${v['ref'] ?? ''} · ${money((v['montant'] ?? 0) as num)} $devise${parseDate(v['expire_at']) == null ? '' : ' · ${tr('jusqu’au')} ${dateDay(v['expire_at'])}'}', style: TextStyle(color: p.muted, fontSize: 12.5)),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: FilledButton(onPressed: () => _activate(v), style: FilledButton.styleFrom(minimumSize: const Size(0, 40)), child: Text(etat == 'active' || etat == 'expired' ? '+$vendeurJours jours' : 'Activer'))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton(onPressed: () => _edit(v), style: OutlinedButton.styleFrom(minimumSize: const Size(0, 40)), child: const Text('Modifier'))),
          IconButton(onPressed: () => _refuse(v), icon: const Icon(Icons.block_rounded)),
          IconButton(onPressed: () => _delete(v), icon: const Icon(Icons.delete_outline_rounded)),
        ]),
      ]),
    );
  }
}

class _Broadcast extends StatefulWidget {
  const _Broadcast();
  @override
  State<_Broadcast> createState() => _BroadcastState();
}

class _BroadcastState extends State<_Broadcast> {
  final _t = TextEditingController(text: 'Message de Zoneck');
  final _m = TextEditingController();
  bool _busy = false;

  Future<void> _send() async {
    if (_m.text.trim().isEmpty) return toast(context, 'Écrivez un message.', error: true);
    setState(() => _busy = true);
    try {
      await sb.from('salon_notifications').insert({'user_id': null, 'broadcast': true, 'titre': _t.text.trim(), 'texte': _m.text.trim()});
      _m.clear();
      if (mounted) toast(context, 'Annonce envoyée à toutes les clientes ✓');
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Envoyer une annonce à toutes les clientes.'),
      const SizedBox(height: 14),
      TextField(controller: _t, decoration: InputDecoration(labelText: tr('Titre'))),
      const SizedBox(height: 12),
      TextField(controller: _m, maxLines: 5, decoration: InputDecoration(labelText: tr('Message'))),
      const SizedBox(height: 14),
      BusyButton(label: 'Envoyer à tout le monde', busy: _busy, onPressed: _send, icon: Icons.campaign_rounded),
    ]);
  }
}
