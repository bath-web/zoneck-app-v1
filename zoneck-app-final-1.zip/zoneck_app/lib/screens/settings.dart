import 'package:flutter/material.dart' hide Text;
import '../core/app_state.dart';
import '../core/i18n.dart';
import '../core/notifier.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import '../widgets/zk_text.dart';

const String aProposZoneck =
    'Zoneck est une plateforme multidiverse, spécialement conçue pour les femmes : '
    'une vitrine pour promouvoir tout ce qui touche à la coiffure, à la beauté et à l’univers féminin.\n\n'
    'Ici, vous pouvez réserver votre rendez-vous dans nos salons, découvrir nos réalisations et notre catalogue, '
    'discuter avec l’équipe et avec les autres membres dans l’Échange, et faire connaître vos produits grâce aux publicités.\n\n'
    'Notre mission : valoriser chaque femme et rapprocher celles qui font la beauté de celles qui la cherchent. 💜';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;

    Widget switchRow(String title, String sub, bool value, ValueChanged<bool> onChanged) => ZkCard(
          child: Row(children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: TextStyle(color: p.text, fontWeight: FontWeight.w800, fontSize: 15)),
                Text(sub, style: TextStyle(color: p.muted, fontSize: 12.5)),
              ]),
            ),
            Switch(value: value, activeColor: p.accent, onChanged: onChanged),
          ]),
        );

    Widget soundRow(ZkSound snd) {
      final on = app.soundId == snd.id;
      return InkWell(
        onTap: () {
          app.setSound(snd.id);
          Notifier.show(
            key: 'test-${DateTime.now().millisecondsSinceEpoch}',
            title: 'Zoneck',
            body: tr('Ceci est un test du son.'),
            soundId: snd.id,
          );
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 11),
          child: Row(children: [
            Icon(on ? Icons.radio_button_checked_rounded : Icons.radio_button_unchecked_rounded, color: on ? p.accent : p.muted),
            const SizedBox(width: 12),
            Expanded(child: Text(snd.label, style: TextStyle(color: p.text, fontWeight: on ? FontWeight.w800 : FontWeight.w500, fontSize: 15))),
            Icon(snd.id == 'silence' ? Icons.volume_off_rounded : Icons.volume_up_rounded, color: p.muted, size: 20),
          ]),
        ),
      );
    }

    Widget langRow(String code, String label) {
      final on = app.lang == code;
      return InkWell(
        onTap: () {
          if (!on) app.setLang(code);
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 11),
          child: Row(children: [
            Icon(on ? Icons.radio_button_checked_rounded : Icons.radio_button_unchecked_rounded, color: on ? p.accent : p.muted),
            const SizedBox(width: 12),
            Expanded(child: Text(label, style: TextStyle(color: p.text, fontWeight: on ? FontWeight.w800 : FontWeight.w500, fontSize: 15))),
          ]),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Paramètres')),
      body: ListenableBuilder(
        listenable: app,
        builder: (context, _) => ListView(padding: const EdgeInsets.only(bottom: 30), children: [
          const SectionTitle('Apparence', sub: 'Choisissez la couleur de l’application.'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(spacing: 10, runSpacing: 10, children: [
              for (final e in palettes.entries)
                GestureDetector(
                  onTap: () => app.setTheme(e.key),
                  child: Column(children: [
                    Container(
                      width: 54,
                      height: 54,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(colors: [e.value.bg, e.value.accent], begin: Alignment.topLeft, end: Alignment.bottomRight),
                        border: Border.all(color: app.theme == e.key ? p.accent : p.line, width: app.theme == e.key ? 3 : 1),
                      ),
                      child: app.theme == e.key ? Icon(Icons.check_rounded, color: e.value.text) : null,
                    ),
                    const SizedBox(height: 4),
                    Text(themeLabels[e.key]!, style: TextStyle(color: p.muted, fontSize: 11.5)),
                  ]),
                ),
            ]),
          ),
          const SectionTitle('Notifications', sub: 'Alertes dans la barre du téléphone, avec un son.'),
          switchRow('Messages et annonces', 'Une alerte à chaque nouveau message reçu.', app.notifMessages, app.setNotifMessages),
          switchRow('Groupe Échange', 'Une alerte pour les messages du groupe.', app.notifEchange, app.setNotifEchange),
          const SectionTitle('Son des notifications', sub: 'Touchez un son pour l’écouter et le choisir.'),
          ZkCard(
            child: Column(children: [
              for (final snd in zkSounds) soundRow(snd),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 4),
            child: Text(
              'Si vous n’entendez rien, vérifiez que les notifications sont autorisées pour Zoneck dans les réglages du téléphone.',
              style: TextStyle(color: p.muted, fontSize: 12.5, height: 1.35),
            ),
          ),
          const SectionTitle('Langue', sub: 'Choisissez la langue de l’application.'),
          ZkCard(
            child: Column(children: [
              langRow('fr', 'Français'),
              langRow('en', 'English'),
            ]),
          ),
          const SectionTitle('À propos'),
          ZkCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.asset('assets/images/logo.png', width: 52, height: 52)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Zoneck', style: TextStyle(color: p.accent, fontSize: 22, fontWeight: FontWeight.w900)),
                    Text('Version 1.2', style: TextStyle(color: p.muted, fontSize: 12.5)),
                  ]),
                ),
              ]),
              const SizedBox(height: 12),
              Text(aProposZoneck, style: TextStyle(color: p.text, height: 1.45, fontSize: 14.5)),
            ]),
          ),
          if (app.loggedIn) ...[
            const SectionTitle('Compte'),
            ZkCard(
              onTap: () async {
                final nav = Navigator.of(context);
                await app.signOut();
                nav.pop();
              },
              child: Row(children: [
                Icon(Icons.logout_rounded, color: p.accent),
                const SizedBox(width: 12),
                Text('Me déconnecter', style: TextStyle(color: p.text, fontWeight: FontWeight.w800)),
              ]),
            ),
          ],
          const SizedBox(height: 18),
          Center(child: Text('@2026zoneck', style: TextStyle(color: p.muted, fontSize: 12))),
        ]),
      ),
    );
  }
}
