import 'dart:math' as math;
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;
import '../core/theme.dart';

/// Écran d'entrée animé : le logo apparaît, brille, la barre se remplit, puis l'application s'ouvre en douceur.
class SplashGate extends StatefulWidget {
  final Widget child;
  const SplashGate({super.key, required this.child});

  @override
  State<SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<SplashGate> with SingleTickerProviderStateMixin {
  static bool _done = false; // on ne rejoue pas l'animation quand la langue ou le thème change
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 2800));
  bool _show = !_done;

  @override
  void initState() {
    super.initState();
    if (_show) {
      _c.forward().whenComplete(() {
        _done = true;
        if (mounted) setState(() => _show = false);
      });
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  double _seg(double t, double a, double b, [Curve curve = Curves.linear]) {
    if (t <= a) return 0;
    if (t >= b) return 1;
    return curve.transform((t - a) / (b - a));
  }

  @override
  Widget build(BuildContext context) {
    final p = palettes['violet']!;
    return Stack(fit: StackFit.expand, children: [
      widget.child,
      if (_show)
      Positioned.fill(
        child: AnimatedBuilder(
          animation: _c,
          builder: (context, _) {
            final t = _c.value;
            final logo = _seg(t, 0.0, 0.42, Curves.easeOutBack);
            final logoFade = _seg(t, 0.0, 0.25, Curves.easeOut);
            final glow = 0.5 + 0.5 * math.sin(t * math.pi * 4);
            final name = _seg(t, 0.32, 0.62, Curves.easeOutCubic);
            final tag = _seg(t, 0.5, 0.75, Curves.easeOut);
            final bar = _seg(t, 0.25, 0.9, Curves.easeInOutCubic);
            final out = 1 - _seg(t, 0.9, 1.0, Curves.easeIn);
            return Opacity(
              opacity: out,
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF2E0256), Color(0xFF4A2A58)]),
                ),
                child: Stack(alignment: Alignment.center, children: [
                  Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Opacity(
                      opacity: logoFade,
                      child: Transform.scale(
                        scale: 0.55 + 0.45 * logo,
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(34),
                            boxShadow: [BoxShadow(color: p.accent.withAlpha((40 + 70 * glow).round()), blurRadius: 30 + 40 * glow, spreadRadius: 2 + 6 * glow)],
                          ),
                          child: ClipRRect(borderRadius: BorderRadius.circular(34), child: Image.asset('assets/images/logo.png', width: 132, height: 132)),
                        ),
                      ),
                    ),
                    const SizedBox(height: 26),
                    Opacity(
                      opacity: name,
                      child: Transform.translate(
                        offset: Offset(0, 16 * (1 - name)),
                        child: m.Text('Zoneck', style: TextStyle(color: p.accent, fontSize: 40, fontWeight: FontWeight.w900, letterSpacing: 2 + 6 * (1 - name))),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Opacity(
                      opacity: tag,
                      child: const m.Text('Coiffure · Beauté · Univers féminin', style: TextStyle(color: Color(0xFFD6C6DE), fontSize: 13.5, letterSpacing: .4)),
                    ),
                  ]),
                  Positioned(
                    bottom: 72,
                    child: Opacity(
                      opacity: _seg(t, 0.2, 0.35),
                      child: Container(
                        width: 150,
                        height: 5,
                        alignment: Alignment.centerLeft,
                        decoration: BoxDecoration(color: Colors.white.withAlpha(30), borderRadius: BorderRadius.circular(3)),
                        child: FractionallySizedBox(
                          widthFactor: bar,
                          child: Container(decoration: BoxDecoration(color: p.accent, borderRadius: BorderRadius.circular(3))),
                        ),
                      ),
                    ),
                  ),
                ]),
              ),
            );
          },
        ),
      ),
    ]);
  }
}
