import 'package:flutter/material.dart' hide Text;
import '../core/api.dart';
import '../core/app_state.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import '../widgets/zk_text.dart';

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key});
  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  List<Map<String, dynamic>>? _rows;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await sb.from('salon_notifications').select().order('created_at', ascending: false).limit(100);
      if (mounted) setState(() => _rows = List<Map<String, dynamic>>.from(r as List));
      app.markNotifsSeen();
    } catch (_) {
      if (mounted) setState(() => _rows = []);
    }
  }

  Future<void> _delete(Map<String, dynamic> n) async {
    try {
      await sb.from('salon_notifications').delete().eq('id', n['id']);
      setState(() => _rows!.remove(n));
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      appBar: AppBar(title: const Text('Notifications')),
      body: _rows == null
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: _rows!.isEmpty
                  ? ListView(children: const [SizedBox(height: 80), Empty('Aucune notification.', icon: Icons.notifications_none_rounded)])
                  : ListView(padding: const EdgeInsets.only(top: 10, bottom: 20), children: [
                      for (final n in _rows!)
                        ZkCard(
                          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Icon(n['broadcast'] == true ? Icons.campaign_rounded : Icons.notifications_rounded, color: p.accent),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text('${n['titre'] ?? 'Zoneck'}', style: TextStyle(color: p.text, fontWeight: FontWeight.w800)),
                                const SizedBox(height: 3),
                                Text('${n['texte'] ?? ''}', style: TextStyle(color: p.text, height: 1.35)),
                                const SizedBox(height: 4),
                                Text(dateLong(n['created_at']), style: TextStyle(color: p.muted, fontSize: 11.5)),
                              ]),
                            ),
                            if (n['broadcast'] != true) IconButton(onPressed: () => _delete(n), icon: Icon(Icons.delete_outline_rounded, color: p.muted)),
                          ]),
                        ),
                    ]),
            ),
    );
  }
}
