import 'dart:async';
import 'package:flutter/material.dart' hide Text;
import '../core/api.dart';
import '../core/app_state.dart';
import '../core/content.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'auth.dart';
import 'echange.dart';
import 'threads.dart';
import '../widgets/zk_text.dart';
import '../core/i18n.dart';

export 'threads.dart';

/// Ouvre (ou crée) la discussion avec un salon.
Future<void> openSalonChat(BuildContext context, String salon) async {
  if (!await requireLogin(context)) return;
  if (!context.mounted) return;
  try {
    final name = app.prenom.isEmpty ? 'Cliente' : app.prenom;
    final r = await sb.rpc('salon_conversation', params: {'p_salon': salon, 'p_name': name, 'p_phone': '${app.profile?['telephone'] ?? ''}'});
    final row = r is List ? (r.isEmpty ? null : r.first) : r;
    if (row == null) throw Exception('Conversation introuvable.');
    if (!context.mounted) return;
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => SalonThreadPage(conversationId: '${row['id']}', title: '${tr('Salon')} ${salonLabel(salon)}'),
    ));
  } catch (e) {
    if (context.mounted) toast(context, errText(e), error: true);
  }
}

class MessagesPage extends StatefulWidget {
  const MessagesPage({super.key});
  @override
  State<MessagesPage> createState() => _MessagesPageState();
}

class _MessagesPageState extends State<MessagesPage> {
  int _tab = 0;
  List<Map<String, dynamic>> _convs = [];
  Map<String, int> _unread = {};
  List<_PubConv> _pubs = [];
  bool _loading = true;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    app.addListener(_onApp);
    _load();
    _t = Timer.periodic(const Duration(seconds: 12), (_) => _load(silent: true));
  }

  bool _wasLogged = false;
  void _onApp() {
    if (app.loggedIn != _wasLogged) {
      _wasLogged = app.loggedIn;
      _load();
    }
  }

  @override
  void dispose() {
    app.removeListener(_onApp);
    _t?.cancel();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    if (!app.loggedIn) {
      if (mounted) setState(() => _loading = false);
      return;
    }
    if (!silent && mounted) setState(() => _loading = true);
    try {
      final rows = await sb.from('salon_conversations').select().order('updated_at', ascending: false).limit(200);
      _convs = List<Map<String, dynamic>>.from(rows as List);
      final un = await sb.from('salon_messages').select('conversation_id').filter('read_at', 'is', null).eq('from_admin', !app.isAdmin);
      final m = <String, int>{};
      for (final r in (un as List)) {
        final k = '${r['conversation_id']}';
        m[k] = (m[k] ?? 0) + 1;
      }
      _unread = m;
    } catch (_) {}
    try {
      final msgs = await sb.from('messages').select().order('created_at', ascending: true);
      final groups = <String, _PubConv>{};
      for (final r in (msgs as List)) {
        final row = Map<String, dynamic>.from(r);
        final key = '${row['pub_id']}|${row['seller_id']}|${row['buyer_id']}';
        final g = groups.putIfAbsent(key, () => _PubConv('${row['pub_id']}', '${row['pub_titre'] ?? 'Annonce'}', '${row['seller_id']}', '${row['buyer_id']}'));
        g.last = row;
        if (row['sender_id'] != app.user?.id && row['read_at'] == null) g.unread++;
      }
      final list = groups.values.toList()..sort((a, b) => '${b.last?['created_at']}'.compareTo('${a.last?['created_at']}'));
      final ids = <String>{for (final g in list) g.otherId};
      if (ids.isNotEmpty) {
        final profs = await sb.from('profiles').select('id,prenom,nom,avatar').inFilter('id', ids.toList());
        final pm = {for (final x in (profs as List)) '${x['id']}': Map<String, dynamic>.from(x)};
        for (final g in list) {
          g.profile = pm[g.otherId];
        }
      }
      _pubs = list;
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    if (!app.loggedIn) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.chat_bubble_outline_rounded, size: 56, color: p.accent),
            const SizedBox(height: 14),
            Text('Vos messages', style: TextStyle(color: p.text, fontSize: 21, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            Text('Connectez-vous pour discuter avec les salons et les vendeurs.', textAlign: TextAlign.center, style: TextStyle(color: p.muted, height: 1.4)),
            const SizedBox(height: 18),
            FilledButton(
              onPressed: () async {
                if (await requireLogin(context)) _load();
              },
              child: const Padding(padding: EdgeInsets.symmetric(horizontal: 22), child: Text('Se connecter')),
            ),
          ]),
        ),
      );
    }
    final unreadSalon = _unread.values.fold<int>(0, (a, b) => a + b);
    final unreadPub = _pubs.fold<int>(0, (a, b) => a + b.unread);
    Widget tab(int i, String label, int n) => Expanded(
          child: GestureDetector(
            onTap: () => setState(() => _tab = i),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 11),
              decoration: BoxDecoration(color: _tab == i ? p.accent : Colors.transparent, borderRadius: BorderRadius.circular(22)),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text(label, style: TextStyle(color: _tab == i ? p.ink : p.text, fontWeight: FontWeight.w800)),
                if (n > 0)
                  Container(
                    margin: const EdgeInsets.only(left: 7),
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 1),
                    decoration: BoxDecoration(color: const Color(0xFFE53935), borderRadius: BorderRadius.circular(10)),
                    child: Text('$n', style: const TextStyle(color: Colors.white, fontSize: 11.5, fontWeight: FontWeight.w800)),
                  ),
              ]),
            ),
          ),
        );
    return Column(children: [
      ZkCard(
        margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const EchangePage())),
        child: Row(children: [
          Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            decoration: BoxDecoration(shape: BoxShape.circle, color: p.accent),
            child: const Text('👑', style: TextStyle(fontSize: 22)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Échanger entre membres', style: TextStyle(color: p.text, fontWeight: FontWeight.w800, fontSize: 16)),
              Text('Le groupe où toutes les membres discutent', style: TextStyle(color: p.muted, fontSize: 12.5)),
            ]),
          ),
          Icon(Icons.chevron_right_rounded, color: p.muted),
        ]),
      ),
      Container(
        margin: const EdgeInsets.fromLTRB(16, 10, 16, 6),
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(26), border: Border.all(color: p.line)),
        child: Row(children: [tab(0, 'Salons', unreadSalon), tab(1, 'Annonces', unreadPub)]),
      ),
      Expanded(
        child: RefreshIndicator(
          color: p.accent,
          onRefresh: _load,
          child: _loading
              ? ListView(children: const [SizedBox(height: 120), Center(child: CircularProgressIndicator())])
              : _tab == 0
                  ? _salons(context)
                  : _annonces(context),
        ),
      ),
    ]);
  }

  Widget _salons(BuildContext context) {
    final p = context.pal;
    return ListView(padding: const EdgeInsets.only(bottom: 20), children: [
      if (!app.isAdmin) ...[
        const SectionTitle('Écrire à un salon', sub: 'Posez vos questions, l’équipe vous répond ici.'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Wrap(spacing: 8, runSpacing: 8, children: [
            for (final s in bookingSalons) ActionChip(avatar: const Icon(Icons.place_rounded, size: 17), label: Text(salonLabel(s)), onPressed: () => openSalonChat(context, s)),
          ]),
        ),
      ],
      SectionTitle(app.isAdmin ? 'Boîte de réception des salons' : 'Mes discussions'),
      if (_convs.isEmpty) const Empty('Aucune discussion pour le moment.', icon: Icons.forum_outlined),
      for (final c in _convs)
        ZkCard(
          onTap: () async {
            await Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => SalonThreadPage(conversationId: '${c['id']}', title: app.isAdmin ? '${c['name']} · ${salonLabel('${c['salon']}')}' : '${tr('Salon')} ${salonLabel('${c['salon']}')}'),
            ));
            _load(silent: true);
            app.refreshCounters();
          },
          child: Row(children: [
            Avatar(name: '${app.isAdmin ? c['name'] : salonLabel('${c['salon']}')}', size: 44),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(app.isAdmin ? '${c['name']} · ${salonLabel('${c['salon']}')}' : '${tr('Salon')} ${salonLabel('${c['salon']}')}', style: TextStyle(color: p.text, fontWeight: FontWeight.w800)),
                Text(app.isAdmin ? '${c['phone'] ?? ''}' : 'Chat avec l’équipe', style: TextStyle(color: p.muted, fontSize: 12.5)),
              ]),
            ),
            if ((_unread['${c['id']}'] ?? 0) > 0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                decoration: BoxDecoration(color: const Color(0xFFE53935), borderRadius: BorderRadius.circular(12)),
                child: Text('${_unread['${c['id']}']}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
              )
            else
              Icon(Icons.chevron_right_rounded, color: p.muted),
          ]),
        ),
    ]);
  }

  Widget _annonces(BuildContext context) {
    final p = context.pal;
    if (_pubs.isEmpty) {
      return ListView(children: const [SizedBox(height: 60), Empty('Aucun message d’annonce.\nTouchez « Écrire au vendeur » sur une publicité pour commencer.', icon: Icons.campaign_outlined)]);
    }
    return ListView(padding: const EdgeInsets.only(top: 8, bottom: 20), children: [
      for (final g in _pubs)
        ZkCard(
          onTap: () async {
            await Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => PubThreadPage(pubId: g.pubId, titre: g.titre, sellerId: g.sellerId, buyerId: g.buyerId),
            ));
            _load(silent: true);
            app.refreshCounters();
          },
          child: Row(children: [
            Avatar(avatar: '${g.profile?['avatar'] ?? ''}', name: '${g.profile?['prenom'] ?? '?'}', size: 44),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${g.profile?['prenom'] ?? 'Membre'} · ${g.titre}', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: p.text, fontWeight: FontWeight.w800)),
                Text(_lastPreview(g.last), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: p.muted, fontSize: 12.5)),
              ]),
            ),
            if (g.unread > 0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                decoration: BoxDecoration(color: const Color(0xFFE53935), borderRadius: BorderRadius.circular(12)),
                child: Text('${g.unread}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
              ),
          ]),
        ),
    ]);
  }
}

class _PubConv {
  final String pubId, titre, sellerId, buyerId;
  Map<String, dynamic>? last, profile;
  int unread = 0;
  _PubConv(this.pubId, this.titre, this.sellerId, this.buyerId);
  String get otherId => sellerId == app.user?.id ? buyerId : sellerId;
}

String _lastPreview(Map<String, dynamic>? m) {
  if (m == null) return '';
  final t = plainMsg('${m['texte'] ?? ''}');
  if (t.isNotEmpty) return t;
  switch ('${m['type']}') {
    case 'image':
    case 'photo':
      return '📷 Photo';
    case 'audio':
      return '🎤 Message vocal';
    case 'video':
      return '🎬 Vidéo';
  }
  return '';
}

/// Les citations du site sont stockées dans le texte (séparateur invisible) : on ne garde que le message.
String plainMsg(String raw) {
  if (raw.isEmpty || raw[0] != zkTag) return raw;
  final parts = raw.substring(1).split(zkTag);
  if (parts.length < 4) return parts.join();
  return parts.sublist(3).join();
}
