import 'package:flutter/material.dart' hide Text;
import '../core/app_state.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'booking.dart';
import '../widgets/zk_text.dart';

class CataloguePage extends StatelessWidget {
  const CataloguePage({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return ListenableBuilder(
      listenable: app.content,
      builder: (context, _) {
        final list = app.content.coiffures;
        return ListView(
          padding: const EdgeInsets.only(bottom: 24),
          children: [
            const SectionTitle('Nos prestations', sub: 'Choisissez votre coiffure, puis réservez en un clic.'),
            for (final c in list)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: Material(
                  color: p.card,
                  borderRadius: BorderRadius.circular(20),
                  clipBehavior: Clip.antiAlias,
                  child: InkWell(
                    onTap: () => openBooking(context, motif: c.nom),
                    child: Container(
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: p.line)),
                      child: Row(children: [
                        SizedBox(width: 118, height: 118, child: ZkImage(app.content.imageFor(c), alignment: Alignment.topCenter, cacheWidth: 360)),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(c.nom, style: TextStyle(color: p.text, fontWeight: FontWeight.w800, fontSize: 16)),
                              const SizedBox(height: 3),
                              Text(c.desc, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: p.muted, fontSize: 12.5, height: 1.3)),
                              const SizedBox(height: 6),
                              Text(c.prix, style: TextStyle(color: p.accent, fontWeight: FontWeight.w800, fontSize: 13.5)),
                              const SizedBox(height: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                                decoration: BoxDecoration(color: p.accent, borderRadius: BorderRadius.circular(16)),
                                child: Text('Réserver', style: TextStyle(color: p.ink, fontWeight: FontWeight.w800, fontSize: 12.5)),
                              ),
                            ]),
                          ),
                        ),
                      ]),
                    ),
                  ),
                ),
              ),
            const SectionTitle('Brochure des prix'),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(18), border: Border.all(color: p.line)),
                child: Column(children: [
                  for (var i = 0; i < list.length; i++)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      decoration: BoxDecoration(border: i == 0 ? null : Border(top: BorderSide(color: p.line))),
                      child: Row(children: [
                        Expanded(child: Text(list[i].nom, style: TextStyle(color: p.text, fontWeight: FontWeight.w600))),
                        Text(list[i].prix, style: TextStyle(color: p.accent, fontWeight: FontWeight.w700)),
                      ]),
                    ),
                ]),
              ),
            ),
          ],
        );
      },
    );
  }
}
