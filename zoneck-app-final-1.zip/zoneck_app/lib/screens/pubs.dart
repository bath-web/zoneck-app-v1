import 'dart:io' show File;
import 'dart:math';
import 'package:flutter/material.dart' hide Text;
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart' show FileOptions, PostgrestException;
import 'package:url_launcher/url_launcher.dart';
import '../core/api.dart';
import '../core/app_state.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import '../widgets/pub_media.dart';
import 'auth.dart';
import 'messages.dart';
import 'vendeur.dart';
import '../widgets/zk_text.dart';
import '../core/i18n.dart';

class PubsPage extends StatefulWidget {
  const PubsPage({super.key});
  @override
  State<PubsPage> createState() => _PubsPageState();
}

class _PubsPageState extends State<PubsPage> {
  List<Map<String, dynamic>>? _pubs;
  List<Map<String, dynamic>> _mine = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final nowIso = DateTime.now().toUtc().toIso8601String();
      final r = await sb
          .from('pubs')
          .select()
          .eq('status', 'active')
          .or('expire_at.is.null,expire_at.gt.$nowIso')
          .order('created_at', ascending: false);
      _pubs = List<Map<String, dynamic>>.from(r as List);
    } catch (_) {
      _pubs ??= [];
    }
    if (app.loggedIn) {
      try {
        final m = await sb.from('pubs').select().eq('user_id', app.user!.id).order('created_at', ascending: false);
        _mine = List<Map<String, dynamic>>.from(m as List);
      } catch (_) {}
    }
    if (mounted) setState(() {});
  }

  Future<void> _create() async {
    if (!await requireLogin(context)) return;
    if (!context.mounted) return;
    final created = await sheet<bool>(context, const _PubForm());
    if (created == true) _load();
  }

  Future<void> _contact(Map<String, dynamic> pub) async {
    if (!await requireLogin(context)) return;
    if (!mounted) return;
    final seller = '${pub['user_id']}';
    if (seller == app.user!.id) return toast(context, 'C’est votre publicité.');
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => PubThreadPage(pubId: '${pub['id']}', titre: '${pub['titre']}', sellerId: seller, buyerId: app.user!.id),
    ));
  }

  Future<void> _paid(Map<String, dynamic> pub) async {
    try {
      await sb.rpc('pub_declare_paid', params: {'p_ref': pub['ref']});
      if (mounted) toast(context, 'Merci ! Votre paiement est en cours de vérification.');
      _load();
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      appBar: AppBar(title: const Text('Publicité')),
      floatingActionButton: FloatingActionButton.extended(onPressed: _create, icon: const Icon(Icons.add_rounded), label: const Text('Créer ma pub')),
      body: _pubs == null
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(padding: const EdgeInsets.only(bottom: 100), children: [
                const SectionTitle('Espace pro', sub: 'Faites connaître vos produits à toutes nos clientes.'),
                if (app.vendeurActive)
                  ZkCard(
                    child: Row(children: [
                      Icon(Icons.card_giftcard_rounded, color: p.accent, size: 30),
                      const SizedBox(width: 12),
                      Expanded(child: Text('Compte vendeur actif : vos publicités sont gratuites 🎁', style: TextStyle(color: p.text, fontWeight: FontWeight.w800, height: 1.35))),
                    ]),
                  )
                else ...[
                ZkCard(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${money(prixPeriode)} $devise', style: TextStyle(color: p.accent, fontSize: 26, fontWeight: FontWeight.w900)),
                    Text('${tr('pour')} $semainesPeriode ${tr('semaines de publicité')}', style: TextStyle(color: p.muted)),
                    const SizedBox(height: 10),
                    for (final s in const [
                      '1. Créez votre compte (gratuit).',
                      '2. Rédigez votre publicité : titre, description, photo, prix.',
                      '3. Payez par Mobile Money.',
                      '4. Votre pub est en ligne dès que le paiement est confirmé.',
                    ])
                      Padding(padding: const EdgeInsets.only(top: 3), child: Text(s, style: TextStyle(color: p.text, height: 1.35, fontSize: 13.5))),
                  ]),
                ),
                ZkCard(
                  onTap: () async {
                    if (await requireLogin(context) && context.mounted) {
                      await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const VendeurPage()));
                      if (mounted) _load();
                    }
                  },
                  child: Row(children: [
                    Icon(Icons.storefront_rounded, color: p.accent, size: 28),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Créer un compte vendeur', style: TextStyle(color: p.text, fontWeight: FontWeight.w800)),
                        Text('${money(vendeurInscription)} $devise ${tr("d'inscription")} + ${money(vendeurMensuel)} $devise/${tr('mois')} · ${tr('publicités gratuites')}', style: TextStyle(color: p.muted, fontSize: 12.5)),
                      ]),
                    ),
                    Icon(Icons.chevron_right_rounded, color: p.muted),
                  ]),
                ),
                ],
                if (_mine.isNotEmpty) ...[
                  const SectionTitle('Mes publicités'),
                  for (final m in _mine) _mineCard(m),
                ],
                const SectionTitle('Publicités en cours'),
                if (_pubs!.isEmpty) const Empty('Aucune publicité pour le moment.', icon: Icons.campaign_outlined),
                for (final pub in _pubs!) _pubCard(pub),
              ]),
            ),
    );
  }

  Widget _pubCard(Map<String, dynamic> pub) {
    final p = context.pal;
    var photos = mediaList(pub['images']);
    final img = '${pub['image'] ?? ''}';
    if (photos.isEmpty && img.isNotEmpty) photos = [img];
    final videos = mediaList(pub['videos']);
    final prix = '${pub['prix'] ?? ''}';
    return ZkCard(
      padding: EdgeInsets.zero,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (photos.isNotEmpty || videos.isNotEmpty)
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
            child: PubMedia(photos: photos, videos: videos, height: 220),
          ),
        Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${pub['titre'] ?? ''}', style: TextStyle(color: p.text, fontWeight: FontWeight.w800, fontSize: 17)),
            if (prix.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 3), child: Text(prix, style: TextStyle(color: p.accent, fontWeight: FontWeight.w800))),
            const SizedBox(height: 6),
            Text('${pub['description'] ?? ''}', style: TextStyle(color: p.muted, height: 1.4)),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: () => _contact(pub),
                  icon: const Icon(Icons.chat_bubble_rounded, size: 18),
                  label: const Text('Écrire au vendeur'),
                ),
              ),
              if ('${pub['contact'] ?? ''}'.trim().isNotEmpty) ...[
                const SizedBox(width: 8),
                OutlinedButton.icon(
                  onPressed: () {
                    final c = '${pub['contact']}'.replaceAll(RegExp(r'[^0-9+]'), '');
                    if (c.length >= 6) launchUrl(Uri.parse('tel:$c'), mode: LaunchMode.externalApplication);
                  },
                  icon: const Icon(Icons.call_rounded, size: 20),
                  label: const Text('Appeler'),
                ),
              ],
            ]),
          ]),
        ),
      ]),
    );
  }

  Widget _mineCard(Map<String, dynamic> m) {
    final p = context.pal;
    final status = '${m['status']}';
    final label = {'active': 'En ligne', 'pending': 'Paiement à confirmer', 'paid': 'Paiement en vérification', 'refused': 'Refusée'}[status] ?? status;
    final color = status == 'active' ? const Color(0xFF6BD68A) : (status == 'refused' ? const Color(0xFFFF9C9C) : p.accent);
    return ZkCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text('${m['titre']}', style: TextStyle(color: p.text, fontWeight: FontWeight.w800, fontSize: 15.5))),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(color: color.withAlpha(40), borderRadius: BorderRadius.circular(12)),
            child: Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 11.5)),
          ),
        ]),
        Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text('${tr('Réf.')} ${m['ref'] ?? ''} · ${m['semaines'] ?? ''} ${tr('sem.')} · ${money((m['montant'] ?? 0) as num)} $devise', style: TextStyle(color: p.muted, fontSize: 12.5)),
        ),
        if (status == 'pending' && ((m['montant'] ?? 0) as num) > 0) ...[
          const SizedBox(height: 10),
          Text('${tr('Envoyez')} ${money((m['montant']) as num)} $devise ${tr('par Mobile Money au')} $paiementTel, ${tr('avec la référence')} ${m['ref']}.', style: TextStyle(color: p.text, fontSize: 13.5, height: 1.35)),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () => _paid(m), icon: const Icon(Icons.check_circle_rounded, size: 19), label: const Text('J’ai payé'))),
        ],
      ]),
    );
  }
}

class _PubForm extends StatefulWidget {
  const _PubForm();
  @override
  State<_PubForm> createState() => _PubFormState();
}

class _PubFormState extends State<_PubForm> {
  final _titre = TextEditingController();
  final _desc = TextEditingController();
  final _prix = TextEditingController();
  late final TextEditingController _contact = TextEditingController(text: '${app.profile?['telephone'] ?? ''}');
  final List<String> _photos = [];
  final List<String> _videos = [];
  int _sem = semainesPeriode;
  bool _busy = false;
  String? _upl; // texte affiché pendant l'envoi d'une photo ou d'une vidéo
  String? _err;

  bool get _free => app.vendeurActive;
  int get _total => _free ? 0 : (_sem / semainesPeriode).ceil() * prixPeriode;

  String _rnd() => '${DateTime.now().millisecondsSinceEpoch}-${Random().nextInt(99999).toRadixString(36)}';

  Future<void> _addPhotos() async {
    final room = 8 - _photos.length;
    if (room <= 0) return setState(() => _err = '8 photos au maximum.');
    try {
      final files = await ImagePicker().pickMultiImage(maxWidth: 1280, imageQuality: 75);
      if (files.isEmpty) return;
      var n = 0;
      for (final f in files.take(room)) {
        n++;
        setState(() {
          _err = null;
          _upl = '${tr('Envoi de la photo')} $n/${files.length > room ? room : files.length}…';
        });
        final bytes = await f.readAsBytes();
        final path = '${app.user!.id}/pub-${_rnd()}.jpg';
        await sb.storage.from('chat').uploadBinary(path, bytes, fileOptions: const FileOptions(contentType: 'image/jpeg', cacheControl: '31536000'));
        _photos.add(sb.storage.from('chat').getPublicUrl(path));
      }
    } catch (e) {
      if (mounted) setState(() => _err = errText(e));
    } finally {
      if (mounted) setState(() => _upl = null);
    }
  }

  Future<void> _addVideo() async {
    if (_videos.length >= 3) return setState(() => _err = '3 vidéos au maximum.');
    try {
      final f = await ImagePicker().pickVideo(source: ImageSource.gallery, maxDuration: const Duration(seconds: 60));
      if (f == null) return;
      final file = File(f.path);
      final size = await file.length();
      if (size > 45 * 1024 * 1024) {
        if (mounted) setState(() => _err = 'Cette vidéo est trop lourde (45 Mo maximum). Choisissez une vidéo plus courte.');
        return;
      }
      setState(() {
        _err = null;
        _upl = 'Envoi de la vidéo… patientez, cela peut durer un moment.';
      });
      final path = '${app.user!.id}/pub-${_rnd()}.mp4';
      await sb.storage.from('chat').upload(path, file, fileOptions: const FileOptions(contentType: 'video/mp4', cacheControl: '31536000'));
      _videos.add(sb.storage.from('chat').getPublicUrl(path));
    } catch (e) {
      if (mounted) setState(() => _err = errText(e));
    } finally {
      if (mounted) setState(() => _upl = null);
    }
  }

  Future<void> _send() async {
    if (_upl != null) return setState(() => _err = 'Attendez la fin de l’envoi des photos et vidéos.');
    if (_titre.text.trim().isEmpty || _desc.text.trim().isEmpty || _contact.text.trim().isEmpty) {
      return setState(() => _err = 'Titre, description et contact sont obligatoires.');
    }
    setState(() {
      _busy = true;
      _err = null;
    });
    final rnd = Random.secure();
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final ref = 'PUB-${List.generate(6, (_) => chars[rnd.nextInt(chars.length)]).join()}';
    try {
      final row = <String, dynamic>{
        'user_id': app.user!.id,
        'titre': _titre.text.trim(),
        'description': _desc.text.trim(),
        'prix': _prix.text.trim().isEmpty ? null : _prix.text.trim(),
        'contact': _contact.text.trim(),
        'image': _photos.isEmpty ? null : _photos.first,
        'semaines': _free ? semainesPeriode : _sem,
        'montant': _total,
        'ref': ref,
        'status': 'pending',
      };
      try {
        await sb.from('pubs').insert({...row, 'images': _photos, 'videos': _videos});
      } on PostgrestException catch (e) {
        final m = e.message.toLowerCase();
        if (m.contains('images') || m.contains('videos') || m.contains('schema cache')) {
          await sb.from('pubs').insert(row);
        } else {
          rethrow;
        }
      }
      if (!mounted) return;
      final rootCtx = Navigator.of(context, rootNavigator: true).context;
      Navigator.of(context).pop(true);
      showDialog(
        context: rootCtx,
        builder: (c) => AlertDialog(
          title: Text(_free ? 'Publicité envoyée 🎁' : 'Dernière étape 💳'),
          content: _free
              ? Text(tr('Votre publicité est gratuite avec votre compte vendeur. Elle est mise en ligne tout de suite.'))
              : Text('${tr('Envoyez')} ${money(_total)} $devise ${tr('par Mobile Money au')} $paiementTel ${tr('avec la référence')} $ref.\n\n${tr('Puis ouvrez « Mes publicités » et touchez « J’ai payé ». Votre pub sera mise en ligne dès confirmation.')}'),
          actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('Compris'))],
        ),
      );
    } catch (e) {
      if (mounted) setState(() => _err = errText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
        Text('Créer ma publicité', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: p.text)),
        const SizedBox(height: 14),
        TextField(controller: _titre, decoration: InputDecoration(labelText: tr('Titre'))),
        const SizedBox(height: 12),
        TextField(controller: _desc, maxLines: 4, decoration: InputDecoration(labelText: tr('Description'))),
        const SizedBox(height: 12),
        TextField(controller: _prix, decoration: InputDecoration(labelText: tr('Prix (facultatif)'))),
        const SizedBox(height: 12),
        TextField(controller: _contact, keyboardType: TextInputType.phone, decoration: InputDecoration(labelText: tr('Contact (téléphone)'))),
        const SizedBox(height: 12),
        Text('${tr('Photos du produit')} (${_photos.length}/8)', style: TextStyle(color: p.muted, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        SizedBox(
          height: 84,
          child: ListView(scrollDirection: Axis.horizontal, children: [
            for (var i = 0; i < _photos.length; i++)
              Container(
                width: 84,
                margin: const EdgeInsets.only(right: 8),
                child: Stack(children: [
                  Positioned.fill(child: ClipRRect(borderRadius: BorderRadius.circular(12), child: ZkImage(_photos[i], cacheWidth: 300))),
                  Positioned(
                    top: 2,
                    right: 2,
                    child: GestureDetector(
                      onTap: () => setState(() => _photos.removeAt(i)),
                      child: const CircleAvatar(radius: 11, backgroundColor: Colors.black54, child: Icon(Icons.close_rounded, size: 14, color: Colors.white)),
                    ),
                  ),
                ]),
              ),
            GestureDetector(
              onTap: _upl != null ? null : _addPhotos,
              child: Container(
                width: 84,
                decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: p.line)),
                child: Icon(Icons.add_photo_alternate_rounded, color: p.accent, size: 30),
              ),
            ),
          ]),
        ),
        const SizedBox(height: 14),
        Text('${tr('Vidéos du produit')} (${_videos.length}/3)', style: TextStyle(color: p.muted, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        for (var i = 0; i < _videos.length; i++)
          Container(
            margin: const EdgeInsets.only(bottom: 6),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: p.line)),
            child: Row(children: [
              Icon(Icons.videocam_rounded, color: p.accent),
              const SizedBox(width: 10),
              Expanded(child: Text('${tr('Vidéo')} ${i + 1} ${tr('ajoutée')}', style: TextStyle(color: p.text, fontWeight: FontWeight.w600))),
              GestureDetector(onTap: () => setState(() => _videos.removeAt(i)), child: Icon(Icons.close_rounded, color: p.muted)),
            ]),
          ),
        OutlinedButton.icon(
          onPressed: _upl != null ? null : _addVideo,
          icon: const Icon(Icons.video_call_rounded),
          label: const Text('Ajouter une vidéo'),
        ),
        if (_upl != null)
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Row(children: [
              const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2.2)),
              const SizedBox(width: 10),
              Expanded(child: Text(_upl!, style: TextStyle(color: p.accent, fontWeight: FontWeight.w700, fontSize: 13))),
            ]),
          ),
        const SizedBox(height: 12),
        if (_free)
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: p.accent.withAlpha(30), borderRadius: BorderRadius.circular(12)),
            child: Row(children: [
              Icon(Icons.card_giftcard_rounded, color: p.accent),
              const SizedBox(width: 10),
              Expanded(child: Text('Gratuit : offert avec votre compte vendeur', style: TextStyle(color: p.text, fontWeight: FontWeight.w700))),
            ]),
          )
        else ...[
        DropdownButtonFormField<int>(
          value: _sem,
          dropdownColor: p.bg2,
          decoration: InputDecoration(labelText: tr('Durée de la publicité')),
          items: [
            for (var n = 1; n <= 4; n++) DropdownMenuItem(value: n * semainesPeriode, child: Text('${n * semainesPeriode} ${tr('semaines')} · ${money(n * prixPeriode)} $devise')),
          ],
          onChanged: (v) => setState(() => _sem = v ?? semainesPeriode),
        ),
        const SizedBox(height: 10),
        Text('${tr('Total à payer')} : ${money(_total)} $devise', style: TextStyle(color: p.accent, fontWeight: FontWeight.w800, fontSize: 16)),
        ],
        if (_err != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(_err!, style: const TextStyle(color: Color(0xFFFF9C9C), fontWeight: FontWeight.w600))),
        const SizedBox(height: 16),
        BusyButton(label: 'Valider ma publicité', busy: _busy, onPressed: _send),
      ]),
    );
  }
}
