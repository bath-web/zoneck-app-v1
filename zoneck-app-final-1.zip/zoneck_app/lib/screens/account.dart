import 'package:flutter/material.dart' hide Text;
import 'package:supabase_flutter/supabase_flutter.dart' show UserAttributes;
import '../core/api.dart';
import '../core/app_state.dart';
import '../core/content.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'auth.dart';
import '../widgets/zk_text.dart';
import '../core/i18n.dart';

class AccountPage extends StatefulWidget {
  const AccountPage({super.key});
  @override
  State<AccountPage> createState() => _AccountPageState();
}

class _AccountPageState extends State<AccountPage> {
  List<Map<String, dynamic>> _rdv = [];
  final _nom = TextEditingController();
  final _tel = TextEditingController();
  String _avatar = 'e:🌸';
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _fill();
    _loadRdv();
  }

  @override
  void dispose() {
    _nom.dispose();
    _tel.dispose();
    super.dispose();
  }

  void _fill() {
    final pr = app.profile;
    _nom.text = '${pr?['nom'] == 'Membre' ? '' : (pr?['nom'] ?? '')}';
    _tel.text = '${pr?['telephone'] ?? ''}';
    _avatar = app.avatar.startsWith('e:') ? app.avatar : 'e:🌸';
  }

  Future<void> _loadRdv() async {
    if (!app.loggedIn) return;
    try {
      final r = await sb.from('salon_appointments').select().order('created_at', ascending: false).limit(30);
      if (mounted) setState(() => _rdv = List<Map<String, dynamic>>.from(r as List));
    } catch (_) {}
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    try {
      await app.saveProfile(nom: _nom.text, tel: _tel.text, avatar: _avatar);
      if (mounted) toast(context, 'Profil enregistré ✓');
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _password() async {
    final a = TextEditingController(), b = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Nouveau mot de passe'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: a, obscureText: true, decoration: InputDecoration(labelText: tr('Nouveau mot de passe'))),
          const SizedBox(height: 10),
          TextField(controller: b, obscureText: true, decoration: InputDecoration(labelText: tr('Confirmer'))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Enregistrer')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    if (a.text.length < 6 || a.text != b.text) return toast(context, '6 caractères minimum, identiques dans les deux champs.', error: true);
    try {
      await sb.auth.updateUser(UserAttributes(password: a.text));
      if (mounted) toast(context, 'Mot de passe modifié ✓');
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        if (!app.loggedIn) {
          return Scaffold(
            appBar: AppBar(title: const Text('Mon compte')),
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(28),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.account_circle_rounded, size: 72, color: p.accent),
                  const SizedBox(height: 12),
                  Text('Connectez-vous pour réserver, écrire aux salons et publier vos annonces.', textAlign: TextAlign.center, style: TextStyle(color: p.muted, height: 1.4)),
                  const SizedBox(height: 20),
                  FilledButton(
                    onPressed: () async {
                      if (await requireLogin(context)) {
                        _fill();
                        _loadRdv();
                      }
                    },
                    child: const Padding(padding: EdgeInsets.symmetric(horizontal: 26), child: Text('Connexion / Inscription')),
                  ),
                ]),
              ),
            ),
          );
        }
        return Scaffold(
          appBar: AppBar(title: const Text('Mon compte')),
          body: ListView(padding: const EdgeInsets.fromLTRB(16, 16, 16, 30), children: [
            Center(child: Avatar(avatar: _avatar, name: app.prenom, size: 84)),
            const SizedBox(height: 10),
            Center(child: Text(app.prenom, style: TextStyle(color: p.text, fontSize: 22, fontWeight: FontWeight.w900))),
            if (app.isAdmin) Center(child: Text('Administrateur', style: TextStyle(color: p.accent, fontWeight: FontWeight.w700))),
            const SizedBox(height: 18),
            Wrap(alignment: WrapAlignment.center, spacing: 8, runSpacing: 8, children: [
              for (final e in avatarEmojis)
                GestureDetector(
                  onTap: () => setState(() => _avatar = 'e:$e'),
                  child: Container(
                    width: 44,
                    height: 44,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: p.card, border: Border.all(color: _avatar == 'e:$e' ? p.accent : p.line, width: _avatar == 'e:$e' ? 2.4 : 1)),
                    child: Text(e, style: const TextStyle(fontSize: 21)),
                  ),
                ),
            ]),
            const SizedBox(height: 18),
            TextField(controller: _nom, textCapitalization: TextCapitalization.words, decoration: InputDecoration(labelText: tr('Nom'))),
            const SizedBox(height: 12),
            TextField(controller: _tel, keyboardType: TextInputType.phone, decoration: InputDecoration(labelText: tr('Téléphone'))),
            const SizedBox(height: 14),
            BusyButton(label: 'Enregistrer', busy: _busy, onPressed: _save),
            const SizedBox(height: 8),
            OutlinedButton.icon(onPressed: _password, icon: const Icon(Icons.lock_reset_rounded), label: const Text('Changer mon mot de passe')),
            const SectionTitle('Mes rendez-vous'),
            if (_rdv.isEmpty) const Empty('Aucun rendez-vous pour le moment.', icon: Icons.event_busy_rounded),
            for (final r in _rdv)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: p.line)),
                  child: Row(children: [
                    if ('${r['photo'] ?? ''}'.isNotEmpty)
                      Padding(padding: const EdgeInsets.only(right: 12), child: ClipRRect(borderRadius: BorderRadius.circular(10), child: ZkImage('${r['photo']}', width: 52, height: 52, cacheWidth: 160))),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${r['motif']} · ${salonLabel('${r['salon']}')}', style: TextStyle(color: p.text, fontWeight: FontWeight.w800)),
                        Text(dateLong(r['appointment_date']), style: TextStyle(color: p.muted, fontSize: 13)),
                        Text('${r['statut'] ?? 'En attente'}', style: TextStyle(color: p.accent, fontSize: 12.5, fontWeight: FontWeight.w700)),
                      ]),
                    ),
                  ]),
                ),
              ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: () async {
                final nav = Navigator.of(context);
                await app.signOut();
                nav.pop();
              },
              icon: const Icon(Icons.logout_rounded),
              label: const Text('Se déconnecter'),
            ),
          ]),
        );
      },
    );
  }
}
