import 'dart:math';
import 'package:flutter/material.dart' hide Text;
import 'package:supabase_flutter/supabase_flutter.dart' show PostgrestException;
import 'package:url_launcher/url_launcher.dart';
import '../core/api.dart';
import '../core/app_state.dart';
import '../core/config.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import '../widgets/zk_text.dart';
import '../core/i18n.dart';
import 'pubs.dart';

String vendeurRef() {
  final rnd = Random.secure();
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  return 'VEN-${List.generate(6, (_) => chars[rnd.nextInt(chars.length)]).join()}';
}

/// État lisible d'un compte vendeur (tient compte de la date de fin).
String vendeurEtat(Map<String, dynamic> v) {
  final st = '${v['status']}';
  if (st == 'active') {
    final e = parseDate(v['expire_at']);
    if (e != null && e.isBefore(DateTime.now())) return 'expired';
  }
  return st;
}

const _etatLabel = {
  'active': 'Compte actif',
  'pending': 'Paiement à effectuer',
  'paid': 'Paiement en vérification',
  'refused': 'Refusé',
  'expired': 'Abonnement terminé',
};

Color etatColor(String etat, Pal p) {
  if (etat == 'active') return const Color(0xFF6BD68A);
  if (etat == 'refused' || etat == 'expired') return const Color(0xFFFF9C9C);
  return p.accent;
}

String etatText(String etat) => _etatLabel[etat] ?? etat;

/// Les conditions affichées avant de créer un compte vendeur.
class VendeurClause extends StatelessWidget {
  const VendeurClause({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    Widget line(IconData i, String t) => Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(i, size: 18, color: p.accent),
            const SizedBox(width: 10),
            Expanded(child: Text(t, style: TextStyle(color: p.text, height: 1.35, fontSize: 13.5))),
          ]),
        );
    return ZkCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Conditions du compte vendeur', style: TextStyle(color: p.text, fontWeight: FontWeight.w800, fontSize: 16)),
        const SizedBox(height: 4),
        Text('${money(vendeurInscription)} $devise ${tr("d'inscription (une seule fois)")}', style: TextStyle(color: p.accent, fontWeight: FontWeight.w900, fontSize: 18)),
        Text('${money(vendeurMensuel)} $devise ${tr('par mois')}', style: TextStyle(color: p.accent, fontWeight: FontWeight.w900, fontSize: 18)),
        line(Icons.campaign_rounded, 'Vos publicités sont gratuites : elles sont offertes avec le compte vendeur.'),
        line(Icons.storefront_rounded, 'Votre compte apparaît comme un salon, dans « Contact & salons », avec les photos des responsables.'),
        line(Icons.phone_android_rounded, 'Paiement par Mobile Money au $paiementTel, avec la référence donnée après l’inscription.'),
        line(Icons.event_repeat_rounded, 'Le compte est valable $vendeurJours jours. Sans renouvellement de ${money(vendeurMensuel)} $devise, il est suspendu.'),
      ]),
    );
  }
}

class VendeurPage extends StatefulWidget {
  const VendeurPage({super.key});
  @override
  State<VendeurPage> createState() => _VendeurPageState();
}

class _VendeurPageState extends State<VendeurPage> {
  final _nom = TextEditingController();
  final _resp = TextEditingController();
  late final TextEditingController _tel = TextEditingController(text: '${app.profile?['telephone'] ?? ''}');
  final _desc = TextEditingController();
  bool _ok = false, _busy = false, _loading = true, _missing = false;
  String? _err;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  @override
  void dispose() {
    for (final c in [_nom, _resp, _tel, _desc]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _reload() async {
    await app.loadVendeur();
    try {
      await sb.from('vendeurs').select('id').limit(1);
      _missing = false;
    } on PostgrestException catch (e) {
      final m = e.message.toLowerCase();
      _missing = m.contains('vendeurs') || m.contains('schema cache') || e.code == '42P01' || e.code == 'PGRST205';
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _create() async {
    setState(() => _err = null);
    if (_nom.text.trim().isEmpty || _resp.text.trim().isEmpty || _tel.text.trim().length < 8) {
      return setState(() => _err = 'Nom de l’entreprise, responsable et téléphone sont obligatoires.');
    }
    if (!_ok) return setState(() => _err = 'Acceptez les conditions pour continuer.');
    setState(() => _busy = true);
    try {
      await sb.from('vendeurs').insert({
        'user_id': app.user!.id,
        'nom': _nom.text.trim(),
        'responsable': _resp.text.trim(),
        'tel': _tel.text.trim(),
        'description': _desc.text.trim(),
        'ref': vendeurRef(),
        'montant': vendeurInscription + vendeurMensuel,
        'status': 'pending',
      });
      await app.loadVendeur();
      if (mounted) toast(context, 'Compte créé ✓ Il reste le paiement.');
    } catch (e) {
      if (mounted) setState(() => _err = errText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _paid() async {
    final v = app.vendeur;
    if (v == null) return;
    try {
      await sb.rpc('vendeur_declare_paid', params: {'p_ref': v['ref']});
      await app.loadVendeur();
      if (mounted) toast(context, 'Merci ! Votre paiement est en cours de vérification.');
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    }
  }

  Future<void> _renew() async {
    try {
      await sb.rpc('vendeur_renew', params: {'p_ref': vendeurRef()});
      await app.loadVendeur();
      if (mounted) toast(context, 'Renouvellement demandé : envoyez le paiement.');
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      appBar: AppBar(title: const Text('Compte vendeur')),
      body: ListenableBuilder(
        listenable: app,
        builder: (context, _) {
          if (_loading) return const Center(child: CircularProgressIndicator());
          if (_missing) {
            return const Center(child: Empty('Les comptes vendeur seront bientôt disponibles.\nRevenez un peu plus tard 💜', icon: Icons.storefront_rounded));
          }
          final v = app.vendeur;
          return RefreshIndicator(
            onRefresh: _reload,
            child: ListView(padding: const EdgeInsets.only(bottom: 30), children: [
              if (v == null) ..._form(p) else ..._status(p, v),
            ]),
          );
        },
      ),
    );
  }

  List<Widget> _form(Pal p) => [
        const SectionTitle('Devenez vendeur Zoneck', sub: 'Faites connaître votre entreprise à toutes les membres.'),
        const VendeurClause(),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(children: [
            TextField(controller: _nom, textCapitalization: TextCapitalization.words, decoration: InputDecoration(labelText: tr('Nom de l’entreprise'), prefixIcon: const Icon(Icons.storefront_outlined))),
            const SizedBox(height: 12),
            TextField(controller: _resp, textCapitalization: TextCapitalization.words, decoration: InputDecoration(labelText: tr('Responsable (patron / patronne)'), prefixIcon: const Icon(Icons.person_outline_rounded))),
            const SizedBox(height: 12),
            TextField(controller: _tel, keyboardType: TextInputType.phone, decoration: InputDecoration(labelText: tr('Téléphone'), prefixIcon: const Icon(Icons.phone_outlined))),
            const SizedBox(height: 12),
            TextField(controller: _desc, maxLines: 3, decoration: InputDecoration(labelText: tr('Ce que vous vendez (facultatif)'))),
            const SizedBox(height: 6),
            CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              controlAffinity: ListTileControlAffinity.leading,
              value: _ok,
              onChanged: (v) => setState(() => _ok = v ?? false),
              title: Text('J’ai lu et j’accepte les conditions : ${money(vendeurInscription)} $devise d’inscription et ${money(vendeurMensuel)} $devise par mois.', style: TextStyle(color: p.text, fontSize: 13.5, height: 1.3)),
            ),
            if (_err != null) Padding(padding: const EdgeInsets.only(bottom: 10), child: Text(_err!, style: const TextStyle(color: Color(0xFFFF9C9C), fontWeight: FontWeight.w600))),
            BusyButton(label: 'Créer mon compte vendeur', busy: _busy, onPressed: _create, icon: Icons.storefront_rounded),
          ]),
        ),
      ];

  List<Widget> _status(Pal p, Map<String, dynamic> v) {
    final etat = vendeurEtat(v);
    final color = etatColor(etat, p);
    final expire = parseDate(v['expire_at']);
    final photos = [for (final k in ['photo', 'photo2']) if ('${v[k] ?? ''}'.isNotEmpty) '${v[k]}'];
    final montant = (v['montant'] ?? 0) as num;
    return [
      ZkCard(
        padding: EdgeInsets.zero,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (photos.isNotEmpty)
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
              child: SizedBox(
                height: 190,
                width: double.infinity,
                child: photos.length == 1
                    ? ZkImage(photos.first, alignment: Alignment.topCenter, cacheWidth: 900)
                    : Row(children: [for (final ph in photos) Expanded(child: ZkImage(ph, alignment: Alignment.topCenter, cacheWidth: 600))]),
              ),
            ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text('${v['nom'] ?? ''}', style: TextStyle(color: p.text, fontWeight: FontWeight.w900, fontSize: 19))),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(color: color.withAlpha(40), borderRadius: BorderRadius.circular(12)),
                  child: Text(etatText(etat), style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 11.5)),
                ),
              ]),
              const SizedBox(height: 4),
              Text('${tr('Responsable')} : ${v['responsable'] ?? ''}', style: TextStyle(color: p.muted)),
              if ('${v['tel'] ?? ''}'.isNotEmpty) Text('${tr('Tél.')} ${v['tel']}', style: TextStyle(color: p.muted)),
              if (etat == 'active' && expire != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text('${tr('Valable jusqu’au')} ${dateDay(v['expire_at'])}', style: TextStyle(color: p.accent, fontWeight: FontWeight.w700))),
            ]),
          ),
        ]),
      ),
      if (etat == 'pending' && montant > 0)
        ZkCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Dernière étape 💳', style: TextStyle(color: p.text, fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 6),
            Text('${tr('Envoyez')} ${money(montant)} $devise ${tr('par Mobile Money au')} $paiementTel, ${tr('avec la référence')} ${v['ref']}.', style: TextStyle(color: p.text, height: 1.4)),
            const SizedBox(height: 12),
            SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _paid, icon: const Icon(Icons.check_circle_rounded, size: 19), label: const Text('J’ai payé'))),
          ]),
        ),
      if (etat == 'paid')
        ZkCard(child: Text('Merci ! Nous vérifions votre paiement. Votre compte sera activé dès confirmation.', style: TextStyle(color: p.text, height: 1.4))),
      if (etat == 'refused')
        ZkCard(child: Text('Votre demande n’a pas été acceptée. Contactez Zoneck pour plus d’informations.', style: TextStyle(color: p.text, height: 1.4))),
      if (etat == 'active') ...[
        ZkCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Vos publicités sont gratuites 🎁', style: TextStyle(color: p.text, fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 6),
            Text('Créez autant de publicités que vous voulez : elles sont offertes avec votre compte vendeur.', style: TextStyle(color: p.muted, height: 1.4)),
            const SizedBox(height: 12),
            SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PubsPage())), icon: const Icon(Icons.campaign_rounded, size: 20), label: const Text('Créer une publicité'))),
          ]),
        ),
      ],
      if (etat == 'expired' || (etat == 'active' && expire != null && expire.difference(DateTime.now()).inDays <= 5))
        ZkCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(etat == 'expired' ? 'Votre abonnement est terminé.' : 'Votre abonnement se termine bientôt.', style: TextStyle(color: p.text, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text('${tr('Renouvellement')} : ${money(vendeurMensuel)} $devise ${tr('par mois')}.', style: TextStyle(color: p.muted)),
            const SizedBox(height: 10),
            SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: _renew, icon: const Icon(Icons.autorenew_rounded), label: const Text('Renouveler mon compte'))),
          ]),
        ),
      const VendeurClause(),
    ];
  }
}

/// « Nos vendeurs » : les comptes vendeur actifs, présentés comme les salons.
class VendeursSection extends StatefulWidget {
  const VendeursSection({super.key});
  @override
  State<VendeursSection> createState() => _VendeursSectionState();
}

class _VendeursSectionState extends State<VendeursSection> {
  List<Map<String, dynamic>> _rows = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await sb.from('vendeurs').select().eq('status', 'active').order('created_at', ascending: true);
      final now = DateTime.now();
      final list = [
        for (final x in (r as List))
          if (parseDate(x['expire_at']) == null || parseDate(x['expire_at'])!.isAfter(now)) Map<String, dynamic>.from(x)
      ];
      if (mounted) setState(() => _rows = list);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    if (_rows.isEmpty) return const SizedBox.shrink();
    final p = context.pal;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SectionTitle('Nos vendeurs'),
      for (final v in _rows)
        ZkCard(
          padding: EdgeInsets.zero,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Builder(builder: (context) {
              final photos = [for (final k in ['photo', 'photo2']) if ('${v[k] ?? ''}'.isNotEmpty) '${v[k]}'];
              if (photos.isEmpty) return const SizedBox.shrink();
              return ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
                child: SizedBox(
                  height: 210,
                  width: double.infinity,
                  child: photos.length == 1
                      ? ZkImage(photos.first, alignment: Alignment.topCenter, cacheWidth: 900)
                      : Row(children: [for (final ph in photos) Expanded(child: ZkImage(ph, alignment: Alignment.topCenter, cacheWidth: 600))]),
                ),
              );
            }),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('🛍️ ${tr('Vendeur')} ${v['nom'] ?? ''}', style: TextStyle(color: p.text, fontWeight: FontWeight.w800, fontSize: 17)),
                if ('${v['responsable'] ?? ''}'.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 3), child: Text('${tr('Responsable')} : ${v['responsable']}', style: TextStyle(color: p.muted))),
                if ('${v['description'] ?? ''}'.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 3), child: Text('${v['description']}', style: TextStyle(color: p.muted, height: 1.35))),
                if ('${v['tel'] ?? ''}'.trim().isNotEmpty) ...[
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () {
                        final c = '${v['tel']}'.replaceAll(RegExp(r'[^0-9+]'), '');
                        if (c.length >= 6) launchUrl(Uri.parse('tel:$c'), mode: LaunchMode.externalApplication);
                      },
                      icon: const Icon(Icons.call_rounded, size: 20),
                      label: const Text('Appeler'),
                    ),
                  ),
                ],
              ]),
            ),
          ]),
        ),
    ]);
  }
}
