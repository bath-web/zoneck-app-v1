import 'package:flutter/material.dart' hide Text;
import 'package:video_player/video_player.dart';
import '../core/theme.dart';
import 'common.dart';
import 'zk_text.dart';

/// Liste de textes (photos / vidéos) lue dans une colonne de la base (liste JSON ou vide).
List<String> mediaList(dynamic v) {
  if (v is List) {
    return [for (final e in v) if ('$e'.trim().isNotEmpty) '$e'];
  }
  return <String>[];
}

/// Photos et vidéos d'une publicité : on glisse de gauche à droite.
class PubMedia extends StatefulWidget {
  final List<String> photos;
  final List<String> videos;
  final double height;
  const PubMedia({super.key, required this.photos, required this.videos, this.height = 220});

  @override
  State<PubMedia> createState() => _PubMediaState();
}

class _PubMediaState extends State<PubMedia> {
  int _i = 0;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final total = widget.photos.length + widget.videos.length;
    if (total == 0) return const SizedBox.shrink();
    return SizedBox(
      height: widget.height,
      width: double.infinity,
      child: Stack(children: [
        PageView.builder(
          itemCount: total,
          onPageChanged: (i) => setState(() => _i = i),
          itemBuilder: (context, i) {
            if (i < widget.photos.length) {
              return ZkImage(widget.photos[i], cacheWidth: 900);
            }
            final url = widget.videos[i - widget.photos.length];
            return GestureDetector(
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => VideoViewPage(url: url))),
              child: Container(
                color: Colors.black,
                alignment: Alignment.center,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.play_circle_fill_rounded, size: 64, color: p.accent),
                  const SizedBox(height: 6),
                  const Text('Voir la vidéo', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                ]),
              ),
            );
          },
        ),
        if (total > 1)
          Positioned(
            right: 10,
            bottom: 10,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(12)),
              child: Text('${_i + 1}/$total', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
            ),
          ),
      ]),
    );
  }
}

/// Lecteur vidéo plein écran (une vidéo envoyée par une vendeuse).
class VideoViewPage extends StatefulWidget {
  final String url;
  const VideoViewPage({super.key, required this.url});

  @override
  State<VideoViewPage> createState() => _VideoViewPageState();
}

class _VideoViewPageState extends State<VideoViewPage> {
  VideoPlayerController? _c;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    final c = VideoPlayerController.networkUrl(Uri.parse(widget.url));
    _c = c;
    c.initialize().then((_) {
      if (!mounted) return;
      c.play();
      setState(() {});
    }).catchError((_) {
      if (mounted) setState(() => _failed = true);
    });
  }

  @override
  void dispose() {
    _c?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = _c;
    final ready = c != null && c.value.isInitialized;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white),
      body: Center(
        child: _failed
            ? const Text('Impossible de lire la vidéo.', style: TextStyle(color: Colors.white))
            : !ready
                ? const CircularProgressIndicator()
                : GestureDetector(
                    onTap: () => setState(() => c.value.isPlaying ? c.pause() : c.play()),
                    child: Stack(alignment: Alignment.center, children: [
                      AspectRatio(aspectRatio: c.value.aspectRatio, child: VideoPlayer(c)),
                      if (!c.value.isPlaying) const Icon(Icons.play_circle_fill_rounded, size: 72, color: Colors.white70),
                      Positioned(left: 0, right: 0, bottom: 0, child: VideoProgressIndicator(c, allowScrubbing: true)),
                    ]),
                  ),
      ),
    );
  }
}
