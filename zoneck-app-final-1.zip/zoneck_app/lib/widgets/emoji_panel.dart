import 'package:flutter/material.dart' hide Text;
import '../core/emoji_data.dart';
import '../core/theme.dart';
import 'zk_text.dart';

class EmojiPanel extends StatefulWidget {
  final ValueChanged<String> onEmoji;
  final ValueChanged<String> onQuick;
  const EmojiPanel({super.key, required this.onEmoji, required this.onQuick});

  @override
  State<EmojiPanel> createState() => _EmojiPanelState();
}

class _EmojiPanelState extends State<EmojiPanel> {
  int _cat = 0;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final cat = emojiCats[_cat];
    return Container(
      height: 280,
      color: p.bg2,
      child: Column(children: [
        SizedBox(
          height: 48,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 8),
            children: [
              for (var i = 0; i < emojiCats.length; i++)
                GestureDetector(
                  onTap: () => setState(() => _cat = i),
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 3, vertical: 6),
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: i == _cat ? p.accent : Colors.transparent,
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Text(emojiCats[i].icon, style: const TextStyle(fontSize: 20)),
                  ),
                ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 2, 16, 4),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text(cat.name, style: TextStyle(color: p.muted, fontWeight: FontWeight.w700, fontSize: 12.5)),
          ),
        ),
        Expanded(
          child: cat.quick
              ? ListView(
                  padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
                  children: [
                    Wrap(
                      spacing: 8,
                      runSpacing: 4,
                      children: [
                        for (final s in cat.items)
                          ActionChip(label: Text(s), onPressed: () => widget.onQuick(s)),
                      ],
                    ),
                  ],
                )
              : GridView.count(
                  crossAxisCount: 7,
                  padding: const EdgeInsets.fromLTRB(8, 0, 8, 12),
                  children: [
                    for (final e in cat.items)
                      InkWell(
                        borderRadius: BorderRadius.circular(10),
                        onTap: () => widget.onEmoji(e),
                        child: Center(child: Text(e, style: const TextStyle(fontSize: 26))),
                      ),
                  ],
                ),
        ),
      ]),
    );
  }
}
