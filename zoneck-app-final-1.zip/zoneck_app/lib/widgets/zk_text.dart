import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;
import '../core/i18n.dart';

/// Remplace le « Text » de Flutter : traduit automatiquement les textes de l'appli
/// selon la langue choisie dans les paramètres.
class Text extends StatelessWidget {
  final String? data;
  final InlineSpan? textSpan;
  final TextStyle? style;
  final TextAlign? textAlign;
  final int? maxLines;
  final TextOverflow? overflow;

  const Text(String this.data, {super.key, this.style, this.textAlign, this.maxLines, this.overflow}) : textSpan = null;

  const Text.rich(InlineSpan this.textSpan, {super.key, this.style, this.textAlign, this.maxLines, this.overflow}) : data = null;

  @override
  Widget build(BuildContext context) {
    final span = textSpan;
    if (span != null) {
      return m.Text.rich(span, style: style, textAlign: textAlign, maxLines: maxLines, overflow: overflow);
    }
    return m.Text(tr(data ?? ''), style: style, textAlign: textAlign, maxLines: maxLines, overflow: overflow);
  }
}
