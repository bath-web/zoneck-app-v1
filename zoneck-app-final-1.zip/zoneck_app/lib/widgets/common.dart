import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart' hide Text;
import '../core/theme.dart';
import 'zk_text.dart';

/// Image venant d'un asset ("asset:nom"), d'une donnée intégrée ("data:") ou d'internet.
class ZkImage extends StatelessWidget {
  final String? src;
  final BoxFit fit;
  final double? width, height;
  final int? cacheWidth;
  final Alignment alignment;
  const ZkImage(this.src, {super.key, this.fit = BoxFit.cover, this.width, this.height, this.cacheWidth = 700, this.alignment = Alignment.center});

  static final Map<String, Uint8List> _mem = {};

  static Uint8List? bytesOf(String s) {
    final cached = _mem[s];
    if (cached != null) return cached;
    try {
      final b = base64Decode(s.substring(s.indexOf(',') + 1));
      if (_mem.length > 40) _mem.clear();
      _mem[s] = b;
      return b;
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = src;
    Widget ph() => Container(
          width: width,
          height: height,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [context.pal.bg2, context.pal.accent.withAlpha(60)],
            ),
          ),
          child: Center(child: Icon(Icons.content_cut_rounded, color: context.pal.accent.withAlpha(170), size: 34)),
        );
    if (s == null || s.isEmpty) return ph();
    if (s.startsWith('asset:')) {
      return Image.asset('assets/images/${s.substring(6)}.jpg',
          fit: fit, width: width, height: height, cacheWidth: cacheWidth, alignment: alignment,
          errorBuilder: (_, __, ___) => ph());
    }
    if (s.startsWith('data:')) {
      final b = bytesOf(s);
      if (b == null) return ph();
      return Image.memory(b,
          fit: fit, width: width, height: height, cacheWidth: cacheWidth, alignment: alignment,
          gaplessPlayback: true, errorBuilder: (_, __, ___) => ph());
    }
    if (s.startsWith('http')) {
      return Image.network(s,
          fit: fit, width: width, height: height, cacheWidth: cacheWidth, alignment: alignment,
          errorBuilder: (_, __, ___) => ph(),
          loadingBuilder: (c, child, p) => p == null ? child : Container(width: width, height: height, color: context.pal.card));
    }
    return ph();
  }
}

/// Avatar rond : emoji ("e:🌸"), image, ou initiale.
class Avatar extends StatelessWidget {
  final String? avatar;
  final String name;
  final double size;
  const Avatar({super.key, this.avatar, this.name = '', this.size = 40});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final a = avatar ?? '';
    Widget child;
    if (a.startsWith('e:')) {
      child = Text(a.substring(2), style: TextStyle(fontSize: size * .5));
    } else if (a.startsWith('data:') || a.startsWith('http')) {
      child = ClipOval(child: ZkImage(a, width: size, height: size, cacheWidth: 120));
    } else {
      final ini = name.trim().isEmpty ? '?' : name.trim().characters.first.toUpperCase();
      child = Text(ini, style: TextStyle(fontSize: size * .42, fontWeight: FontWeight.w800, color: p.ink));
    }
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: a.startsWith('e:') ? p.card : p.accent,
        border: Border.all(color: p.line),
      ),
      child: child,
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String? sub;
  final Widget? trailing;
  const SectionTitle(this.title, {super.key, this.sub, this.trailing});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 22, 16, 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: p.text)),
                if (sub != null) Padding(padding: const EdgeInsets.only(top: 3), child: Text(sub!, style: TextStyle(color: p.muted, fontSize: 13.5, height: 1.35))),
              ],
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

class ZkCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  final EdgeInsets margin;
  const ZkCard({super.key, required this.child, this.padding = const EdgeInsets.all(14), this.onTap, this.margin = const EdgeInsets.fromLTRB(16, 0, 16, 12)});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: margin,
      child: Material(
        color: p.card,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Container(
            padding: padding,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: p.line)),
            child: child,
          ),
        ),
      ),
    );
  }
}

class Empty extends StatelessWidget {
  final String text;
  final IconData icon;
  const Empty(this.text, {super.key, this.icon = Icons.inbox_outlined});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 44, color: p.muted),
          const SizedBox(height: 10),
          Text(text, textAlign: TextAlign.center, style: TextStyle(color: p.muted, height: 1.4)),
        ],
      ),
    );
  }
}

void toast(BuildContext context, String msg, {bool error = false}) {
  final p = context.pal;
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: error ? const Color(0xFFFF8A8A) : p.accent,
      duration: Duration(seconds: error ? 4 : 3),
    ));
}

Widget stars(int n, {double size = 16}) => Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        for (var i = 1; i <= 5; i++)
          Icon(i <= n ? Icons.star_rounded : Icons.star_outline_rounded, size: size, color: const Color(0xFFFFC94D)),
      ],
    );

/// Bouton principal avec indicateur de chargement.
class BusyButton extends StatelessWidget {
  final String label;
  final bool busy;
  final VoidCallback? onPressed;
  final IconData? icon;
  const BusyButton({super.key, required this.label, required this.busy, required this.onPressed, this.icon});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: FilledButton(
        onPressed: busy ? null : onPressed,
        child: busy
            ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.4))
            : Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                if (icon != null) ...[Icon(icon, size: 19), const SizedBox(width: 8)],
                Text(label),
              ]),
      ),
    );
  }
}

/// Pastille rouge avec le nombre de nouveaux messages (1, 2, 3…).
class RedBadge extends StatelessWidget {
  final int count;
  final Widget child;
  const RedBadge({super.key, required this.count, required this.child});

  @override
  Widget build(BuildContext context) {
    return Badge(
      isLabelVisible: count > 0,
      backgroundColor: const Color(0xFFE53935),
      textColor: Colors.white,
      label: Text(count > 99 ? '99+' : '$count', style: const TextStyle(fontWeight: FontWeight.w800)),
      child: child,
    );
  }
}

Future<T?> sheet<T>(BuildContext context, Widget child) {
  final p = context.pal;
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: p.bg2,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: (c) => Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(c).viewInsets.bottom),
      child: child,
    ),
  );
}
