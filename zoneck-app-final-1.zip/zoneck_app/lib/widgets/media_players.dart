import 'package:flutter/material.dart' hide Text;
import 'package:flutter/material.dart' as m show Text;
import 'package:video_player/video_player.dart';
import '../core/chat_media.dart';
import '../core/theme.dart';
import 'common.dart';
import 'pub_media.dart';

String _clock(int secs) {
  final s = secs < 0 ? 0 : secs;
  return '${s ~/ 60}:${(s % 60).toString().padLeft(2, '0')}';
}

/// Message vocal : bouton lecture, barre de progression et durée.
class AudioBubble extends StatefulWidget {
  final String url;
  final Color fg;
  const AudioBubble({super.key, required this.url, required this.fg});

  @override
  State<AudioBubble> createState() => _AudioBubbleState();
}

class _AudioBubbleState extends State<AudioBubble> {
  VideoPlayerController? _c;
  bool _loading = false, _failed = false;
  static _AudioBubbleState? _active;

  int get _totalMs {
    final c = _c;
    if (c != null && c.value.isInitialized && c.value.duration.inMilliseconds > 0) return c.value.duration.inMilliseconds;
    return audioSeconds(widget.url) * 1000;
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    if (_active == this) _active = null;
    _c?.removeListener(_tick);
    _c?.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    var c = _c;
    if (c == null) {
      setState(() {
        _loading = true;
        _failed = false;
      });
      final nc = VideoPlayerController.networkUrl(Uri.parse(cleanUrl(widget.url)));
      try {
        await nc.initialize();
      } catch (_) {
        await nc.dispose();
        if (mounted) {
          setState(() {
            _loading = false;
            _failed = true;
          });
        }
        return;
      }
      if (!mounted) {
        await nc.dispose();
        return;
      }
      nc.addListener(_tick);
      c = nc;
      _c = nc;
      _loading = false;
    }
    if (c.value.isPlaying) {
      await c.pause();
    } else {
      if (c.value.duration.inMilliseconds > 0 && c.value.position >= c.value.duration) await c.seekTo(Duration.zero);
      final other = _active;
      if (other != null && other != this) await other._pauseOnly();
      _active = this;
      await c.play();
    }
    if (mounted) setState(() {});
  }

  Future<void> _pauseOnly() async {
    try {
      await _c?.pause();
    } catch (_) {}
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final fg = widget.fg;
    final c = _c;
    final playing = c != null && c.value.isPlaying;
    final total = _totalMs;
    final pos = c == null ? 0 : c.value.position.inMilliseconds;
    final frac = total <= 0 ? 0.0 : (pos / total).clamp(0.0, 1.0);
    return SizedBox(
      width: 210,
      child: Row(children: [
        GestureDetector(
          onTap: _loading ? null : _toggle,
          child: Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(shape: BoxShape.circle, color: fg.withAlpha(40)),
            child: _loading
                ? Padding(padding: const EdgeInsets.all(10), child: CircularProgressIndicator(strokeWidth: 2.2, color: fg))
                : Icon(_failed ? Icons.error_outline_rounded : (playing ? Icons.pause_rounded : Icons.play_arrow_rounded), color: fg, size: 26),
          ),
        ),
        Expanded(
          child: SliderTheme(
            data: SliderTheme.of(context).copyWith(
              trackHeight: 3,
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
              overlayShape: SliderComponentShape.noOverlay,
              activeTrackColor: fg,
              inactiveTrackColor: fg.withAlpha(60),
              thumbColor: fg,
            ),
            child: Slider(
              value: frac,
              onChanged: (c == null || total <= 0)
                  ? null
                  : (v) {
                      c.seekTo(Duration(milliseconds: (v * total).round()));
                    },
            ),
          ),
        ),
        m.Text(_clock(((playing || pos > 0) ? pos : total) ~/ 1000), style: TextStyle(color: fg.withAlpha(200), fontSize: 11.5, fontWeight: FontWeight.w600)),
      ]),
    );
  }
}

/// Vignette d'une vidéo envoyée dans une discussion : on touche pour la regarder.
class VideoBubble extends StatelessWidget {
  final String url;
  const VideoBubble({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return GestureDetector(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => VideoViewPage(url: cleanUrl(url)))),
      child: Container(
        width: 220,
        height: 150,
        decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(12)),
        alignment: Alignment.center,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.play_circle_fill_rounded, size: 54, color: p.accent),
          const SizedBox(height: 4),
          const m.Text('Vidéo', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
        ]),
      ),
    );
  }
}

/// Photo en plein écran (on peut zoomer).
class ImageViewPage extends StatelessWidget {
  final String url;
  const ImageViewPage({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white),
      body: Center(
        child: InteractiveViewer(minScale: 1, maxScale: 5, child: ZkImage(url, fit: BoxFit.contain, cacheWidth: 1600)),
      ),
    );
  }
}
