import 'dart:async';
import 'dart:io' show File;
import 'package:flutter/material.dart' hide Text;
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import '../core/api.dart';
import '../core/app_state.dart';
import '../core/chat_media.dart';
import '../core/config.dart';
import '../core/hidden.dart';
import '../core/theme.dart';
import 'common.dart';
import 'emoji_panel.dart';
import 'media_players.dart';
import 'zk_text.dart';
import '../core/i18n.dart';

// ---------------------------------------------------------------- Citations

class DecodedMsg {
  final String body;
  final String? qName, qText;
  const DecodedMsg(this.body, {this.qName, this.qText});
}

/// Les réponses sont stockées dans le texte (séparateur invisible), comme les citations du site.
DecodedMsg decodeMsg(String raw) {
  if (raw.isEmpty || raw[0] != zkTag) return DecodedMsg(raw);
  final parts = raw.substring(1).split(zkTag);
  if (parts.length < 4) return DecodedMsg(parts.join());
  final body = parts.sublist(3).join();
  if (parts[0] == 'zk') return DecodedMsg(body, qName: parts[1], qText: parts[2]);
  return DecodedMsg(body);
}

String encodeReply(String name, String quote, String body) {
  String clean(String s) => s.replaceAll(zkTag, '').replaceAll('\n', ' ');
  return '${zkTag}zk$zkTag${clean(name)}$zkTag${clean(quote)}$zkTag$body';
}

// ---------------------------------------------------------------- Données

class ChatItem {
  final String id;
  final bool mine;
  final String text;
  final String? createdAt, media, type, senderName, senderAvatar, replyName, replyText;
  final bool canDeleteAll;
  const ChatItem({
    required this.id,
    required this.mine,
    required this.text,
    this.createdAt,
    this.media,
    this.type,
    this.senderName,
    this.senderAvatar,
    this.replyName,
    this.replyText,
    this.canDeleteAll = false,
  });

  String get body => decodeMsg(text).body;

  String get preview {
    final b = body.trim();
    if (b.isNotEmpty) {
      final ch = b.characters;
      return ch.length > 90 ? '${ch.take(90)}…' : b;
    }
    if (type == 'image' || type == 'photo') return '📷 Photo';
    if (type == 'audio') return '🎤 Message vocal';
    if (type == 'video') return '🎬 Vidéo';
    return '';
  }
}

String replyAuthor(ChatItem r, String peerLabel) {
  if (r.mine) return app.prenom;
  final n = r.senderName ?? '';
  return n.isNotEmpty ? n : peerLabel;
}

// ---------------------------------------------------------------- Bulle

bool _onlyEmoji(String s) {
  final t = s.trim();
  if (t.isEmpty || t.runes.length > 8) return false;
  return !RegExp(r'[A-Za-z0-9\u00C0-\u024F]').hasMatch(t);
}

Color _nameColor(BuildContext context, String name) {
  var h = 0;
  for (final u in name.codeUnits) {
    h = (h * 31 + u) & 0xFFFFFF;
  }
  final light = Theme.of(context).brightness == Brightness.light;
  return HSLColor.fromAHSL(1, (h % 360).toDouble(), .65, light ? .32 : .74).toColor();
}

class ChatBubble extends StatelessWidget {
  final ChatItem item;
  final String body;
  final String? qName, qText;
  final bool group;
  final VoidCallback onLongPress;
  final VoidCallback onReply;
  const ChatBubble({
    super.key,
    required this.item,
    required this.body,
    this.qName,
    this.qText,
    this.group = false,
    required this.onLongPress,
    required this.onReply,
  });

  Widget _quote(BuildContext context, Color fg) {
    final p = context.pal;
    final n = qName ?? '';
    final who = n.isEmpty ? '' : (n == app.prenom ? 'Vous' : n);
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: IntrinsicHeight(
          child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Container(width: 4, color: item.mine ? p.ink : p.accent),
            Flexible(
              child: Container(
                color: Colors.black.withAlpha(30),
                padding: const EdgeInsets.fromLTRB(8, 5, 10, 5),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  if (who.isNotEmpty)
                    Text(who, style: TextStyle(color: fg, fontWeight: FontWeight.w800, fontSize: 12)),
                  Text(qText ?? '', maxLines: 3, overflow: TextOverflow.ellipsis, style: TextStyle(color: fg.withAlpha(200), fontSize: 12.5)),
                ]),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final mine = item.mine;
    final bg = mine ? p.accent : p.card;
    final fg = mine ? p.ink : p.text;
    final media = item.media;
    final mediaUrl = media ?? '';
    final hasMedia = mediaUrl.isNotEmpty;
    final hasImg = hasMedia && (item.type == 'image' || item.type == 'photo');
    final isAudio = hasMedia && item.type == 'audio';
    final isVideo = hasMedia && item.type == 'video';
    final big = !hasImg && !isAudio && !isVideo && (qText ?? '').isEmpty && _onlyEmoji(body);
    final sName = item.senderName ?? '';
    final showName = group && !mine && sName.isNotEmpty;
    final maxW = MediaQuery.of(context).size.width * ((group && !mine) ? .68 : .78);

    final bubble = Container(
      constraints: BoxConstraints(maxWidth: maxW),
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 6),
      decoration: BoxDecoration(
        color: big ? Colors.transparent : bg,
        border: (mine || big) ? null : Border.all(color: p.line),
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(18),
          topRight: const Radius.circular(18),
          bottomLeft: Radius.circular(mine ? 18 : 4),
          bottomRight: Radius.circular(mine ? 4 : 18),
        ),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        if (showName)
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 3),
              child: Text(sName, style: TextStyle(color: _nameColor(context, sName), fontWeight: FontWeight.w800, fontSize: 12.5)),
            ),
          ),
        if ((qText ?? '').isNotEmpty) _quote(context, fg),
        if (hasImg)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: GestureDetector(
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ImageViewPage(url: mediaUrl))),
              child: ClipRRect(borderRadius: BorderRadius.circular(12), child: ZkImage(mediaUrl, cacheWidth: 600)),
            ),
          ),
        if (isVideo) Padding(padding: const EdgeInsets.only(bottom: 6), child: VideoBubble(url: mediaUrl)),
        if (isAudio) Padding(padding: const EdgeInsets.only(bottom: 4), child: AudioBubble(url: mediaUrl, fg: fg)),
        if (body.isNotEmpty)
          Align(
            alignment: Alignment.centerLeft,
            child: Text(body, style: TextStyle(color: big ? p.text : fg, fontSize: big ? 38 : 15, height: 1.3)),
          ),
        const SizedBox(height: 2),
        Text(hhmm(item.createdAt), style: TextStyle(color: big ? p.muted : fg.withAlpha(150), fontSize: 10.5)),
      ]),
    );

    Widget row;
    if (mine) {
      row = Align(alignment: Alignment.centerRight, child: bubble);
    } else if (group) {
      row = Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Avatar(avatar: item.senderAvatar, name: sName, size: 30),
        const SizedBox(width: 6),
        Flexible(child: bubble),
      ]);
    } else {
      row = Align(alignment: Alignment.centerLeft, child: bubble);
    }
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onLongPress: onLongPress,
      onHorizontalDragEnd: (d) {
        if ((d.primaryVelocity ?? 0) > 280) onReply();
      },
      child: Padding(padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 12), child: row),
    );
  }
}

// ---------------------------------------------------------------- Zone de saisie

String _clock(int secs) => '${secs ~/ 60}:${(secs % 60).toString().padLeft(2, '0')}';

class ZkComposer extends StatelessWidget {
  final TextEditingController c;
  final FocusNode focus;
  final VoidCallback onSend;
  final VoidCallback? onAttach;
  final VoidCallback? onMic;
  final VoidCallback onEmoji;
  final bool emojiOpen, busy;
  final String? replyWho, replyText;
  final VoidCallback? onCancelReply;
  final Widget? panel;
  final bool recording;
  final int recSecs;
  final VoidCallback? onCancelRec, onSendRec;
  const ZkComposer({
    super.key,
    required this.c,
    required this.focus,
    required this.onSend,
    required this.onEmoji,
    this.onAttach,
    this.onMic,
    this.emojiOpen = false,
    this.busy = false,
    this.replyWho,
    this.replyText,
    this.onCancelReply,
    this.panel,
    this.recording = false,
    this.recSecs = 0,
    this.onCancelRec,
    this.onSendRec,
  });

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final border = OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide(color: p.line));
    return Container(
      decoration: BoxDecoration(color: p.bg2, border: Border(top: BorderSide(color: p.line))),
      child: SafeArea(
        top: false,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          if (busy) LinearProgressIndicator(minHeight: 2, color: p.accent, backgroundColor: Colors.transparent),
          if (replyText != null && !recording)
            Container(
              margin: const EdgeInsets.fromLTRB(10, 8, 10, 0),
              padding: const EdgeInsets.fromLTRB(12, 6, 4, 6),
              decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: p.line)),
              child: Row(children: [
                Icon(Icons.reply_rounded, color: p.accent, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${tr('Répondre à')} ${replyWho ?? ''}', style: TextStyle(color: p.accent, fontWeight: FontWeight.w800, fontSize: 12.5)),
                    Text(replyText ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: p.muted, fontSize: 12.5)),
                  ]),
                ),
                IconButton(onPressed: onCancelReply, icon: Icon(Icons.close_rounded, color: p.muted, size: 20)),
              ]),
            ),
          if (recording)
            Padding(
              padding: const EdgeInsets.fromLTRB(6, 8, 8, 10),
              child: Row(children: [
                IconButton(onPressed: onCancelRec, icon: const Icon(Icons.delete_outline_rounded, color: Color(0xFFFF6B6B))),
                const Icon(Icons.fiber_manual_record_rounded, color: Color(0xFFFF3B30), size: 16),
                const SizedBox(width: 6),
                Text(_clock(recSecs), style: TextStyle(color: p.text, fontWeight: FontWeight.w800, fontSize: 16)),
                const SizedBox(width: 10),
                Expanded(child: Text('Enregistrement… touchez envoyer', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: p.muted, fontSize: 13))),
                Material(
                  color: p.accent,
                  shape: const CircleBorder(),
                  child: IconButton(onPressed: onSendRec, icon: Icon(Icons.send_rounded, color: p.ink)),
                ),
              ]),
            )
          else
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 6, 8, 8),
              child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                IconButton(
                  onPressed: onEmoji,
                  icon: Icon(emojiOpen ? Icons.keyboard_rounded : Icons.emoji_emotions_outlined, color: p.accent),
                ),
                Expanded(
                  child: TextField(
                    controller: c,
                    focusNode: focus,
                    minLines: 1,
                    maxLines: 5,
                    textCapitalization: TextCapitalization.sentences,
                    decoration: InputDecoration(
                      hintText: tr('Votre message…'),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      border: border,
                      enabledBorder: border,
                      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide(color: p.accent)),
                    ),
                  ),
                ),
                if (onAttach != null) IconButton(onPressed: busy ? null : onAttach, icon: Icon(Icons.attach_file_rounded, color: p.accent)),
                const SizedBox(width: 2),
                ValueListenableBuilder<TextEditingValue>(
                  valueListenable: c,
                  builder: (context, v, _) {
                    final empty = v.text.trim().isEmpty;
                    final showMic = empty && onMic != null;
                    return Material(
                      color: p.accent,
                      shape: const CircleBorder(),
                      child: IconButton(
                        onPressed: busy ? null : (showMic ? onMic : onSend),
                        icon: Icon(showMic ? Icons.mic_rounded : Icons.send_rounded, color: p.ink),
                      ),
                    );
                  },
                ),
              ]),
            ),
          if (panel != null) panel!,
        ]),
      ),
    );
  }
}

// ---------------------------------------------------------------- Écran de discussion complet

class ChatPanel extends StatefulWidget {
  final List<ChatItem> items;
  final Future<void> Function(String text, ChatItem? reply) onSend;

  /// Envoi d'une photo, d'une vidéo ou d'un vocal déjà envoyé sur internet. Absent = pas de pièces jointes.
  final Future<void> Function(SentMedia media, ChatItem? reply)? onMedia;
  final Future<void> Function(ChatItem item)? onDeleteAll;
  final String hiddenScope;
  final String peerLabel;
  final String mediaPrefix;
  final bool group;
  final String emptyText;
  const ChatPanel({
    super.key,
    required this.items,
    required this.onSend,
    required this.hiddenScope,
    required this.peerLabel,
    this.onMedia,
    this.onDeleteAll,
    this.mediaPrefix = 'chat',
    this.group = false,
    this.emptyText = 'Écrivez votre premier message 👋',
  });

  @override
  State<ChatPanel> createState() => _ChatPanelState();
}

class _ChatPanelState extends State<ChatPanel> {
  final _c = TextEditingController();
  final _focus = FocusNode();
  final _scroll = ScrollController();
  final AudioRecorder _rec = AudioRecorder();
  Timer? _recTimer;
  Set<String> _hidden = <String>{};
  ChatItem? _reply;
  bool _emoji = false, _busy = false, _recording = false;
  int _recSecs = 0;

  @override
  void initState() {
    super.initState();
    app.chatOpen++;
    Hidden.load(widget.hiddenScope).then((s) {
      if (mounted) setState(() => _hidden = s);
    });
    _focus.addListener(() {
      if (_focus.hasFocus && _emoji && mounted) setState(() => _emoji = false);
    });
    _toEnd();
  }

  @override
  void didUpdateWidget(covariant ChatPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.items.length != oldWidget.items.length) _toEnd();
  }

  @override
  void dispose() {
    if (app.chatOpen > 0) app.chatOpen--;
    _recTimer?.cancel();
    _rec.dispose();
    _c.dispose();
    _focus.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _toEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
    });
  }

  void _setReply(ChatItem m) {
    setState(() => _reply = m);
    _focus.requestFocus();
  }

  Future<void> _doSend(String t, {bool clear = true}) async {
    if (t.isEmpty || _busy) return;
    final reply = _reply;
    setState(() => _busy = true);
    if (clear) _c.clear();
    try {
      await widget.onSend(t, reply);
      if (mounted) setState(() => _reply = null);
      _toEnd();
    } catch (e) {
      if (mounted) {
        if (clear) _c.text = t;
        toast(context, errText(e), error: true);
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  /// Envoie une photo, une vidéo ou un vocal : `make` prépare le fichier sur internet, puis le message est créé.
  Future<void> _sendMedia(Future<SentMedia?> Function() make) async {
    final f = widget.onMedia;
    if (f == null || _busy) return;
    setState(() => _busy = true);
    try {
      final m = await make();
      if (m != null) {
        await f(m, _reply);
        if (mounted) setState(() => _reply = null);
        _toEnd();
      }
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _attachMenu() {
    FocusScope.of(context).unfocus();
    Widget opt(IconData i, String t, VoidCallback f) => ListTile(
          leading: Icon(i),
          title: Text(t),
          onTap: () {
            Navigator.of(context).pop();
            f();
          },
        );
    sheet<void>(
      context,
      SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const SizedBox(height: 8),
          opt(Icons.photo_library_rounded, 'Photo de la galerie', () => _sendMedia(() => pickPhoto(ImageSource.gallery, prefix: widget.mediaPrefix))),
          opt(Icons.photo_camera_rounded, 'Prendre une photo', () => _sendMedia(() => pickPhoto(ImageSource.camera, prefix: widget.mediaPrefix))),
          opt(Icons.video_library_rounded, 'Vidéo de la galerie', () => _sendMedia(() => pickVideo(ImageSource.gallery, prefix: widget.mediaPrefix))),
          opt(Icons.videocam_rounded, 'Filmer une vidéo', () => _sendMedia(() => pickVideo(ImageSource.camera, prefix: widget.mediaPrefix))),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  Future<void> _startRec() async {
    if (_busy || _recording) return;
    try {
      if (!await _rec.hasPermission()) {
        if (mounted) toast(context, 'Autorisez le micro de votre téléphone pour envoyer un vocal.', error: true);
        return;
      }
      final dir = await getTemporaryDirectory();
      final path = '${dir.path}/zk-${DateTime.now().millisecondsSinceEpoch}.m4a';
      await _rec.start(const RecordConfig(encoder: AudioEncoder.aacLc, bitRate: 64000, sampleRate: 44100), path: path);
      if (!mounted) return;
      FocusScope.of(context).unfocus();
      setState(() {
        _recording = true;
        _recSecs = 0;
        _emoji = false;
      });
      _recTimer?.cancel();
      _recTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted) setState(() => _recSecs++);
      });
    } catch (e) {
      if (mounted) toast(context, 'Impossible de démarrer l’enregistrement.', error: true);
    }
  }

  Future<void> _stopRec({required bool send}) async {
    _recTimer?.cancel();
    final secs = _recSecs;
    if (mounted) setState(() => _recording = false);
    String? path;
    try {
      if (send) {
        path = await _rec.stop();
      } else {
        await _rec.cancel();
      }
    } catch (_) {}
    if (!send || path == null) return;
    final file = path;
    if (secs < 1) {
      if (mounted) toast(context, 'Vocal trop court : gardez le doigt un peu plus longtemps.', error: true);
      return;
    }
    await _sendMedia(() => uploadAudio(file, secs, prefix: widget.mediaPrefix));
    try {
      await File(file).delete();
    } catch (_) {}
  }

  void _insertEmoji(String e) {
    final sel = _c.selection;
    final txt = _c.text;
    final a = (sel.start < 0 || sel.start > txt.length) ? txt.length : sel.start;
    final b = (sel.end < 0 || sel.end > txt.length) ? txt.length : sel.end;
    final lo = a < b ? a : b;
    final hi = a < b ? b : a;
    _c.value = TextEditingValue(
      text: txt.replaceRange(lo, hi, e),
      selection: TextSelection.collapsed(offset: lo + e.length),
    );
  }

  void _toggleEmoji() {
    if (_emoji) {
      setState(() => _emoji = false);
      _focus.requestFocus();
    } else {
      FocusScope.of(context).unfocus();
      setState(() => _emoji = true);
    }
  }

  Future<void> _hide(ChatItem m) async {
    await Hidden.add(widget.hiddenScope, m.id);
    if (mounted) {
      setState(() {});
      toast(context, 'Message supprimé');
    }
  }

  Future<void> _deleteAll(ChatItem m) async {
    final f = widget.onDeleteAll;
    if (f == null) return;
    try {
      await f(m);
    } catch (e) {
      if (mounted) toast(context, errText(e), error: true);
    }
  }

  /// Appui long sur un message : répondre, copier, supprimer.
  void _menu(ChatItem m) {
    HapticFeedback.mediumImpact();
    final p = context.pal;
    final body = m.body;
    const red = Color(0xFFFF6B6B);
    final prev = m.preview;
    sheet<void>(
      context,
      SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const SizedBox(height: 10),
          Container(width: 40, height: 4, decoration: BoxDecoration(color: p.line, borderRadius: BorderRadius.circular(2))),
          if (prev.isNotEmpty)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(16, 12, 16, 4),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(14), border: Border.all(color: p.line)),
              child: Text(prev, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: p.muted)),
            ),
          const SizedBox(height: 6),
          ListTile(
            leading: const Icon(Icons.reply_rounded),
            title: const Text('Répondre'),
            onTap: () {
              Navigator.of(context).pop();
              _setReply(m);
            },
          ),
          if (body.trim().isNotEmpty)
            ListTile(
              leading: const Icon(Icons.copy_rounded),
              title: const Text('Copier'),
              onTap: () {
                Navigator.of(context).pop();
                Clipboard.setData(ClipboardData(text: body));
                toast(context, 'Message copié');
              },
            ),
          ListTile(
            leading: const Icon(Icons.delete_outline_rounded, color: red),
            title: const Text('Supprimer', style: TextStyle(color: red, fontWeight: FontWeight.w700)),
            subtitle: Text('Seulement pour moi : les autres le gardent', style: TextStyle(color: p.muted, fontSize: 12)),
            onTap: () {
              Navigator.of(context).pop();
              _hide(m);
            },
          ),
          if (m.canDeleteAll && widget.onDeleteAll != null)
            ListTile(
              leading: const Icon(Icons.delete_forever_rounded, color: red),
              title: const Text('Supprimer pour tous', style: TextStyle(color: red, fontWeight: FontWeight.w700)),
              onTap: () {
                Navigator.of(context).pop();
                _deleteAll(m);
              },
            ),
          const SizedBox(height: 8),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final items = [for (final m in widget.items) if (!_hidden.contains(m.id)) m];
    final children = <Widget>[];
    String? lastDay;
    for (final m in items) {
      final d = dayLabel(m.createdAt);
      if (d != lastDay) {
        lastDay = d;
        children.add(Center(
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 10),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(color: p.card, borderRadius: BorderRadius.circular(12)),
            child: Text(d, style: TextStyle(color: p.muted, fontSize: 11.5)),
          ),
        ));
      }
      final dec = decodeMsg(m.text);
      final rn = m.replyName ?? '';
      final rt = m.replyText ?? '';
      children.add(ChatBubble(
        item: m,
        body: dec.body,
        qName: rn.isNotEmpty ? rn : dec.qName,
        qText: rt.isNotEmpty ? rt : dec.qText,
        group: widget.group,
        onLongPress: () => _menu(m),
        onReply: () => _setReply(m),
      ));
    }
    final r = _reply;
    final canMedia = widget.onMedia != null;
    return Column(children: [
      Expanded(
        child: items.isEmpty
            ? Center(child: Empty(widget.emptyText, icon: Icons.waving_hand_outlined))
            : ListView(controller: _scroll, padding: const EdgeInsets.symmetric(vertical: 8), children: children),
      ),
      ZkComposer(
        c: _c,
        focus: _focus,
        onSend: () => _doSend(_c.text.trim()),
        onAttach: canMedia ? _attachMenu : null,
        onMic: canMedia ? _startRec : null,
        onEmoji: _toggleEmoji,
        emojiOpen: _emoji,
        busy: _busy,
        replyWho: r == null ? null : (r.mine ? 'Vous' : replyAuthor(r, widget.peerLabel)),
        replyText: r?.preview,
        onCancelReply: () => setState(() => _reply = null),
        recording: _recording,
        recSecs: _recSecs,
        onCancelRec: () => _stopRec(send: false),
        onSendRec: () => _stopRec(send: true),
        panel: _emoji ? EmojiPanel(onEmoji: _insertEmoji, onQuick: (s) => _doSend(s, clear: false)) : null,
      ),
    ]);
  }
}
